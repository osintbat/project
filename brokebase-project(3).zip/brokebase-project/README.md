# Brokebase — Open Source OSINT Intelligence Platform

Modern, secure OSINT platform built with React, TypeScript, Tailwind CSS, and enterprise-grade security modules.

## 🎯 Features

### Frontend
- **Modern React 18** with TypeScript for type safety
- **Tailwind CSS v4** with custom monochromatic design system
- **Responsive Design** optimized for mobile and desktop
- **Gradient Text Effects** with "Wolfeye" branding
- **Component Library** following shadcn/ui principles

### Security Modules (Python)
- **Input Validation** — SQL Injection, XSS, Path Traversal prevention
- **IDOR Protection** — Insecure Direct Object Reference mitigation
- **XSS Protection** — Comprehensive HTML/JavaScript sanitization
- **Rate Limiting** — Token bucket algorithm, exponential backoff
- **CSRF Protection** — Token-based and Same-Site cookie patterns
- **Authentication** — Session management, API keys, 2FA support

### OSINT Tools
- Domain Intelligence & WHOIS lookup
- Social Media Footprint Analysis
- Data Breach Search
- Security Assessment
- Email & Reverse Lookup
- Real-Time Alerts

## 📁 Project Structure

```
brokebase-project/
├── src/
│   ├── components/
│   │   ├── Header.tsx
│   │   ├── Hero.tsx
│   │   ├── Features.tsx
│   │   ├── Tools.tsx
│   │   ├── Security.tsx
│   │   ├── Pricing.tsx
│   │   └── Footer.tsx
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── security/
│   ├── input_validator.py
│   ├── idor_protection.py
│   ├── xss_protection.py
│   ├── csrf_protection.py
│   ├── rate_limiter.py
│   ├── auth_manager.py
│   └── __init__.py
├── index.html
├── package.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig.json
└── README.md
```

## 🚀 Getting Started

### Prerequisites
- Node.js >= 18
- Python >= 3.9
- npm or yarn

### Installation

1. **Install frontend dependencies:**
```bash
cd brokebase-project
npm install
```

2. **Install Python security modules:**
```bash
pip install -r requirements.txt --break-system-packages
```

### Development

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run security module tests
python -m security.input_validator
python -m security.idor_protection
python -m security.xss_protection
python -m security.rate_limiter
```

## 🔒 Security Features

### Input Validation (`input_validator.py`)
- SQL injection detection and prevention
- XSS pattern detection
- Path traversal prevention
- Email and domain validation
- URL validation with open redirect prevention

### IDOR Protection (`idor_protection.py`)
- Resource ownership verification
- Permission-based access control
- Batch resource access validation
- Team-based resource sharing
- Authorization caching with TTL
- Comprehensive audit logging

### XSS Protection (`xss_protection.py`)
- HTML entity escaping
- Event handler removal
- Script tag sanitization
- URL encoding for links
- CSS injection prevention
- Content Security Policy headers

### Rate Limiting (`rate_limiter.py`)
- Token bucket algorithm
- Exponential backoff for failed attempts
- Distributed rate limiting support
- API key tiered limits (Free/Starter/Pro/Enterprise)
- Usage statistics tracking

### CSRF Protection (`csrf_protection.py`)
- Token-based CSRF protection
- Double-submit cookie pattern
- Same-Site cookie attributes
- Token expiration and cleanup

### Authentication (`auth_manager.py`)
- PBKDF2-SHA256 password hashing
- Session management with TTL
- API key generation and validation
- Two-factor authentication support
- Backup code generation

## 🎨 Design System

### Colors (Monochromatic)
- **Canvas**: `#f5f5f5` — Page background
- **Paper**: `#ffffff` — Card surfaces
- **Ink**: `#0a0a0a` — Primary text
- **Mid-gray**: `#737373` — Muted text
- **Ember**: `#e7000b` — Destructive actions

### Typography
- **Font**: Geist (fallback: Inter, system-ui)
- **Scales**: 12px–48px with tight tracking on display sizes
- **Weights**: 400, 500, 600

### Spacing
- **Unit**: 4px
- **Scale**: 4, 8, 12, 16, 20, 24, 48px

### Border Radius
- **Interactive**: 18px (buttons, inputs, badges)
- **Containers**: 24px (cards)

## 📦 Deployment

### Production Build

```bash
npm run build
```

Build output: `dist/`

### Nginx Configuration

The project is configured for Nginx as per `/etc/nginx/sites-enabled/brokebase.com`:

```nginx
root /var/www/brokebase/dist;
index index.html;

location / {
    try_files $uri /index.html;
}
```

### Deploy to Server

```bash
# Stop Nginx
sudo systemctl stop nginx

# Copy dist to server
scp -r dist/* matteo@server:/var/www/brokebase/dist/

# Start Nginx
sudo systemctl start nginx
```

## 🔐 Security Best Practices

1. **Input Validation**: All user input is validated against strict schemas
2. **Output Encoding**: Content is encoded based on context (HTML, attribute, URL, CSS, JavaScript)
3. **Access Control**: IDOR protection ensures users can only access their own data
4. **Rate Limiting**: Prevents brute force and DDoS attacks
5. **CSRF Protection**: Tokens validate state-changing requests
6. **Session Security**: Secure, HTTP-only, Same-Site cookie attributes
7. **Password Security**: PBKDF2-SHA256 hashing with random salts
8. **API Security**: Rate-limited, tier-based API keys with usage tracking

## 📝 API Endpoints

### OSINT Tools
- `GET /api/v1/ip/geolocation?ip=<ip>` — IP Geolocation lookup
- `GET /api/v1/whois?domain=<domain>` — WHOIS data extraction
- `POST /api/v1/ssl/analyze` — SSL certificate analysis
- `GET /api/v1/breaches/search?email=<email>` — Breach database search
- `GET /api/v1/archive/timeline?url=<url>` — Web archive timeline
- `POST /api/v1/reports/generate` — Threat report generation

### Authentication
- `POST /api/auth/register` — User registration
- `POST /api/auth/login` — User login
- `POST /api/auth/logout` — Logout

### Account
- `GET /api/account/profile` — Get user profile
- `POST /api/account/password/change` — Change password
- `POST /api/account/2fa/setup` — Enable 2FA

## 🧪 Testing

```bash
# Python security module tests
python -m pytest security/ -v

# TypeScript type checking
npm run typecheck

# Linting
npm run lint
```

## 📄 License

MIT License - See LICENSE file for details

## 🤝 Contributing

Contributions are welcome! Please ensure:
1. All security tests pass
2. Input validation is comprehensive
3. Output encoding is context-aware
4. Rate limiting is implemented
5. IDOR protections are in place

## ⚠️ Security Vulnerabilities

If you discover a security vulnerability, please email `security@brokebase.com` instead of using the issue tracker.

## 📞 Support

- **Documentation**: https://docs.brokebase.com
- **Community**: https://community.brokebase.com
- **Email**: support@brokebase.com

---

Built with ❤️ for security researchers and OSINT professionals.
