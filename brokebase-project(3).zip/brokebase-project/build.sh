#!/bin/bash
set -e

echo "🏗️  Building Brokebase..."

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing npm dependencies..."
    npm install
fi

# Build React app
echo "🔨 Building React application..."
npm run build

# Check build output
if [ ! -d "dist" ]; then
    echo "❌ Build failed: dist directory not found"
    exit 1
fi

echo "✅ Build completed successfully"
echo "📁 Output directory: ./dist"

# Display build stats
echo ""
echo "📊 Build Statistics:"
du -sh dist/
find dist -type f -exec wc -c + | tail -1

# Ready for deployment
echo ""
echo "🚀 Ready for deployment to /var/www/brokebase/dist"
