#!/bin/bash
set -e

echo "🚀 Deploying Brokebase to production..."

# Check if dist exists
if [ ! -d "dist" ]; then
    echo "⚠️  dist directory not found, building..."
    bash build.sh
fi

# Target directory
DEST_DIR="/var/www/brokebase/dist"

# Backup existing deployment
if [ -d "$DEST_DIR" ]; then
    echo "💾 Backing up existing deployment..."
    BACKUP_DIR="/var/www/brokebase/backups/dist_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$(dirname $BACKUP_DIR)"
    cp -r "$DEST_DIR" "$BACKUP_DIR"
    echo "✅ Backup created: $BACKUP_DIR"
fi

# Stop Nginx
echo "🛑 Stopping Nginx..."
sudo systemctl stop nginx || echo "⚠️  Nginx already stopped"

# Deploy new version
echo "📁 Deploying to $DEST_DIR..."
sudo mkdir -p "$DEST_DIR"
sudo cp -r dist/* "$DEST_DIR/"

# Set proper permissions
echo "🔐 Setting permissions..."
sudo chown -R www-data:www-data "$DEST_DIR"
sudo chmod -R 755 "$DEST_DIR"
sudo find "$DEST_DIR" -type f -exec chmod 644 {} \;

# Verify deployment
echo "✅ Verifying deployment..."
if [ -f "$DEST_DIR/index.html" ]; then
    echo "✅ index.html found"
else
    echo "❌ index.html not found!"
    exit 1
fi

# Restart Nginx
echo "🚀 Starting Nginx..."
sudo systemctl start nginx

# Test Nginx config
echo "🔍 Testing Nginx configuration..."
sudo nginx -t

# Verify service is running
echo "📊 Checking Nginx status..."
sudo systemctl status nginx

echo ""
echo "✅ Deployment completed successfully!"
echo "🌐 Application available at: https://www.brokebase.com"
echo ""
echo "📝 Deployment info:"
echo "  - Timestamp: $(date)"
echo "  - Version: $(cat package.json | grep version | head -1 | awk '{print $2}' | tr -d '",:')"
echo "  - Directory: $DEST_DIR"

# Clean up old backups (keep last 5)
echo ""
echo "🧹 Cleaning up old backups (keeping last 5)..."
BACKUP_DIR="/var/www/brokebase/backups"
if [ -d "$BACKUP_DIR" ]; then
    ls -t "$BACKUP_DIR" | tail -n +6 | while read old_backup; do
        rm -rf "$BACKUP_DIR/$old_backup"
        echo "  Removed: $old_backup"
    done
fi

echo ""
echo "🎉 Ready for production!"
