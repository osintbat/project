"""
Authentication Manager
Handles user authentication, session management, and API key validation
"""

import secrets
import hashlib
import hmac
from typing import Dict, Optional, Tuple
from datetime import datetime, timedelta
import json


class PasswordManager:
    """Secure password handling with PBKDF2"""

    @staticmethod
    def hash_password(password: str, salt: Optional[str] = None, iterations: int = 100000) -> Tuple[str, str]:
        """
        Hash password using PBKDF2-SHA256
        Returns: (hashed_password, salt)
        """
        if salt is None:
            salt = secrets.token_hex(32)

        # PBKDF2-SHA256
        hashed = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            iterations
        )

        return hashed.hex(), salt

    @staticmethod
    def verify_password(password: str, hashed: str, salt: str) -> bool:
        """
        Verify password against stored hash
        """
        new_hash, _ = PasswordManager.hash_password(password, salt)
        
        # Constant-time comparison to prevent timing attacks
        return hmac.compare_digest(new_hash, hashed)


class SessionManager:
    """Manage user sessions"""

    def __init__(self, session_ttl_minutes: int = 60):
        """
        Initialize session manager
        session_ttl_minutes: Session time-to-live in minutes
        """
        self.session_ttl_minutes = session_ttl_minutes
        self.sessions: Dict[str, Dict] = {}

    def create_session(self, user_id: str, user_data: Dict) -> str:
        """
        Create new session for user
        Returns: session_id
        """
        session_id = secrets.token_urlsafe(32)

        self.sessions[session_id] = {
            'user_id': user_id,
            'user_data': user_data,
            'created': datetime.now(),
            'expires': datetime.now() + timedelta(minutes=self.session_ttl_minutes),
            'last_activity': datetime.now()
        }

        return session_id

    def validate_session(self, session_id: str) -> Tuple[bool, Optional[Dict], Optional[str]]:
        """
        Validate session and return user data
        Returns: (is_valid, user_data, error_message)
        """
        if session_id not in self.sessions:
            return False, None, "Invalid session ID"

        session = self.sessions[session_id]

        # Check expiration
        if datetime.now() > session['expires']:
            del self.sessions[session_id]
            return False, None, "Session has expired"

        # Update last activity
        session['last_activity'] = datetime.now()

        return True, session['user_data'], None

    def revoke_session(self, session_id: str) -> bool:
        """Revoke/delete session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False

    def cleanup_expired_sessions(self) -> int:
        """Remove expired sessions"""
        now = datetime.now()
        expired_sessions = [
            session_id for session_id, session in self.sessions.items()
            if now > session['expires']
        ]

        for session_id in expired_sessions:
            del self.sessions[session_id]

        return len(expired_sessions)

    def get_active_sessions_for_user(self, user_id: str) -> list:
        """Get all active sessions for a user"""
        return [
            session_id for session_id, session in self.sessions.items()
            if session['user_id'] == user_id and datetime.now() <= session['expires']
        ]


class APIKeyManager:
    """Manage API keys for programmatic access"""

    def __init__(self):
        self.api_keys: Dict[str, Dict] = {}

    def generate_api_key(self, user_id: str, name: str, tier: str = 'starter') -> Tuple[str, str]:
        """
        Generate new API key
        Returns: (api_key, api_secret)
        """
        api_key = f"bbase_{secrets.token_urlsafe(24)}"
        api_secret = secrets.token_urlsafe(32)

        # Hash the secret for storage
        secret_hash = hashlib.sha256(api_secret.encode()).hexdigest()

        self.api_keys[api_key] = {
            'user_id': user_id,
            'name': name,
            'secret_hash': secret_hash,
            'tier': tier,
            'created': datetime.now(),
            'last_used': None,
            'is_active': True,
            'usage_count': 0
        }

        return api_key, api_secret

    def verify_api_key(self, api_key: str, api_secret: str) -> Tuple[bool, Optional[Dict], Optional[str]]:
        """
        Verify API key and secret
        Returns: (is_valid, key_data, error_message)
        """
        if api_key not in self.api_keys:
            return False, None, "Invalid API key"

        key_data = self.api_keys[api_key]

        # Check if key is active
        if not key_data['is_active']:
            return False, None, "API key is inactive"

        # Verify secret hash
        secret_hash = hashlib.sha256(api_secret.encode()).hexdigest()
        if not hmac.compare_digest(secret_hash, key_data['secret_hash']):
            return False, None, "Invalid API secret"

        # Update last used and usage count
        key_data['last_used'] = datetime.now()
        key_data['usage_count'] += 1

        return True, key_data, None

    def revoke_api_key(self, api_key: str) -> bool:
        """Revoke API key"""
        if api_key in self.api_keys:
            self.api_keys[api_key]['is_active'] = False
            return True
        return False

    def get_user_api_keys(self, user_id: str) -> list:
        """Get all API keys for user"""
        return [
            {'key': key, **{k: v for k, v in data.items() if k != 'secret_hash'}}
            for key, data in self.api_keys.items()
            if data['user_id'] == user_id
        ]


class TwoFactorAuth:
    """Two-factor authentication support"""

    def __init__(self):
        self.pending_verifications: Dict[str, Dict] = {}
        self.user_2fa: Dict[str, Dict] = {}

    def setup_2fa(self, user_id: str) -> str:
        """
        Setup 2FA for user (TOTP secret)
        In production, use pyotp library
        """
        secret = secrets.token_urlsafe(32)

        self.user_2fa[user_id] = {
            'secret': secret,
            'enabled': False,
            'backup_codes': [secrets.token_hex(4) for _ in range(10)],
            'created': datetime.now()
        }

        return secret

    def verify_2fa_code(self, user_id: str, code: str) -> Tuple[bool, Optional[str]]:
        """
        Verify 2FA code (TOTP)
        In production, implement proper TOTP verification
        """
        if user_id not in self.user_2fa:
            return False, "2FA not enabled"

        if self.user_2fa[user_id]['enabled'] is False:
            return False, "2FA is not enabled"

        # In production, verify against TOTP using pyotp
        # For now, placeholder implementation
        if len(code) != 6 or not code.isdigit():
            return False, "Invalid 2FA code format"

        return True, None

    def generate_backup_codes(self, user_id: str) -> list:
        """Generate backup codes for account recovery"""
        if user_id not in self.user_2fa:
            return []

        backup_codes = [secrets.token_hex(4) for _ in range(10)]
        self.user_2fa[user_id]['backup_codes'] = backup_codes

        return backup_codes


class AuthenticationManager:
    """Main authentication manager combining all components"""

    def __init__(self):
        self.password_manager = PasswordManager()
        self.session_manager = SessionManager()
        self.api_key_manager = APIKeyManager()
        self.two_factor_auth = TwoFactorAuth()
        self.users: Dict[str, Dict] = {}  # In production, use database

    def register_user(self, username: str, email: str, password: str) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """
        Register new user
        Returns: (success, error, user_data)
        """
        # Check if user already exists
        if any(u.get('username') == username or u.get('email') == email for u in self.users.values()):
            return False, "Username or email already exists", None

        user_id = secrets.token_urlsafe(16)
        hashed_password, salt = self.password_manager.hash_password(password)

        user_data = {
            'user_id': user_id,
            'username': username,
            'email': email,
            'password_hash': hashed_password,
            'password_salt': salt,
            'created': datetime.now(),
            'is_active': True,
            '2fa_enabled': False
        }

        self.users[user_id] = user_data

        return True, None, {'user_id': user_id, 'username': username, 'email': email}

    def authenticate_user(self, username: str, password: str) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Authenticate user and create session
        Returns: (success, error, session_id)
        """
        # Find user by username
        user = next((u for u in self.users.values() if u.get('username') == username), None)

        if user is None:
            return False, "Invalid username or password", None

        # Verify password
        if not self.password_manager.verify_password(
            password,
            user['password_hash'],
            user['password_salt']
        ):
            return False, "Invalid username or password", None

        # Create session
        session_id = self.session_manager.create_session(
            user['user_id'],
            {'username': username, 'email': user['email']}
        )

        return True, None, session_id


# Example usage
if __name__ == '__main__':
    auth_manager = AuthenticationManager()

    # Test user registration
    print("User Registration Test:")
    success, error, user_data = auth_manager.register_user("john_doe", "john@example.com", "SecurePassword123!")
    print(f"Registration: Success={success}, User={user_data}")

    # Test authentication
    print("\nAuthentication Test:")
    success, error, session_id = auth_manager.authenticate_user("john_doe", "SecurePassword123!")
    print(f"Auth: Success={success}, SessionID={session_id[:20]}...")

    # Test session validation
    print("\nSession Validation Test:")
    if session_id:
        is_valid, user_data, error = auth_manager.session_manager.validate_session(session_id)
        print(f"Session Valid: {is_valid}, UserData={user_data}")

    # Test API key generation
    print("\nAPI Key Generation Test:")
    if session_id:
        is_valid, user_data, _ = auth_manager.session_manager.validate_session(session_id)
        if is_valid:
            api_key, api_secret = auth_manager.api_key_manager.generate_api_key(
                user_data.get('username'), "Development Key"
            )
            print(f"API Key: {api_key[:20]}...")
            print(f"API Secret: {api_secret[:20]}...")
