"""
Input Validator Module
Prevents: SQL Injection, XSS, Path Traversal, LDAP Injection
"""

import re
import urllib.parse
from typing import Any, Dict, List, Optional, Union
from pathlib import Path


class InputValidator:
    """Comprehensive input validation and sanitization"""

    # SQL Injection patterns
    SQL_KEYWORDS = [
        'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 
        'ALTER', 'EXEC', 'EXECUTE', 'SCRIPT', 'UNION', '--', ';'
    ]
    
    # XSS patterns
    XSS_PATTERNS = [
        r'<script[^>]*>.*?</script>',
        r'javascript:',
        r'onerror=',
        r'onload=',
        r'onclick=',
        r'onmouseover=',
        r'eval\(',
        r'expression\(',
    ]
    
    # Path traversal patterns
    PATH_TRAVERSAL_PATTERNS = [
        r'\.\.',
        r'\.\./',
        r'\.\.\\',
        r'%2e%2e',
    ]

    @staticmethod
    def validate_sql_input(value: str, allow_wildcards: bool = False) -> tuple[bool, Optional[str]]:
        """
        Validates input for SQL injection attempts
        Returns: (is_valid, error_message)
        """
        if not isinstance(value, str):
            return False, "Input must be a string"
        
        # Check length
        if len(value) > 1000:
            return False, "Input exceeds maximum length (1000 chars)"
        
        # Check for SQL keywords
        upper_value = value.upper()
        for keyword in InputValidator.SQL_KEYWORDS:
            if keyword in upper_value:
                return False, f"Suspicious SQL keyword detected: {keyword}"
        
        # Check for common SQL injection patterns
        if re.search(r"['\"](.*?)(UNION|SELECT|INSERT|DELETE|UPDATE|DROP)", value, re.IGNORECASE):
            return False, "Potential SQL injection detected"
        
        # Check for comment sequences
        if '--' in value or '/*' in value or '*/' in value:
            return False, "SQL comment syntax detected"
        
        return True, None

    @staticmethod
    def sanitize_xss(value: str) -> str:
        """
        Sanitizes HTML/JavaScript to prevent XSS attacks
        """
        if not isinstance(value, str):
            return str(value)
        
        # Remove potentially dangerous patterns
        for pattern in InputValidator.XSS_PATTERNS:
            value = re.sub(pattern, '', value, flags=re.IGNORECASE)
        
        # HTML encode special characters
        dangerous_chars = {
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '&': '&amp;',
        }
        
        for char, encoded in dangerous_chars.items():
            value = value.replace(char, encoded)
        
        return value

    @staticmethod
    def validate_path(file_path: str, base_dir: str = '/var/www/brokebase') -> tuple[bool, Optional[str]]:
        """
        Validates file path to prevent directory traversal
        Returns: (is_valid, error_message)
        """
        try:
            # Resolve the path
            base = Path(base_dir).resolve()
            requested = (base / file_path).resolve()
            
            # Ensure the resolved path is within the base directory
            if not str(requested).startswith(str(base)):
                return False, "Path traversal attempt detected"
            
            # Check for common traversal patterns
            if any(pattern in file_path for pattern in InputValidator.PATH_TRAVERSAL_PATTERNS):
                return False, "Path traversal pattern detected"
            
            return True, None
        except Exception as e:
            return False, f"Path validation error: {str(e)}"

    @staticmethod
    def validate_email(email: str) -> tuple[bool, Optional[str]]:
        """
        Validates email format using RFC 5322 simplified pattern
        """
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        if not re.match(pattern, email):
            return False, "Invalid email format"
        
        if len(email) > 254:
            return False, "Email exceeds maximum length"
        
        # Check for SQL injection in email
        is_valid, error = InputValidator.validate_sql_input(email)
        if not is_valid:
            return False, f"Suspicious email content: {error}"
        
        return True, None

    @staticmethod
    def validate_ip_address(ip: str) -> tuple[bool, Optional[str]]:
        """
        Validates IPv4 and IPv6 addresses
        """
        # IPv4 pattern
        ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        # IPv6 pattern (simplified)
        ipv6_pattern = r'^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$'
        
        if re.match(ipv4_pattern, ip):
            parts = ip.split('.')
            for part in parts:
                if int(part) > 255:
                    return False, "Invalid IPv4 address"
            return True, None
        elif re.match(ipv6_pattern, ip):
            return True, None
        else:
            return False, "Invalid IP address format"

    @staticmethod
    def validate_domain(domain: str) -> tuple[bool, Optional[str]]:
        """
        Validates domain name format
        """
        # Domain pattern
        domain_pattern = r'^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$'
        
        if not re.match(domain_pattern, domain.lower()):
            return False, "Invalid domain format"
        
        if len(domain) > 253:
            return False, "Domain exceeds maximum length"
        
        # Check for SQL injection
        is_valid, error = InputValidator.validate_sql_input(domain)
        if not is_valid:
            return False, f"Suspicious domain content: {error}"
        
        return True, None

    @staticmethod
    def validate_url(url: str) -> tuple[bool, Optional[str]]:
        """
        Validates URL format and prevents open redirect
        """
        try:
            parsed = urllib.parse.urlparse(url)
            
            # Only allow http and https
            if parsed.scheme not in ('http', 'https'):
                return False, "Only HTTP(S) schemes allowed"
            
            # Ensure hostname is present
            if not parsed.netloc:
                return False, "URL must have a hostname"
            
            # Check for javascript: protocol (common XSS vector)
            if url.startswith('javascript:'):
                return False, "JavaScript protocol not allowed"
            
            # Prevent open redirect
            if url.startswith('//'):
                return False, "Protocol-relative URLs not allowed"
            
            return True, None
        except Exception as e:
            return False, f"URL validation error: {str(e)}"

    @staticmethod
    def validate_input_dict(data: Dict[str, Any], schema: Dict[str, Dict[str, Any]]) -> tuple[bool, Optional[Dict[str, str]]]:
        """
        Validates a dictionary against a schema
        Schema format:
        {
            'field_name': {
                'type': str/int/float/bool,
                'required': True/False,
                'max_length': int,
                'pattern': regex,
                'validator': callable
            }
        }
        """
        errors = {}
        
        for field_name, field_schema in schema.items():
            field_value = data.get(field_name)
            field_type = field_schema.get('type', str)
            is_required = field_schema.get('required', False)
            
            # Check required fields
            if is_required and field_value is None:
                errors[field_name] = f"{field_name} is required"
                continue
            
            if field_value is None:
                continue
            
            # Check type
            if not isinstance(field_value, field_type):
                errors[field_name] = f"{field_name} must be {field_type.__name__}"
                continue
            
            # Check length
            if isinstance(field_value, str):
                max_length = field_schema.get('max_length', 1000)
                if len(field_value) > max_length:
                    errors[field_name] = f"{field_name} exceeds maximum length ({max_length})"
                    continue
            
            # Check pattern
            pattern = field_schema.get('pattern')
            if pattern and isinstance(field_value, str):
                if not re.match(pattern, field_value):
                    errors[field_name] = f"{field_name} does not match required pattern"
                    continue
            
            # Custom validator
            validator = field_schema.get('validator')
            if validator and callable(validator):
                is_valid, error = validator(field_value)
                if not is_valid:
                    errors[field_name] = error
        
        return len(errors) == 0, errors if errors else None


# Example usage
if __name__ == '__main__':
    validator = InputValidator()
    
    # Test SQL injection detection
    print("SQL Injection Test:")
    result, error = validator.validate_sql_input("'; DROP TABLE users; --")
    print(f"Result: {result}, Error: {error}")
    
    # Test XSS detection
    print("\nXSS Test:")
    sanitized = validator.sanitize_xss("<script>alert('xss')</script>")
    print(f"Sanitized: {sanitized}")
    
    # Test path traversal detection
    print("\nPath Traversal Test:")
    result, error = validator.validate_path("../../../etc/passwd")
    print(f"Result: {result}, Error: {error}")
    
    # Test email validation
    print("\nEmail Validation Test:")
    result, error = validator.validate_email("user@example.com")
    print(f"Result: {result}, Error: {error}")
