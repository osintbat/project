"""
IDOR (Insecure Direct Object Reference) Protection Module
Prevents unauthorized access to resources based on user context
"""

import hashlib
import secrets
from typing import Any, Dict, Optional, Union
from datetime import datetime, timedelta
import json


class IDORProtection:
    """Provides mechanisms to prevent IDOR vulnerabilities"""

    def __init__(self, cache_ttl: int = 300):
        """
        Initialize IDOR protection
        cache_ttl: Time to live for authorization cache (seconds)
        """
        self.cache_ttl = cache_ttl
        self.authorization_cache: Dict[str, Dict[str, Any]] = {}

    def generate_secure_token(self, user_id: str, resource_id: str) -> str:
        """
        Generate cryptographically secure token for resource access
        Combines user_id, resource_id, and random component
        """
        random_component = secrets.token_hex(16)
        combined = f"{user_id}:{resource_id}:{random_component}:{int(datetime.now().timestamp())}"
        token = hashlib.sha256(combined.encode()).hexdigest()
        return token

    def verify_resource_ownership(
        self,
        user_id: str,
        resource_id: str,
        resource_owner_id: str,
        resource_type: str = "unknown"
    ) -> tuple[bool, Optional[str]]:
        """
        Verify that the current user owns/has access to the resource
        Returns: (is_authorized, error_message)
        """
        # Direct ownership check
        if str(user_id) != str(resource_owner_id):
            return False, f"User {user_id} is not authorized to access resource {resource_id}"

        # Log the authorization check (for audit trail)
        self._log_access(user_id, resource_id, resource_type, "denied", "ownership_mismatch")

        return True, None

    def verify_resource_permission(
        self,
        user_id: str,
        resource_id: str,
        required_permission: str,
        user_permissions: Dict[str, Union[bool, List[str]]]
    ) -> tuple[bool, Optional[str]]:
        """
        Verify that the user has the required permission
        Returns: (is_authorized, error_message)
        """
        # Check cache first
        cache_key = f"{user_id}:{resource_id}:{required_permission}"
        if cache_key in self.authorization_cache:
            cached_entry = self.authorization_cache[cache_key]
            if datetime.now() < cached_entry['expires']:
                return cached_entry['result'], cached_entry['error']

        # Check permissions
        if required_permission not in user_permissions:
            error_msg = f"User {user_id} lacks permission: {required_permission}"
            self._cache_authorization(cache_key, False, error_msg)
            self._log_access(user_id, resource_id, "resource", "denied", f"missing_permission_{required_permission}")
            return False, error_msg

        permission_value = user_permissions[required_permission]

        # Handle boolean permissions
        if isinstance(permission_value, bool):
            if not permission_value:
                error_msg = f"User {user_id} permission denied: {required_permission}"
                self._cache_authorization(cache_key, False, error_msg)
                self._log_access(user_id, resource_id, "resource", "denied", required_permission)
                return False, error_msg

        # Handle list-based permissions (e.g., allowed resource IDs)
        elif isinstance(permission_value, list):
            if resource_id not in permission_value:
                error_msg = f"User {user_id} not authorized to access resource {resource_id}"
                self._cache_authorization(cache_key, False, error_msg)
                self._log_access(user_id, resource_id, "resource", "denied", f"not_in_permission_list")
                return False, error_msg

        # Authorization successful
        self._cache_authorization(cache_key, True, None)
        self._log_access(user_id, resource_id, "resource", "granted", required_permission)
        return True, None

    def verify_batch_resource_access(
        self,
        user_id: str,
        resource_ids: list,
        resource_owner_mapping: Dict[str, str]  # resource_id -> owner_id
    ) -> tuple[list, list]:
        """
        Verify batch resource access (for bulk operations)
        Returns: (authorized_ids, denied_ids)
        """
        authorized = []
        denied = []

        for resource_id in resource_ids:
            owner_id = resource_owner_mapping.get(str(resource_id))

            if owner_id is None:
                denied.append(resource_id)
                self._log_access(user_id, resource_id, "batch_resource", "denied", "not_found")
                continue

            if str(user_id) == str(owner_id):
                authorized.append(resource_id)
                self._log_access(user_id, resource_id, "batch_resource", "granted")
            else:
                denied.append(resource_id)
                self._log_access(user_id, resource_id, "batch_resource", "denied", "ownership_mismatch")

        return authorized, denied

    def verify_team_resource_access(
        self,
        user_id: str,
        resource_id: str,
        team_id: str,
        user_team_mapping: Dict[str, list]  # user_id -> [team_ids]
    ) -> tuple[bool, Optional[str]]:
        """
        Verify access to shared team resources
        Returns: (is_authorized, error_message)
        """
        user_teams = user_team_mapping.get(str(user_id), [])

        if not user_teams:
            error_msg = f"User {user_id} is not member of any team"
            self._log_access(user_id, resource_id, "team_resource", "denied", "not_in_team")
            return False, error_msg

        if str(team_id) not in user_teams:
            error_msg = f"User {user_id} is not member of team {team_id}"
            self._log_access(user_id, resource_id, "team_resource", "denied", "team_mismatch")
            return False, error_msg

        self._log_access(user_id, resource_id, "team_resource", "granted")
        return True, None

    def get_user_accessible_resources(
        self,
        user_id: str,
        all_resources: Dict[str, Dict[str, Any]],
        ownership_field: str = "owner_id"
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get only resources the user is authorized to access
        Filters out unauthorized resources
        """
        accessible = {}

        for resource_id, resource_data in all_resources.items():
            owner_id = resource_data.get(ownership_field)

            if str(user_id) == str(owner_id):
                accessible[resource_id] = resource_data

        return accessible

    def _cache_authorization(self, cache_key: str, result: bool, error: Optional[str]) -> None:
        """Cache authorization decision"""
        self.authorization_cache[cache_key] = {
            'result': result,
            'error': error,
            'expires': datetime.now() + timedelta(seconds=self.cache_ttl)
        }

    def _log_access(
        self,
        user_id: str,
        resource_id: str,
        resource_type: str,
        status: str,
        reason: str = ""
    ) -> None:
        """Log resource access attempt for audit trail"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'user_id': user_id,
            'resource_id': resource_id,
            'resource_type': resource_type,
            'status': status,
            'reason': reason
        }
        # In production, this would write to a secure audit log
        # print(json.dumps(log_entry))

    def clear_expired_cache(self) -> None:
        """Clear expired authorization cache entries"""
        now = datetime.now()
        expired_keys = [
            key for key, entry in self.authorization_cache.items()
            if now > entry['expires']
        ]

        for key in expired_keys:
            del self.authorization_cache[key]


# Example usage
if __name__ == '__main__':
    idor = IDORProtection()

    # Test ownership verification
    print("Ownership Verification Test:")
    result, error = idor.verify_resource_ownership(
        user_id="user123",
        resource_id="resource456",
        resource_owner_id="user123"
    )
    print(f"Result: {result}, Error: {error}")

    # Test permission verification
    print("\nPermission Verification Test:")
    user_perms = {
        'read': True,
        'write': False,
        'delete': False
    }
    result, error = idor.verify_resource_permission(
        user_id="user123",
        resource_id="resource456",
        required_permission="read",
        user_permissions=user_perms
    )
    print(f"Result: {result}, Error: {error}")

    # Test batch access
    print("\nBatch Resource Access Test:")
    resource_mapping = {
        "res1": "user123",
        "res2": "user456",
        "res3": "user123"
    }
    authorized, denied = idor.verify_batch_resource_access(
        user_id="user123",
        resource_ids=["res1", "res2", "res3"],
        resource_owner_mapping=resource_mapping
    )
    print(f"Authorized: {authorized}, Denied: {denied}")
