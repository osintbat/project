"""
XSS (Cross-Site Scripting) Protection Module
Provides comprehensive XSS prevention mechanisms
"""

import re
import html
import json
from typing import Any, Dict, List, Optional
from urllib.parse import quote, unquote


class XSSProtection:
    """Comprehensive XSS protection utilities"""

    # Dangerous HTML tags that should be removed
    DANGEROUS_TAGS = [
        'script', 'iframe', 'embed', 'object', 'applet',
        'link', 'meta', 'style', 'base', 'form'
    ]

    # Event handlers that can execute JavaScript
    EVENT_HANDLERS = [
        'onload', 'onunload', 'onclick', 'onmouseover', 'onmouseout',
        'onmousemove', 'onmouseenter', 'onmouseleave', 'onfocus', 'onblur',
        'onchange', 'onsubmit', 'oninput', 'onkeydown', 'onkeyup',
        'onerror', 'onabort', 'ondblclick', 'oncontextmenu',
        'ondrag', 'ondrop', 'onwheel', 'onscroll'
    ]

    # Protocols that can execute code
    DANGEROUS_PROTOCOLS = [
        'javascript:', 'data:', 'vbscript:', 'file:'
    ]

    @staticmethod
    def escape_html(text: str) -> str:
        """
        Escape HTML special characters to prevent XSS
        Converts: < > & " '
        """
        if not isinstance(text, str):
            return str(text)

        return html.escape(text, quote=True)

    @staticmethod
    def sanitize_html(html_content: str, allow_basic_tags: bool = False) -> str:
        """
        Sanitize HTML content by removing dangerous elements
        """
        if not isinstance(html_content, str):
            return ""

        # Remove script tags and content
        html_content = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.IGNORECASE | re.DOTALL)

        # Remove event handlers
        for handler in XSSProtection.EVENT_HANDLERS:
            pattern = rf'{handler}\s*=\s*["\']?[^"\'>]*["\']?'
            html_content = re.sub(pattern, '', html_content, flags=re.IGNORECASE)

        # Remove dangerous tags
        for tag in XSSProtection.DANGEROUS_TAGS:
            pattern = rf'<{tag}[^>]*>.*?</{tag}>'
            html_content = re.sub(pattern, '', html_content, flags=re.IGNORECASE | re.DOTALL)
            # Also remove self-closing versions
            pattern = rf'<{tag}[^>]*/>'
            html_content = re.sub(pattern, '', html_content, flags=re.IGNORECASE)

        # Remove javascript: protocol
        html_content = re.sub(r'javascript:', '', html_content, flags=re.IGNORECASE)
        html_content = re.sub(r'vbscript:', '', html_content, flags=re.IGNORECASE)
        html_content = re.sub(r'data:', '', html_content, flags=re.IGNORECASE)

        if not allow_basic_tags:
            # Remove all HTML tags
            html_content = re.sub(r'<[^>]+>', '', html_content)

        return html_content.strip()

    @staticmethod
    def url_encode(url: str) -> str:
        """
        URL encode unsafe characters in URLs
        Prevents URL-based XSS attacks
        """
        if not isinstance(url, str):
            return ""

        # First, check for dangerous protocols
        for protocol in XSSProtection.DANGEROUS_PROTOCOLS:
            if url.lower().startswith(protocol):
                return ""  # Reject the URL entirely

        # URL encode special characters
        return quote(url, safe=':/?#[]@!$&\'()*+,;=')

    @staticmethod
    def attribute_escape(value: str) -> str:
        """
        Escape values that will be used in HTML attributes
        """
        if not isinstance(value, str):
            return ""

        # HTML escape
        value = html.escape(value, quote=True)

        # Additional attribute-specific encoding
        value = value.replace('\n', '&#x0A;')
        value = value.replace('\r', '&#x0D;')
        value = value.replace('\t', '&#x09;')

        return value

    @staticmethod
    def json_escape(data: Any) -> str:
        """
        Safely convert data to JSON string with XSS protection
        """
        try:
            json_str = json.dumps(data)
            # Escape forward slashes to prevent closing script tags
            json_str = json_str.replace('</', '<\\/')
            return json_str
        except (TypeError, ValueError):
            return json.dumps(str(data))

    @staticmethod
    def css_escape(css_value: str) -> str:
        """
        Escape CSS values to prevent CSS injection
        """
        if not isinstance(css_value, str):
            return ""

        # Remove backslashes that could escape characters
        css_value = css_value.replace('\\', '')

        # Remove quotes
        css_value = css_value.replace('"', '').replace("'", '')

        # Reject javascript: protocol in URLs
        if 'javascript:' in css_value.lower():
            return ""

        return css_value

    @staticmethod
    def is_xss_suspicious(value: str, strict: bool = True) -> tuple[bool, Optional[str]]:
        """
        Check if a value contains suspicious XSS patterns
        Returns: (is_suspicious, reason)
        """
        if not isinstance(value, str):
            return False, None

        # Check for script tags
        if re.search(r'<script', value, re.IGNORECASE):
            return True, "Script tag detected"

        # Check for event handlers
        for handler in XSSProtection.EVENT_HANDLERS:
            if re.search(rf'{handler}\s*=', value, re.IGNORECASE):
                return True, f"Event handler detected: {handler}"

        # Check for iframe
        if re.search(r'<iframe', value, re.IGNORECASE):
            return True, "IFrame tag detected"

        # Check for embed
        if re.search(r'<embed', value, re.IGNORECASE):
            return True, "Embed tag detected"

        # Check for dangerous protocols
        for protocol in XSSProtection.DANGEROUS_PROTOCOLS:
            if protocol in value.lower():
                return True, f"Dangerous protocol detected: {protocol}"

        if strict:
            # In strict mode, also check for encoded versions
            # Check for double-encoded attacks
            if '%253c' in value.lower() or '%253e' in value.lower():
                return True, "Double-encoded HTML detected"

            # Check for Unicode escapes that could bypass filters
            if re.search(r'\\u003[ce]', value, re.IGNORECASE):
                return True, "Unicode escape detected"

        return False, None

    @staticmethod
    def sanitize_user_input(user_input: str, context: str = 'html') -> str:
        """
        Context-aware sanitization based on how input will be used
        context: 'html', 'attribute', 'url', 'css', 'javascript'
        """
        if not isinstance(user_input, str):
            return str(user_input)

        if context == 'html':
            return XSSProtection.escape_html(user_input)
        elif context == 'attribute':
            return XSSProtection.attribute_escape(user_input)
        elif context == 'url':
            return XSSProtection.url_encode(user_input)
        elif context == 'css':
            return XSSProtection.css_escape(user_input)
        elif context == 'javascript':
            return XSSProtection.json_escape(user_input)
        else:
            # Default to HTML escaping
            return XSSProtection.escape_html(user_input)

    @staticmethod
    def validate_csp_header() -> Dict[str, str]:
        """
        Generate Content Security Policy header for XSS mitigation
        """
        return {
            'Content-Security-Policy': (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "  # Adjust as needed
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self'; "
                "connect-src 'self'; "
                "frame-ancestors 'none'; "
                "base-uri 'self'; "
                "form-action 'self';"
            ),
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'X-XSS-Protection': '1; mode=block',
            'Referrer-Policy': 'strict-origin-when-cross-origin'
        }


# Example usage
if __name__ == '__main__':
    xss = XSSProtection()

    # Test HTML escaping
    print("HTML Escaping Test:")
    dangerous = "<script>alert('xss')</script>"
    safe = xss.escape_html(dangerous)
    print(f"Original: {dangerous}")
    print(f"Escaped: {safe}")

    # Test XSS detection
    print("\nXSS Detection Test:")
    suspicious_input = "onmouseover='alert(1)'"
    is_suspicious, reason = xss.is_xss_suspicious(suspicious_input)
    print(f"Suspicious: {is_suspicious}, Reason: {reason}")

    # Test HTML sanitization
    print("\nHTML Sanitization Test:")
    html_with_scripts = "<p>Hello</p><script>alert('xss')</script><img src=x onerror='alert(1)'>"
    sanitized = xss.sanitize_html(html_with_scripts)
    print(f"Sanitized: {sanitized}")

    # Test CSP headers
    print("\nCSP Headers Test:")
    csp_headers = xss.validate_csp_header()
    for header, value in csp_headers.items():
        print(f"{header}: {value}")
