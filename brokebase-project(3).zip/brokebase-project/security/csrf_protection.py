"""
CSRF (Cross-Site Request Forgery) Protection Module
Provides token-based and same-site cookie protection
"""

import secrets
import hashlib
from typing import Dict, Optional, Tuple
from datetime import datetime, timedelta


class CSRFProtection:
    """CSRF protection using tokens and secure cookies"""

    def __init__(self, token_ttl_minutes: int = 60):
        """
        Initialize CSRF protection
        token_ttl_minutes: Token time-to-live in minutes
        """
        self.token_ttl_minutes = token_ttl_minutes
        self.tokens: Dict[str, Dict] = {}

    def generate_token(self, session_id: str) -> str:
        """
        Generate a cryptographically secure CSRF token
        """
        # Generate random token
        token = secrets.token_urlsafe(32)

        # Store token with metadata
        self.tokens[token] = {
            'session_id': session_id,
            'created': datetime.now(),
            'expires': datetime.now() + timedelta(minutes=self.token_ttl_minutes)
        }

        return token

    def verify_token(self, token: str, session_id: str) -> Tuple[bool, Optional[str]]:
        """
        Verify CSRF token validity
        Returns: (is_valid, error_message)
        """
        # Check if token exists
        if token not in self.tokens:
            return False, "Invalid or missing CSRF token"

        token_data = self.tokens[token]

        # Check if token has expired
        if datetime.now() > token_data['expires']:
            del self.tokens[token]
            return False, "CSRF token has expired"

        # Verify session ID matches
        if token_data['session_id'] != session_id:
            return False, "CSRF token does not match session"

        return True, None

    def consume_token(self, token: str, session_id: str) -> Tuple[bool, Optional[str]]:
        """
        Verify and consume (delete) CSRF token
        Tokens should only be used once
        """
        is_valid, error = self.verify_token(token, session_id)

        if is_valid:
            # Consume the token
            if token in self.tokens:
                del self.tokens[token]

        return is_valid, error

    def get_csrf_headers() -> Dict[str, str]:
        """
        Get recommended HTTP headers for CSRF protection
        """
        return {
            'X-Frame-Options': 'SAMEORIGIN',
            'X-Content-Type-Options': 'nosniff',
            'X-XSS-Protection': '1; mode=block',
            'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
        }

    def cleanup_expired_tokens(self) -> int:
        """
        Remove expired tokens from storage
        Returns: number of tokens removed
        """
        now = datetime.now()
        expired_tokens = [
            token for token, data in self.tokens.items()
            if now > data['expires']
        ]

        for token in expired_tokens:
            del self.tokens[token]

        return len(expired_tokens)


class DoubleSubmitCookie:
    """
    Double Submit Cookie pattern for CSRF protection
    Works well with JavaScript frameworks
    """

    def __init__(self):
        self.cookies: Dict[str, str] = {}

    def generate_cookie_token(self, session_id: str) -> str:
        """
        Generate token for double-submit cookie pattern
        """
        token = secrets.token_urlsafe(32)
        self.cookies[session_id] = token
        return token

    def verify_cookie_token(self, session_id: str, submitted_token: str) -> Tuple[bool, Optional[str]]:
        """
        Verify that cookie token matches submitted token
        """
        if session_id not in self.cookies:
            return False, "No CSRF cookie found for session"

        cookie_token = self.cookies[session_id]

        if not self._compare_tokens(cookie_token, submitted_token):
            return False, "CSRF token mismatch"

        return True, None

    @staticmethod
    def _compare_tokens(token1: str, token2: str) -> bool:
        """
        Constant-time comparison to prevent timing attacks
        """
        if len(token1) != len(token2):
            return False

        result = 0
        for a, b in zip(token1, token2):
            result |= ord(a) ^ ord(b)

        return result == 0


class SameSiteCookie:
    """
    Same-Site cookie pattern for CSRF protection (modern browsers)
    """

    @staticmethod
    def get_cookie_attributes() -> Dict[str, any]:
        """
        Get recommended cookie attributes for SameSite protection
        """
        return {
            'HttpOnly': True,           # Prevent JavaScript access
            'Secure': True,             # Only send over HTTPS
            'SameSite': 'Strict',       # Prevent cross-site requests
            'Max-Age': 3600,            # 1 hour expiry
            'Domain': '.brokebase.com'  # Limit to domain
        }


# Example usage and testing
if __name__ == '__main__':
    csrf = CSRFProtection()

    # Test token generation and verification
    print("CSRF Token Protection Test:")
    session_id = "session123"
    token = csrf.generate_token(session_id)
    print(f"Generated token: {token[:20]}...")

    is_valid, error = csrf.verify_token(token, session_id)
    print(f"Verification result: Valid={is_valid}, Error={error}")

    # Test double-submit cookie
    print("\nDouble-Submit Cookie Test:")
    dsc = DoubleSubmitCookie()
    cookie_token = dsc.generate_cookie_token(session_id)
    print(f"Cookie token: {cookie_token[:20]}...")

    is_valid, error = dsc.verify_cookie_token(session_id, cookie_token)
    print(f"Cookie verification: Valid={is_valid}, Error={error}")

    # Test SameSite cookie attributes
    print("\nSameSite Cookie Attributes:")
    attrs = SameSiteCookie.get_cookie_attributes()
    for key, value in attrs.items():
        print(f"  {key}: {value}")
