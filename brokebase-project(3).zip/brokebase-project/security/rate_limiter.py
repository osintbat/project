"""
Rate Limiter Module
Prevents brute force attacks, DDoS, and abuse
Implements token bucket and exponential backoff algorithms
"""

import time
import hashlib
from typing import Dict, Optional, Tuple
from collections import defaultdict
from datetime import datetime, timedelta


class RateLimiter:
    """Token bucket based rate limiting with exponential backoff"""

    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        """
        Initialize rate limiter
        max_requests: Maximum requests allowed in the window
        window_seconds: Time window in seconds
        """
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests: Dict[str, list] = defaultdict(list)
        self.failed_attempts: Dict[str, Dict] = defaultdict(lambda: {'count': 0, 'last_attempt': None})

    def is_allowed(self, identifier: str) -> Tuple[bool, Optional[str]]:
        """
        Check if request is allowed for the given identifier
        identifier: IP address, user ID, or API key
        Returns: (is_allowed, error_message)
        """
        current_time = time.time()
        cutoff_time = current_time - self.window_seconds

        # Remove old requests outside the window
        self.requests[identifier] = [
            req_time for req_time in self.requests[identifier]
            if req_time > cutoff_time
        ]

        # Check if limit is exceeded
        if len(self.requests[identifier]) >= self.max_requests:
            oldest_request = min(self.requests[identifier])
            retry_after = int(oldest_request + self.window_seconds - current_time) + 1
            return False, f"Rate limit exceeded. Retry after {retry_after} seconds"

        # Add current request
        self.requests[identifier].append(current_time)
        return True, None

    def track_failed_attempt(self, identifier: str) -> Tuple[bool, Optional[str]]:
        """
        Track failed authentication attempts with exponential backoff
        Returns: (is_allowed, error_message)
        """
        current_time = datetime.now()
        attempt_info = self.failed_attempts[identifier]

        # Reset count if last attempt was more than 15 minutes ago
        if attempt_info['last_attempt'] is None or \
           (current_time - attempt_info['last_attempt']).total_seconds() > 900:
            attempt_info['count'] = 0

        attempt_info['count'] += 1
        attempt_info['last_attempt'] = current_time

        # Exponential backoff: 1s, 2s, 4s, 8s, 16s, 32s...
        backoff_seconds = 2 ** (attempt_info['count'] - 1)

        # Cap at 1 hour
        if backoff_seconds > 3600:
            backoff_seconds = 3600

        # After 5 failed attempts, enforce exponential backoff
        if attempt_info['count'] >= 5:
            lockout_until = attempt_info['last_attempt'] + timedelta(seconds=backoff_seconds)

            if current_time < lockout_until:
                remaining = int((lockout_until - current_time).total_seconds())
                return False, f"Too many failed attempts. Try again in {remaining} seconds"

        return True, None

    def get_remaining_requests(self, identifier: str) -> int:
        """Get remaining requests for identifier in current window"""
        current_time = time.time()
        cutoff_time = current_time - self.window_seconds

        self.requests[identifier] = [
            req_time for req_time in self.requests[identifier]
            if req_time > cutoff_time
        ]

        return max(0, self.max_requests - len(self.requests[identifier]))

    def reset_user(self, identifier: str) -> None:
        """Reset rate limit for specific user/IP"""
        if identifier in self.requests:
            del self.requests[identifier]
        if identifier in self.failed_attempts:
            del self.failed_attempts[identifier]

    def get_retry_after(self, identifier: str) -> Optional[int]:
        """Get seconds to wait before retrying"""
        current_time = time.time()
        cutoff_time = current_time - self.window_seconds

        self.requests[identifier] = [
            req_time for req_time in self.requests[identifier]
            if req_time > cutoff_time
        ]

        if len(self.requests[identifier]) >= self.max_requests:
            oldest_request = min(self.requests[identifier])
            return int(oldest_request + self.window_seconds - current_time) + 1

        return None


class DistributedRateLimiter:
    """
    Rate limiter for distributed systems using Redis or similar
    (Implementation uses in-memory store, but designed for Redis integration)
    """

    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.storage: Dict[str, Dict] = {}

    def is_allowed(self, identifier: str, current_time: Optional[float] = None) -> Tuple[bool, Optional[str]]:
        """
        Check rate limit using token bucket algorithm
        """
        if current_time is None:
            current_time = time.time()

        # Get or create token bucket
        if identifier not in self.storage:
            self.storage[identifier] = {
                'tokens': self.max_requests,
                'last_update': current_time
            }

        bucket = self.storage[identifier]

        # Calculate tokens to add based on time elapsed
        time_passed = current_time - bucket['last_update']
        tokens_to_add = (time_passed / self.window_seconds) * self.max_requests

        bucket['tokens'] = min(self.max_requests, bucket['tokens'] + tokens_to_add)
        bucket['last_update'] = current_time

        # Check if tokens available
        if bucket['tokens'] >= 1:
            bucket['tokens'] -= 1
            return True, None
        else:
            retry_after = 1 / ((self.max_requests / self.window_seconds) + 0.001)
            return False, f"Rate limited. Retry after {int(retry_after)} seconds"

    def reset(self, identifier: str) -> None:
        """Reset rate limiter for identifier"""
        if identifier in self.storage:
            del self.storage[identifier]


class APIKeyRateLimiter:
    """
    Specialized rate limiter for API keys with tiered limits
    """

    def __init__(self):
        self.rate_limits = {
            'free': {'requests': 100, 'window': 3600},      # 100 req/hour
            'starter': {'requests': 1000, 'window': 3600},   # 1000 req/hour
            'pro': {'requests': 10000, 'window': 3600},      # 10k req/hour
            'enterprise': {'requests': None, 'window': None}  # Unlimited
        }
        self.limiters: Dict[str, RateLimiter] = {}

    def check_rate_limit(self, api_key: str, tier: str) -> Tuple[bool, Optional[str]]:
        """Check rate limit for API key"""
        if tier not in self.rate_limits:
            return False, "Invalid API tier"

        if self.rate_limits[tier]['requests'] is None:
            # Enterprise tier - unlimited
            return True, None

        # Get or create limiter for this key
        if api_key not in self.limiters:
            limits = self.rate_limits[tier]
            self.limiters[api_key] = RateLimiter(
                max_requests=limits['requests'],
                window_seconds=limits['window']
            )

        limiter = self.limiters[api_key]
        return limiter.is_allowed(api_key)

    def get_usage_stats(self, api_key: str) -> Dict:
        """Get usage statistics for API key"""
        if api_key not in self.limiters:
            return {'requests_used': 0, 'remaining': 'unknown'}

        limiter = self.limiters[api_key]
        current_time = time.time()
        cutoff_time = current_time - limiter.window_seconds

        requests_in_window = [
            req_time for req_time in limiter.requests[api_key]
            if req_time > cutoff_time
        ]

        return {
            'requests_used': len(requests_in_window),
            'remaining': limiter.get_remaining_requests(api_key),
            'limit': limiter.max_requests,
            'window_seconds': limiter.window_seconds
        }


# Example usage
if __name__ == '__main__':
    # Test basic rate limiter
    print("Basic Rate Limiter Test:")
    limiter = RateLimiter(max_requests=5, window_seconds=10)

    for i in range(7):
        allowed, error = limiter.is_allowed("user123")
        print(f"Request {i+1}: Allowed={allowed}, Error={error}")
        time.sleep(0.1)

    # Test failed attempt tracking
    print("\nFailed Attempt Tracking Test:")
    for i in range(8):
        allowed, error = limiter.track_failed_attempt("attacker_ip")
        print(f"Attempt {i+1}: Allowed={allowed}, Error={error}")
        if not allowed:
            break

    # Test API key rate limiting
    print("\nAPI Key Rate Limiting Test:")
    api_limiter = APIKeyRateLimiter()

    allowed, error = api_limiter.check_rate_limit("key123", "starter")
    print(f"API Request: Allowed={allowed}, Error={error}")

    stats = api_limiter.get_usage_stats("key123")
    print(f"Usage Stats: {stats}")
