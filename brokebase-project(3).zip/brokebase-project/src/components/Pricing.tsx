import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Starter',
    price: '$29',
    period: '/month',
    description: 'For individual researchers',
    features: [
      'Up to 1,000 API calls/day',
      'Basic OSINT tools',
      'Email support',
      'Community access',
      'Basic reporting',
    ],
    cta: 'Start Free Trial',
    highlighted: false,
  },
  {
    name: 'Professional',
    price: '$99',
    period: '/month',
    description: 'For small teams & agencies',
    features: [
      'Up to 50,000 API calls/day',
      'All tools + advanced features',
      'Priority email support',
      'Team collaboration',
      'Advanced reporting & exports',
      'Custom integrations',
      'API access',
    ],
    cta: 'Get Started',
    highlighted: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For large organizations',
    features: [
      'Unlimited API calls',
      'Custom tool development',
      '24/7 phone & email support',
      'Dedicated account manager',
      'White-label options',
      'On-premise deployment',
      'SLA guarantee (99.99%)',
    ],
    cta: 'Contact Sales',
    highlighted: false,
  },
];

export function Pricing() {
  return (
    <section className="section-container bg-canvas py-16 md:py-24">
      <div className="max-w-page mx-auto px-16 space-y-16">
        {/* Section Header */}
        <div className="space-y-16 text-center max-w-3xl mx-auto">
          <h2 className="heading-lg text-ink">
            Transparent Pricing
          </h2>
          <p className="text-subheading text-mid-gray">
            Choose the plan that fits your needs. No hidden fees, cancel anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-24">
          {plans.map((plan, idx) => (
            <div
              key={idx}
              className={`card ${
                plan.highlighted
                  ? 'md:scale-105 border-ink shadow-subtle'
                  : ''
              } transition-all`}
            >
              {plan.highlighted && (
                <div className="absolute -top-12 left-1/2 transform -translate-x-1/2">
                  <span className="badge">Most Popular</span>
                </div>
              )}

              <div className="space-y-16">
                <div>
                  <h3 className="heading-sm mb-4">{plan.name}</h3>
                  <p className="text-body text-mid-gray mb-16">{plan.description}</p>
                  <div className="flex items-baseline gap-4">
                    <span className="text-heading font-semibold">{plan.price}</span>
                    {plan.period && <span className="text-body text-mid-gray">{plan.period}</span>}
                  </div>
                </div>

                {/* CTA Button */}
                <button className={plan.highlighted ? 'btn-primary w-full' : 'btn-secondary w-full'}>
                  {plan.cta}
                </button>

                {/* Features List */}
                <div className="space-y-12 border-t border-hairline pt-16">
                  {plan.features.map((feature, featureIdx) => (
                    <div key={featureIdx} className="flex gap-12 items-start">
                      <Check size={20} className="text-ink mt-2 flex-shrink-0" />
                      <span className="text-body text-ink">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Snippet */}
        <div className="border-t border-hairline pt-64 space-y-16">
          <h3 className="heading text-center">Frequently Asked Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-24 max-w-3xl mx-auto">
            <div className="space-y-8">
              <h4 className="heading-sm">Can I upgrade anytime?</h4>
              <p className="text-body text-mid-gray">
                Yes, upgrade or downgrade your plan at any time. Changes take effect immediately.
              </p>
            </div>
            <div className="space-y-8">
              <h4 className="heading-sm">Is there a free trial?</h4>
              <p className="text-body text-mid-gray">
                Yes, all plans come with a 14-day free trial. No credit card required.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
