import { Copy } from 'lucide-react';
import { useState } from 'react';

interface Tool {
  name: string;
  description: string;
  example: string;
  category: 'reconnaissance' | 'analysis' | 'reporting';
}

const tools: Tool[] = [
  {
    name: 'IP Geolocation Lookup',
    description: 'Identify geographic location, ISP, and hosting provider for any IP address',
    example: 'GET /api/v1/ip/geolocation?ip=8.8.8.8',
    category: 'reconnaissance',
  },
  {
    name: 'WHOIS Data Extraction',
    description: 'Extract detailed WHOIS information for domains with historical records',
    example: 'GET /api/v1/whois?domain=example.com',
    category: 'reconnaissance',
  },
  {
    name: 'SSL Certificate Analysis',
    description: 'Deep dive into SSL certificates, alternative names, and issuer information',
    example: 'POST /api/v1/ssl/analyze',
    category: 'analysis',
  },
  {
    name: 'Breach Database Query',
    description: 'Search across millions of compromised records with detailed exposure analysis',
    example: 'GET /api/v1/breaches/search?email=user@domain.com',
    category: 'analysis',
  },
  {
    name: 'Web Archive Timeline',
    description: 'Access historical snapshots of websites and track changes over time',
    example: 'GET /api/v1/archive/timeline?url=example.com',
    category: 'reconnaissance',
  },
  {
    name: 'Threat Report Generator',
    description: 'Automatically generate comprehensive threat intelligence reports',
    example: 'POST /api/v1/reports/generate',
    category: 'reporting',
  },
];

export function Tools() {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'reconnaissance' | 'analysis' | 'reporting'>('all');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const filteredTools =
    selectedCategory === 'all' ? tools : tools.filter((tool) => tool.category === selectedCategory);

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <section id="tools" className="section-container bg-canvas py-16 md:py-24">
      <div className="max-w-page mx-auto px-16 space-y-16">
        {/* Section Header */}
        <div className="space-y-16">
          <h2 className="heading-lg text-ink">
            Advanced OSINT Tools
          </h2>
          <p className="text-subheading text-mid-gray max-w-2xl">
            Industry-leading tools for reconnaissance, analysis, and threat reporting. RESTful API with
            comprehensive documentation.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-12">
          {(['all', 'reconnaissance', 'analysis', 'reporting'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-16 py-8 rounded-lg text-sm font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-ink text-paper'
                  : 'bg-paper border border-hairline text-ink hover:bg-surface-alt'
              }`}
            >
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-24">
          {filteredTools.map((tool, idx) => (
            <div key={idx} className="card bg-transparent group">
              <div className="flex items-start justify-between mb-12">
                <h3 className="heading-sm flex-1">{tool.name}</h3>
                <span className="badge-soft text-xs ml-8">{tool.category}</span>
              </div>

              <p className="text-body text-mid-gray mb-16">{tool.description}</p>

              {/* Code Example */}
              <div className="bg-ink rounded-md p-12 mb-12 relative group/code">
                <pre className="text-xs text-paper font-mono overflow-x-auto">
                  <code>{tool.example}</code>
                </pre>
                <button
                  onClick={() => handleCopy(tool.example, idx)}
                  className="absolute top-8 right-8 p-6 bg-ink-soft rounded opacity-0 group-hover/code:opacity-100 transition-opacity"
                >
                  {copiedIndex === idx ? (
                    <span className="text-xs text-paper">Copied!</span>
                  ) : (
                    <Copy size={16} className="text-paper" />
                  )}
                </button>
              </div>

              {/* View Docs Link */}
              <a href="#" className="text-sm text-ink font-medium hover:text-ink-soft">
                View Documentation →
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
