import { Globe, Users, Database, Shield, Search, Zap } from 'lucide-react';
import BorderGlow from './ui/BorderGlow';

const features = [
  {
    icon: Globe,
    title: 'Domain Intelligence',
    description: 'Advanced domain enumeration, DNS records analysis, and subdomain discovery with real-time monitoring.',
  },
  {
    icon: Users,
    title: 'Social Media Footprint',
    description: 'Comprehensive social media profiling across all major platforms with historical data tracking.',
  },
  {
    icon: Database,
    title: 'Data Breach Search',
    description: 'Search millions of exposed records from public breaches with detailed vulnerability assessment.',
  },
  {
    icon: Shield,
    title: 'Security Assessment',
    description: 'Automated vulnerability scanning and security posture analysis with comprehensive reporting.',
  },
  {
    icon: Search,
    title: 'Email & Reverse Lookup',
    description: 'Advanced email verification, reverse email search, and contact intelligence across databases.',
  },
  {
    icon: Zap,
    title: 'Real-Time Alerts',
    description: 'Instant notifications for new mentions, breaches, and security events related to your targets.',
  },
];

export function Features() {
  return (
    <section id="features" className="section-container pt-64 md:pt-96">
      <div className="space-y-16">
        {/* Section Header */}
        <div className="space-y-16 text-center max-w-3xl mx-auto">
          <h2 className="heading-lg text-ink">
            <span>Powerful Intelligence</span>
            <br />
            Tools at Your Fingertips
          </h2>
          <p className="text-subheading text-mid-gray">
            Access the most advanced OSINT toolkit built for professionals who need actionable intelligence fast.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-24">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <BorderGlow
                key={idx}
                backgroundColor="transparent"
                glowColor="0 0 75"
                borderRadius={24}
                className="group"
                colors={['#9ca3af', '#6b7280', '#4b5563']}
              >
                <div className="p-20">
                  <div className="mb-16">
                    <div className="w-48 h-48 rounded-lg flex items-center justify-center group-hover:shadow-lg transition-all">
                      <Icon size={28} className="text-ink" />
                    </div>
                  </div>
                  <h3 className="heading-sm mb-8">{feature.title}</h3>
                  <p className="text-body text-mid-gray leading-relaxed">{feature.description}</p>

                  {/* Hover indicator */}
                  <div className="mt-12 pt-12 border-t border-hairline opacity-0 group-hover:opacity-100 transition-opacity">
                    <a href="#" className="text-sm text-ink font-medium hover:text-ink-soft">
                      Learn More →
                    </a>
                  </div>
                </div>
              </BorderGlow>
            );
          })}
        </div>
      </div>
    </section>
  );
}
