/**
 * Security Utilities for Input Validation and Sanitization
 * Implements OWASP best practices for input validation and output encoding
 */

/**
 * Validates and sanitizes input to prevent XSS attacks
 * @param input - Raw user input
 * @returns Sanitized safe string
 */
export function sanitizeInput(input: string): string {
  if (typeof input !== 'string') return '';
  
  // Remove potentially dangerous characters
  let sanitized = input
    .replace(/[<>]/g, '') // Remove HTML brackets
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+\s*=/gi, '') // Remove inline event handlers
    .replace(/data:text\/html/gi, '') // Remove data:text/html
    .trim();
  
  // Limit length to prevent DoS
  const MAX_LENGTH = 10000;
  if (sanitized.length > MAX_LENGTH) {
    sanitized = sanitized.substring(0, MAX_LENGTH);
  }
  
  return sanitized;
}

/**
 * Validates URL to prevent open redirect vulnerabilities
 * @param url - URL to validate
 * @returns Boolean indicating if URL is safe
 */
export function isValidUrl(url: string): boolean {
  try {
    const parsedUrl = new URL(url);
    
    // Allow only http and https protocols
    if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
      return false;
    }
    
    // Prevent javascript: and data: protocols
    if (url.startsWith('javascript:') || url.startsWith('data:')) {
      return false;
    }
    
    // Prevent open redirects by checking if hostname matches expected domains
    const allowedDomains = ['www.brokebase.com', 'brokebase.com', 'localhost'];
    if (!allowedDomains.includes(parsedUrl.hostname)) {
      return false;
    }
    
    return true;
  } catch {
    return false;
  }
}

/**
 * Validates email format
 * @param email - Email to validate
 * @returns Boolean indicating if email is valid
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
}

/**
 * Validates and sanitizes domain name
 * @param domain - Domain to validate
 * @returns Sanitized domain or empty string if invalid
 */
export function sanitizeDomain(domain: string): string {
  if (typeof domain !== 'string') return '';
  
  // Remove any path traversal attempts
  const sanitized = domain
    .replace(/\.\./g, '') // Remove directory traversal
    .replace(/[\/\\]/g, '') // Remove path separators
    .replace(/[^a-zA-Z0-9.-]/g, '') // Allow only alphanumeric, dots, hyphens
    .toLowerCase()
    .trim();
  
  // Validate domain format
  const domainRegex = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/;
  
  if (!domainRegex.test(sanitized) || sanitized.length > 253) {
    return '';
  }
  
  return sanitized;
}

/**
 * Validates IP address format
 * @param ip - IP address to validate
 * @returns Boolean indicating if IP is valid
 */
export function isValidIP(ip: string): boolean {
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const ipv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  return ipv4Regex.test(ip) || ipv6Regex.test(ip);
}

/**
 * Validates numeric input to prevent injection
 * @param value - Value to validate
 * @returns Boolean indicating if value is a safe number
 */
export function isSafeNumber(value: any): boolean {
  if (typeof value === 'number') {
    return Number.isFinite(value) && !Number.isNaN(value);
  }
  if (typeof value === 'string') {
    const parsed = parseFloat(value);
    return !isNaN(parsed) && Number.isFinite(parsed);
  }
  return false;
}

/**
 * Validates and limits numeric input range
 * @param value - Value to validate
 * @param min - Minimum allowed value
 * @param max - Maximum allowed value
 * @returns Clamped safe number
 */
export function clampNumber(value: any, min: number, max: number): number {
  const num = Number(value);
  if (isNaN(num) || !Number.isFinite(num)) {
    return min;
  }
  return Math.max(min, Math.min(max, num));
}

/**
 * Escapes HTML to prevent XSS
 * @param unsafe - Unsafe string
 * @returns Escaped safe string
 */
export function escapeHtml(unsafe: string): string {
  if (typeof unsafe !== 'string') return '';
  
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

/**
 * Validates filename to prevent path traversal
 * @param filename - Filename to validate
 * @returns Sanitized safe filename
 */
export function sanitizeFilename(filename: string): string {
  if (typeof filename !== 'string') return '';
  
  // Remove path traversal characters
  let sanitized = filename
    .replace(/\.\./g, '')
    .replace(/[\/\\]/g, '')
    .replace(/^\.+/, '') // Remove leading dots
    .trim();
  
  // Remove dangerous characters
  sanitized = sanitized.replace(/[<>:"|?*]/g, '');
  
  // Limit length
  const MAX_FILENAME_LENGTH = 255;
  if (sanitized.length > MAX_FILENAME_LENGTH) {
    sanitized = sanitized.substring(0, MAX_FILENAME_LENGTH);
  }
  
  // Ensure it's not empty after sanitization
  if (!sanitized) {
    return 'file';
  }
  
  return sanitized;
}

/**
 * Validates JSON string structure
 * @param jsonStr - JSON string to validate
 * @returns Parsed object or null if invalid
 */
export function parseJsonSafely<T>(jsonStr: string): T | null {
  try {
    return JSON.parse(jsonStr) as T;
  } catch {
    return null;
  }
}

/**
 * Rate limiter implementation
 */
class RateLimiter {
  private requests: Map<string, number[]> = new Map();
  private windowMs: number;
  private maxRequests: number;

  constructor(windowMs: number = 60000, maxRequests: number = 100) {
    this.windowMs = windowMs;
    this.maxRequests = maxRequests;
  }

  isAllowed(identifier: string): boolean {
    const now = Date.now();
    const windowStart = now - this.windowMs;
    
    const requests = this.requests.get(identifier) || [];
    const validRequests = requests.filter(time => time > windowStart);
    
    if (validRequests.length >= this.maxRequests) {
      return false;
    }
    
    validRequests.push(now);
    this.requests.set(identifier, validRequests);
    return true;
  }

  reset(identifier: string): void {
    this.requests.delete(identifier);
  }
}

export const rateLimiter = new RateLimiter();

/**
 * Content Security Policy configuration
 */
export const CSP_CONFIG = {
  'default-src': "'self'",
  'script-src': "'self' 'unsafe-inline' 'unsafe-eval'", // Allow inline scripts for React
  'style-src': "'self' 'unsafe-inline'", // Allow inline styles for Tailwind
  'img-src': "'self' data: https:",
  'font-src': "'self' https://fonts.gstatic.com https://fonts.googleapis.com",
  'connect-src': "'self' https://*.googleapis.com",
  'frame-src': "'none'",
  'object-src': "'none'",
  'base-uri': "'self'",
  'form-action': "'self'",
  'frame-ancestors': "'none'",
  'upgrade-insecure-requests': '1',
};

/**
 * Generates CSP meta tag content
 */
export function generateCSPMeta(): string {
  return Object.entries(CSP_CONFIG)
    .map(([directive, value]) => `${directive} ${value}`)
    .join('; ');
}