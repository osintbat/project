import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Footer } from './components/Footer';
import SmoothScroll from './components/SmoothScroll';

function App() {
  return (
    <div className="min-h-screen bg-paper">
      <SmoothScroll />
      <Header />
      <Hero />
      <Features />
      <Footer />
    </div>
  );
}

export default App;
