/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Monochromatic palette
        canvas: '#f5f5f5',
        paper: '#ffffff',
        'surface-alt': '#fafafa',
        ink: '#0a0a0a',
        'ink-soft': '#171717',
        'mid-gray': '#737373',
        hairline: '#e5e5e5',
        ember: '#e7000b',
      },
      fontFamily: {
        geist: [
          'Geist',
          'ui-sans-serif',
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Roboto',
          'sans-serif',
        ],
      },
      fontSize: {
        caption: ['12px', { lineHeight: '1.33', letterSpacing: '0.6px' }],
        body: ['14px', { lineHeight: '1.43' }],
        'body-lg': ['16px', { lineHeight: '1.5' }],
        subheading: ['18px', { lineHeight: '1.56' }],
        'heading-sm': ['24px', { lineHeight: '1.33', letterSpacing: '-0.6px' }],
        heading: ['30px', { lineHeight: '1.2', letterSpacing: '-0.75px' }],
        'heading-lg': ['36px', { lineHeight: '1.11', letterSpacing: '-0.9px' }],
        display: ['48px', { lineHeight: '1.1', letterSpacing: '-2.4px' }],
      },
      borderRadius: {
        sm: '6px',
        md: '10px',
        lg: '14px',
        xl: '18px',
        '2xl': '24px',
      },
      boxShadow: {
        subtle: 'oklab(0.145 -0.00000143796 0.00000340492 / 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 1px 3px 0px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px',
      },
      backgroundImage: {
        'gradient-wolf': 'linear-gradient(135deg, #0a0a0a 0%, #171717 50%, #0a0a0a 100%)',
        'gradient-wolf-hover': 'linear-gradient(135deg, #171717 0%, #272c30 50%, #171717 100%)',
      },
      spacing: {
        '4': '4px',
        '8': '8px',
        '12': '12px',
        '16': '16px',
        '20': '20px',
        '24': '24px',
        '48': '48px',
      },
      maxWidth: {
        page: '1280px',
      },
    },
  },
  plugins: [],
}
