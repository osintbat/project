import { CheckCircle2, Lock, Eye, AlertCircle, Key, Shield } from 'lucide-react';

const securityFeatures = [
  {
    icon: Lock,
    title: 'End-to-End Encryption',
    description: 'All data in transit and at rest uses military-grade AES-256 encryption',
  },
  {
    icon: Key,
    title: 'API Key Management',
    description: 'Secure API key rotation, scoping, and rate limiting with audit logs',
  },
  {
    icon: Shield,
    title: 'WAF & DDoS Protection',
    description: 'Cloudflare Enterprise protection against all attack vectors',
  },
  {
    icon: Eye,
    title: 'Access Control',
    description: '2FA, SSO, RBAC, and granular permission management',
  },
  {
    icon: AlertCircle,
    title: 'Incident Response',
    description: '24/7 security monitoring with automated threat detection',
  },
  {
    icon: CheckCircle2,
    title: 'Compliance & Audits',
    description: 'SOC 2 Type II, GDPR, CCPA, and full audit trail compliance',
  },
];

export function Security() {
  return (
    <section className="section-container py-64 md:py-96">
      <div className="space-y-64 max-w-page mx-auto px-16">
        {/* Header */}
        <div className="space-y-16">
          <div className="inline-block">
            <span className="badge">Enterprise Grade Security</span>
          </div>
          <h2 className="heading-lg gradient-wolf-text">
            Security You Can Trust
          </h2>
          <p className="text-subheading text-mid-gray max-w-3xl">
            Built with security-first architecture. Every request is validated, sanitized, and protected against
            common attack vectors including SQL injection, XSS, CSRF, and path traversal.
          </p>
        </div>

        {/* Security Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-24">
          {securityFeatures.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="card">
                <div className="w-48 h-48 bg-canvas rounded-lg flex items-center justify-center mb-12 group-hover:gradient-wolf transition-all">
                  <Icon size={28} className="text-ink" />
                </div>
                <h3 className="heading-sm mb-8">{feature.title}</h3>
                <p className="text-body text-mid-gray">{feature.description}</p>
              </div>
            );
          })}
        </div>

        {/* Security Statement */}
        <div className="bg-paper border border-hairline rounded-2xl p-24 space-y-16">
          <h3 className="heading gradient-wolf-text">Our Security Commitment</h3>
          <div className="space-y-12 text-body text-mid-gray">
            <p>
              Brokebase implements defense-in-depth strategies with multiple layers of protection:
            </p>
            <ul className="space-y-8 list-none">
              <li className="flex gap-12 items-start">
                <CheckCircle2 size={20} className="text-ink mt-2 flex-shrink-0" />
                <span>
                  <strong>Input Validation:</strong> All user inputs are validated against strict schemas and sanitized
                  to prevent injection attacks.
                </span>
              </li>
              <li className="flex gap-12 items-start">
                <CheckCircle2 size={20} className="text-ink mt-2 flex-shrink-0" />
                <span>
                  <strong>IDOR Prevention:</strong> Strict authorization checks ensure users can only access their own
                  data.
                </span>
              </li>
              <li className="flex gap-12 items-start">
                <CheckCircle2 size={20} className="text-ink mt-2 flex-shrink-0" />
                <span>
                  <strong>XSS Protection:</strong> Content Security Policy headers and output encoding prevent script
                  injection.
                </span>
              </li>
              <li className="flex gap-12 items-start">
                <CheckCircle2 size={20} className="text-ink mt-2 flex-shrink-0" />
                <span>
                  <strong>Path Traversal Prevention:</strong> Strict path validation and normalization prevent directory
                  traversal.
                </span>
              </li>
              <li className="flex gap-12 items-start">
                <CheckCircle2 size={20} className="text-ink mt-2 flex-shrink-0" />
                <span>
                  <strong>Rate Limiting:</strong> Sophisticated rate limiting with exponential backoff prevents brute
                  force attacks.
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
