import { Github, Twitter, Linkedin, Mail } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-ink text-paper">
      <div className="max-w-page mx-auto px-16 py-64 md:py-96">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-32 mb-64 pb-64 border-b border-ink-soft">
          {/* Company Info */}
          <div className="space-y-12">
            <h3 className="heading-sm text-paper">Brokebase</h3>
            <p className="text-body text-mid-gray">
              Open-source OSINT platform for security research and intelligence gathering.
            </p>
            <div className="flex gap-12">
              <a href="#" className="hover:text-paper transition-colors">
                <Github size={20} />
              </a>
              <a href="#" className="hover:text-paper transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="hover:text-paper transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="hover:text-paper transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Product Links */}
          <div className="space-y-12">
            <h4 className="heading-sm text-paper">Product</h4>
            <ul className="space-y-8 text-body text-mid-gray">
              <li>
                <a href="#features" className="hover:text-paper transition-colors">
                  Features
                </a>
              </li>
              <li>
                <a href="#tools" className="hover:text-paper transition-colors">
                  Tools
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-paper transition-colors">
                  Pricing
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Changelog
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-12">
            <h4 className="heading-sm text-paper">Resources</h4>
            <ul className="space-y-8 text-body text-mid-gray">
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Documentation
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  API Reference
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Community
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-12">
            <h4 className="heading-sm text-paper">Legal</h4>
            <ul className="space-y-8 text-body text-mid-gray">
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Security Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-paper transition-colors">
                  Responsible Disclosure
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-16 text-body text-mid-gray">
          <p>&copy; {currentYear} Brokebase. All rights reserved.</p>
          <div className="flex gap-24 text-sm">
            <a href="#" className="hover:text-paper transition-colors">
              Status
            </a>
            <a href="#" className="hover:text-paper transition-colors">
              Contact
            </a>
            <a href="#" className="hover:text-paper transition-colors">
              Support
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
