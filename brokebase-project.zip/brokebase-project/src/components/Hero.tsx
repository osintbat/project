import { ArrowRight, Zap } from 'lucide-react';

export function Hero() {
  return (
    <section className="section-container pt-80 md:pt-120">
      <div className="space-y-32 max-w-4xl">
        {/* Badge */}
        <div className="inline-block">
          <span className="badge-outline flex items-center gap-8">
            <Zap size={14} className="text-ember" />
            Powered by Advanced Intelligence
          </span>
        </div>

        {/* Main Headline */}
        <div className="space-y-16">
          <h1 className="heading-display">
            <span className="gradient-wolf-text">Open Source</span>
            <br />
            Intelligence Platform
          </h1>

          <p className="text-subheading text-mid-gray max-w-2xl leading-relaxed">
            Brokebase is a modern OSINT platform designed for security researchers, investigators,
            and cybersecurity professionals. Gather, analyze, and protect.
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-12 pt-24">
          <button className="btn-primary flex items-center justify-center gap-8 group">
            Start Free Trial
            <ArrowRight size={16} className="group-hover:translate-x-8 transition-transform" />
          </button>
          <button className="btn-outline flex items-center justify-center gap-8">
            Learn More
          </button>
        </div>

        {/* Social Proof */}
        <div className="pt-32 border-t border-hairline">
          <p className="text-caption text-mid-gray uppercase tracking-wider mb-12">
            Trusted by researchers & professionals
          </p>
          <div className="flex flex-wrap gap-16">
            <div className="text-sm text-ink font-medium">500+ Active Users</div>
            <div className="text-sm text-ink font-medium">2M+ Records Indexed</div>
            <div className="text-sm text-ink font-medium">99.9% Uptime</div>
          </div>
        </div>
      </div>
    </section>
  );
}
