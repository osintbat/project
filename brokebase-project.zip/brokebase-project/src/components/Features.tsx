import { Globe, Users, Database, Shield, Search, Zap } from 'lucide-react';

const features = [
  {
    icon: Globe,
    title: 'Domain Intelligence',
    description: 'Advanced domain enumeration, DNS records analysis, and subdomain discovery with real-time monitoring.',
  },
  {
    icon: Users,
    title: 'Social Media Footprint',
    description: 'Comprehensive social media profiling across all major platforms with historical data tracking.',
  },
  {
    icon: Database,
    title: 'Data Breach Search',
    description: 'Search millions of exposed records from public breaches with detailed vulnerability assessment.',
  },
  {
    icon: Shield,
    title: 'Security Assessment',
    description: 'Automated vulnerability scanning and security posture analysis with comprehensive reporting.',
  },
  {
    icon: Search,
    title: 'Email & Reverse Lookup',
    description: 'Advanced email verification, reverse email search, and contact intelligence across databases.',
  },
  {
    icon: Zap,
    title: 'Real-Time Alerts',
    description: 'Instant notifications for new mentions, breaches, and security events related to your targets.',
  },
];

export function Features() {
  return (
    <section id="features" className="section-container">
      <div className="space-y-64">
        {/* Section Header */}
        <div className="space-y-16 text-center max-w-3xl mx-auto">
          <h2 className="heading-lg">
            <span className="gradient-wolf-text">Powerful Intelligence</span>
            <br />
            Tools at Your Fingertips
          </h2>
          <p className="text-subheading text-mid-gray">
            Access the most advanced OSINT toolkit built for professionals who need actionable intelligence fast.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-24">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="card group hover:border-ink transition-all">
                <div className="mb-16">
                  <div className="w-48 h-48 gradient-wolf rounded-lg flex items-center justify-center group-hover:shadow-lg transition-all">
                    <Icon size={28} className="text-paper" />
                  </div>
                </div>
                <h3 className="heading-sm mb-8">{feature.title}</h3>
                <p className="text-body text-mid-gray leading-relaxed">{feature.description}</p>

                {/* Hover indicator */}
                <div className="mt-12 pt-12 border-t border-hairline opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href="#" className="text-sm text-ink font-medium hover:text-ink-soft">
                    Learn More →
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
