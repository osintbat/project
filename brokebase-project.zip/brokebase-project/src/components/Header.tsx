import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-paper border-b border-hairline">
      <div className="max-w-page mx-auto px-16 py-16 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center gap-8">
          <a href="/" className="flex items-center gap-8">
            <div className="w-32 h-32 gradient-wolf rounded-md flex items-center justify-center">
              <span className="text-paper font-semibold text-body">BrokenBase</span>
            </div>
            <span className="gradient-wolf-text font-semibold text-heading-sm hidden md:block">OSINT</span>
          </a>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-24">
          <a href="#features" className="text-body text-mid-gray hover:text-ink transition-colors">
            Features
          </a>
          <a href="#tools" className="text-body text-mid-gray hover:text-ink transition-colors">
            Tools
          </a>
          <a href="#about" className="text-body text-mid-gray hover:text-ink transition-colors">
            About
          </a>
        </nav>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-12">
          <button className="btn-secondary text-sm">Sign In</button>
          <button className="btn-primary text-sm">Get Started</button>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-hairline bg-canvas">
          <div className="px-16 py-12 space-y-12">
            <a href="#features" className="block text-body text-ink hover:text-mid-gray">
              Features
            </a>
            <a href="#tools" className="block text-body text-ink hover:text-mid-gray">
              Tools
            </a>
            <a href="#about" className="block text-body text-ink hover:text-mid-gray">
              About
            </a>
            <div className="flex flex-col gap-8 pt-8">
              <button className="btn-secondary text-sm w-full">Sign In</button>
              <button className="btn-primary text-sm w-full">Get Started</button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
