import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Tools } from './components/Tools';
import { Security } from './components/Security';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-paper">
      <Header />
      <Hero />
      <Features />
      <Tools />
      <Security />
      <Pricing />
      <Footer />
    </div>
  );
}

export default App;
