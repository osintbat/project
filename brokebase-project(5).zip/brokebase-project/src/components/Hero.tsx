import { ArrowRight } from 'lucide-react';
import { Globe } from './ui/globe';

export function Hero() {
  return (
    <section className="relative section-container pt-48 md:pt-64 pb-8 min-h-[600px] overflow-hidden">
      {/* Globe - Centered on full section, independent from text column */}
      <div className="absolute inset-0 w-full h-full flex items-center justify-center opacity-30 pointer-events-none">
        <Globe />
      </div>

      <div className="relative max-w-6xl mx-auto">
        {/* Main Content */}
        <div className="space-y-16 max-w-4xl">
          {/* Main Headline */}
          <div className="space-y-16">
            <h1 className="heading-display text-ink opacity-80">
              <span>Open Source</span>
              <br />
              Intelligence Platform
            </h1>

            <p className="text-subheading text-mid-gray max-w-2xl leading-relaxed opacity-70">
              Brokebase is a modern OSINT platform designed for security researchers, investigators,
              and cybersecurity professionals. Gather, analyze, and protect.
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-12 pt-24">
            <button className="btn-primary flex items-center justify-center gap-8 group opacity-80">
              Start Free Trial
              <ArrowRight size={16} className="group-hover:translate-x-8 transition-transform" />
            </button>
            <button className="btn-outline flex items-center justify-center gap-8 opacity-80">
              Learn More
            </button>
          </div>

          {/* Social Proof */}
          <div className="pt-32 border-t border-hairline opacity-70">
            <p className="text-caption text-mid-gray uppercase tracking-wider mb-12">
              Trusted by researchers & professionals
            </p>
            <div className="flex flex-wrap gap-16">
              <div className="text-sm text-ink font-medium">500+ Active Users</div>
              <div className="text-sm text-ink font-medium">2M+ Records Indexed</div>
              <div className="text-sm text-ink font-medium">99.9% Uptime</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
