import { SignUp } from "@clerk/clerk-react";
import { AuthShell } from "../components/AuthShell";
import { appAppearance } from "../lib/clerkAppearance";

export default function RegisterPage() {
  return (
    <AuthShell
      eyebrow="New Identity"
      title="Create your account."
      subtitle="A few seconds to set up. Verified access only — no shared credentials."
    >
      <SignUp
        routing="path"
        path="/register"
        signInUrl="/login"
        appearance={appAppearance}
      />
    </AuthShell>
  );
}
