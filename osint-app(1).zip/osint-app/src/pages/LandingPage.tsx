import { Navbar } from "../components/landing/Navbar";
import { Hero } from "../components/landing/Hero";
import { FeatureGrid } from "../components/landing/FeatureGrid";
import { StatsBand } from "../components/landing/StatsBand";
import { CTASection, Footer } from "../components/landing/CTASection";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black">
      <Navbar />
      <Hero />
      <FeatureGrid />
      <StatsBand />
      <CTASection />
      <Footer />
    </div>
  );
}
