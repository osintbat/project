import type { Appearance } from "@clerk/types";

export const appAppearance: Appearance = {
  variables: {
    colorPrimary: "#ffffff",
    colorBackground: "#000000",
    colorText: "#fafafa",
    colorTextSecondary: "rgba(255,255,255,0.5)",
    colorInputBackground: "rgba(255,255,255,0.02)",
    colorInputText: "#fafafa",
    colorDanger: "#ef4444",
    borderRadius: "10px",
    fontFamily:
      "'Geist', 'Inter Variable', ui-sans-serif, system-ui, sans-serif",
  },
  elements: {
    card: "bg-black border border-white/10 shadow-none",
    headerTitle: "text-white",
    headerSubtitle: "text-white/50",
    formButtonPrimary:
      "bg-white text-black hover:bg-white/90 rounded-lg font-medium normal-case",
    formFieldInput:
      "bg-white/[0.02] border-white/10 text-white focus:border-white/40",
    formFieldLabel: "text-white/50",
    footerActionLink: "text-white hover:text-white/70",
    dividerLine: "bg-white/10",
    dividerText: "text-white/30",
    socialButtonsBlockButton:
      "border-white/10 text-white hover:bg-white/5",
    identityPreviewText: "text-white",
    formResendCodeLink: "text-white",
  },
};
