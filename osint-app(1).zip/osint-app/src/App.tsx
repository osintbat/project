import { Routes, Route } from "react-router-dom";
import { SignedIn, SignedOut } from "@clerk/clerk-react";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";

export default function App() {
  return (
    <Routes>
      <Route path="/login/*" element={<LoginPage />} />
      <Route path="/register/*" element={<RegisterPage />} />

      {/*
        Nessuna dashboard per ora (come richiesto). Un utente autenticato
        che finisce su "/" resta comunque su una pagina neutra finche'
        non esiste una vera destinazione protetta.
      */}
      <Route
        path="/"
        element={
          <>
            <SignedOut>
              <LandingPage />
            </SignedOut>
            <SignedIn>
              <div className="flex min-h-screen items-center justify-center bg-black text-white">
                Sei autenticato. La dashboard non e' ancora stata costruita.
              </div>
            </SignedIn>
          </>
        }
      />

      {/* qualunque path non riconosciuto: nessuna informazione, solo 404 */}
      <Route
        path="*"
        element={
          <div className="flex min-h-screen items-center justify-center bg-black text-white/40">
            404 — Page not found
          </div>
        }
      />
    </Routes>
  );
}
