import type { ReactNode } from "react";

export function AuthShell({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <div className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-black px-6 py-12">
      {/* stesso elemento firma della landing: anelli concentrici sottili */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[800px] w-[800px] -translate-x-1/2 -translate-y-1/2 opacity-[0.35]"
      >
        {[100, 200, 300].map((r) => (
          <span
            key={r}
            className="absolute left-1/2 top-1/2 rounded-full border border-white/[0.06]"
            style={{
              width: r * 2,
              height: r * 2,
              transform: "translate(-50%, -50%)",
            }}
          />
        ))}
      </div>

      <div className="relative z-10 grid w-full max-w-4xl grid-cols-1 overflow-hidden rounded-2xl border border-white/10 md:grid-cols-2">
        {/* pannello sinistro: identita' */}
        <div className="hidden flex-col justify-between bg-white/[0.02] p-10 md:flex">
          <div>
            <span className="mb-10 flex h-6 w-6 items-center justify-center rounded-md border border-white/20 text-[10px] font-semibold text-white">
              TG
            </span>

            <p className="mb-3 text-xs uppercase tracking-[0.2em] text-white/40">
              {eyebrow}
            </p>
            <h1 className="mb-4 max-w-xs text-2xl font-medium leading-[1.15] tracking-tight text-white">
              {title}
            </h1>
            <p className="max-w-xs text-sm leading-relaxed text-white/50">
              {subtitle}
            </p>
          </div>

          <p className="text-xs text-white/30">
            Encrypted end-to-end · Access scoped to verified accounts only
          </p>
        </div>

        {/* pannello destro: form Clerk */}
        <div className="flex items-center justify-center bg-black p-6 sm:p-10">
          <div className="w-full max-w-sm">{children}</div>
        </div>
      </div>
    </div>
  );
}
