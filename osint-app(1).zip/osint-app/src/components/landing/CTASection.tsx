import { Link } from "react-router-dom";
import { buttonVariants } from "../ui/button";
import { cn } from "../../lib/utils";

export function CTASection() {
  return (
    <section id="how-it-works" className="border-t border-white/10 px-6 py-24 text-center">
      <div className="mx-auto max-w-lg">
        <h2 className="mb-4 text-3xl font-medium tracking-tight text-white sm:text-4xl">
          Get a baseline of your exposure in minutes.
        </h2>
        <p className="mb-8 text-white/50">
          Verify ownership of your domain, and TraceGrid starts mapping your
          footprint right away. No sales call required to get started.
        </p>
        <Link to="/register" className={cn(buttonVariants({ size: "lg" }))}>
          Create free account
        </Link>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/10 px-6 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="flex h-5 w-5 items-center justify-center rounded border border-white/20 text-[9px] font-semibold text-white">
            TG
          </span>
          <span className="text-sm text-white/70">TraceGrid</span>
        </div>
        <p className="text-xs text-white/30">
          © {new Date().getFullYear()} TraceGrid. Built for defensive
          security teams monitoring their own assets.
        </p>
      </div>
    </footer>
  );
}
