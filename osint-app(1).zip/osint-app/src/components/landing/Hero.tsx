import { Link } from "react-router-dom";
import { buttonVariants } from "../ui/button";
import { Badge } from "../ui/badge";
import { cn } from "../../lib/utils";

export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pt-28 pb-32 text-center">
      {/* elemento firma: anelli concentrici sottili, tipo radar/scan — monocromatico */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-24 -z-10 h-[900px] w-[900px] -translate-x-1/2 opacity-[0.4]"
      >
        {[120, 220, 320, 420].map((r) => (
          <span
            key={r}
            className="absolute left-1/2 top-1/2 rounded-full border border-white/[0.06]"
            style={{
              width: r * 2,
              height: r * 2,
              transform: "translate(-50%, -50%)",
            }}
          />
        ))}
      </div>

      <div className="relative mx-auto max-w-2xl">
        <Badge className="mb-6">Continuous attack-surface monitoring</Badge>

        <h1 className="mb-6 text-5xl font-medium leading-[1.05] tracking-tight text-white sm:text-6xl">
          See your exposure
          <br />
          before someone else does.
        </h1>

        <p className="mx-auto mb-10 max-w-lg text-lg leading-relaxed text-white/50">
          TraceGrid continuously maps your organization's public footprint —
          domains, credentials, infrastructure — and flags what shouldn't be
          exposed, before it becomes an incident.
        </p>

        <div className="flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link to="/register" className={cn(buttonVariants({ size: "lg" }))}>
            Start free assessment
          </Link>
          <a
            href="#how-it-works"
            className={cn(buttonVariants({ variant: "outline", size: "lg" }))}
          >
            How it works
          </a>
        </div>

        <p className="mt-6 text-xs text-white/30">
          No credit card required · Scoped to your own verified domains
        </p>
      </div>
    </section>
  );
}
