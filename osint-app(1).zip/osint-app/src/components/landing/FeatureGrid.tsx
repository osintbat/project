import { Card, CardTitle, CardDescription } from "../ui/card";

const FEATURES = [
  {
    title: "Domain & asset discovery",
    description:
      "Automatically map every subdomain, certificate, and exposed service tied to your organization — kept current as your infrastructure changes.",
  },
  {
    title: "Exposure monitoring",
    description:
      "Get alerted the moment credentials or configuration tied to your own domains surface in a known incident, so you can rotate them fast.",
  },
  {
    title: "Reporting & workflow",
    description:
      "Turn findings into tickets your team can act on, with severity scoring and a full audit trail for compliance.",
  },
];

export function FeatureGrid() {
  return (
    <section id="product" className="border-t border-white/10 px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <p className="mb-3 text-center text-xs uppercase tracking-[0.2em] text-white/40">
          Platform
        </p>
        <h2 className="mx-auto mb-16 max-w-xl text-center text-3xl font-medium tracking-tight text-white sm:text-4xl">
          Everything your security team needs to watch your own perimeter.
        </h2>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {FEATURES.map((feature, i) => (
            <Card key={feature.title} className="text-left">
              <span className="mb-6 block text-xs font-mono text-white/30">
                0{i + 1}
              </span>
              <CardTitle className="mb-2">{feature.title}</CardTitle>
              <CardDescription>{feature.description}</CardDescription>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
