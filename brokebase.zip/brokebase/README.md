# Brokebase

Mini-SaaS di budget tracking personale. Frontend React+Vite+TS+Tailwind+MUI,
backend Node+Express+TS+PostgreSQL, deploy su Ubuntu 24.04 + nginx + Cloudflare (Full strict).

## Struttura

```
brokebase/
├── frontend/        # React + Vite + TS + Tailwind + MUI, hero con FloatingLines (three.js)
├── backend/         # Express + TS + PostgreSQL, auth JWT in cookie httpOnly, CSRF, rate limit
└── infra/           # script Python di provisioning per la VPS
    ├── 00_install_dependencies.py   # installa node, nginx, postgres, ufw, fail2ban...
    ├── 01_setup_dirs.py             # crea /opt/brokebase, utente di sistema 'brokebase'
    └── 02_setup_nginx.py            # config nginx brokebase.com -> www.brokebase.com, TLS Cloudflare
```

## Deploy da zero (Ubuntu 24.04, solo python3+nano installati)

Sulla VPS, come root:

```bash
# 1. installa tutte le dipendenze di sistema (node, nginx, postgres, ufw, fail2ban)
python3 infra/00_install_dependencies.py
# salva il DATABASE_URL stampato a fine script

# 2. crea la struttura di directory e l'utente di sistema 'brokebase'
python3 infra/01_setup_dirs.py

# 3. build del frontend in locale o sulla VPS
cd frontend
npm install
cp .env.example .env.production   # imposta VITE_API_URL=https://www.brokebase.com/api
npm run build
cp -r dist /opt/brokebase/frontend/

# 4. build del backend
cd ../backend
npm install
npm run build
cp -r dist node_modules package.json /opt/brokebase/backend/
cp .env.example /opt/brokebase/backend/env/.env
nano /opt/brokebase/backend/env/.env
# compila: DATABASE_URL (dal passo 1), JWT_SECRET (openssl rand -base64 48),
# CORS_ALLOWED_ORIGINS=https://www.brokebase.com, COOKIE_DOMAIN=.brokebase.com

# 5. esegui le migration del database
cd /opt/brokebase/backend
node dist/db/migrate.js

# 6. avvia il backend come servizio
systemctl enable --now brokebase-backend
systemctl status brokebase-backend

# 7. genera la config nginx (richiede /opt/certs/cert.pem e key.pem già presenti)
python3 /path/to/infra/02_setup_nginx.py
```

A questo punto: Cloudflare in modalità **Full (strict)** verso l'origine, nginx termina TLS con
il certificato Cloudflare Origin CA in `/opt/certs`, proxa `/api/*` al backend Node su
`127.0.0.1:4000` (mai esposto direttamente su internet) e serve i file statici del frontend.

## Note di sicurezza incluse (non "vuln finte da patchare" — protezioni reali fin dall'inizio)

- Password: argon2id, mai MD5/SHA1, mai salt fisso
- Sessioni: JWT in cookie httpOnly + Secure + SameSite=Strict, algoritmo fissato (no `alg: none`)
- CSRF: double-submit cookie token su tutte le richieste che modificano stato
- CORS: allow-list esplicita, mai wildcard, credentials solo per origin note
- SQLi: solo query parametrizzate ($1, $2…), mai concatenazione stringhe
- IDOR: ogni query su risorse utente filtra per `user_id` dal token, mai dal body/params
- Path traversal: `safeResolve()` valida ogni path contro la directory base
- CSP + Helmet: `frame-ancestors: none` (anti-clickjacking), niente inline script
- Rate limiting su login/register (anti brute-force/credential stuffing) e globale sull'API
- Niente stack trace o dettagli DB nelle risposte di errore
- Niente sourcemap in produzione, niente secrets nei log (redazione pino)
- Backend gira come utente di sistema non privilegiato, mai come root, mai esposto fuori da localhost
