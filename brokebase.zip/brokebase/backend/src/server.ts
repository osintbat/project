import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import compression from 'compression';
import pinoHttp from 'pino-http';
import { env, allowedOrigins } from './config/env.js';
import { apiLimiter } from './middleware/rateLimits.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import authRoutes from './routes/auth.js';
import expensesRoutes from './routes/expenses.js';
import budgetsRoutes from './routes/budgets.js';

const app = express();

// Behind nginx — needed for correct req.ip and secure cookies over the proxy.
app.set('trust proxy', 1);
// Don't advertise the framework/version.
app.disable('x-powered-by');

app.use(
  pinoHttp({
    redact: ['req.headers.cookie', 'req.headers.authorization', 'res.headers["set-cookie"]'],
    autoLogging: {
      ignore: (req) => req.url === '/health'
    }
  })
);

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"], // blocks clickjacking — no one can iframe this API/app
        baseUri: ["'self'"],
        formAction: ["'self'"],
        upgradeInsecureRequests: []
      }
    },
    crossOriginResourcePolicy: { policy: 'same-site' },
    crossOriginOpenerPolicy: { policy: 'same-origin' },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    hsts: { maxAge: 63072000, includeSubDomains: true, preload: true }
  })
);

// Strict allow-list CORS — never a wildcard, credentials only for known origins.
app.use(
  cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      callback(new Error('Origin not allowed by CORS policy'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'X-CSRF-Token']
  })
);

app.use(compression());
app.use(express.json({ limit: '100kb' })); // small body cap — mitigates simple DoS via huge payloads
app.use(cookieParser());
app.use('/api', apiLimiter);

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/expenses', expensesRoutes);
app.use('/api/budgets', budgetsRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

app.listen(env.PORT, '127.0.0.1', () => {
  console.log(`Brokebase API listening on 127.0.0.1:${env.PORT} (${env.NODE_ENV})`);
});
