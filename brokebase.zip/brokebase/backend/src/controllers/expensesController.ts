import { Response } from 'express';
import { z } from 'zod';
import { pool } from '../db/pool.js';
import type { AuthedRequest } from '../middleware/auth.js';

const expenseSchema = z.object({
  label: z.string().trim().min(1).max(120),
  amount: z.number().finite().positive().max(1_000_000),
  category: z.string().trim().min(1).max(60),
  date: z.string().date()
});

// UUID format check before it ever reaches a query — cheap defense-in-depth,
// the real IDOR protection is the "AND user_id = $2" on every query below.
const uuidSchema = z.string().uuid();

export async function listExpenses(req: AuthedRequest, res: Response) {
  const result = await pool.query(
    'SELECT id, label, amount::float AS amount, category, to_char(date, \'YYYY-MM-DD\') AS date FROM expenses WHERE user_id = $1 ORDER BY date DESC, created_at DESC LIMIT 500',
    [req.userId]
  );
  res.json({ expenses: result.rows });
}

export async function createExpense(req: AuthedRequest, res: Response) {
  const parsed = expenseSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid expense data' });
  }
  const { label, amount, category, date } = parsed.data;

  const result = await pool.query(
    `INSERT INTO expenses (user_id, label, amount, category, date)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, label, amount::float AS amount, category, to_char(date, 'YYYY-MM-DD') AS date`,
    [req.userId, label, amount, category, date]
  );
  res.status(201).json({ expense: result.rows[0] });
}

export async function deleteExpense(req: AuthedRequest, res: Response) {
  const idCheck = uuidSchema.safeParse(req.params.id);
  if (!idCheck.success) {
    return res.status(400).json({ message: 'Invalid expense id' });
  }

  // The user_id predicate is what prevents one user deleting another's row (IDOR).
  const result = await pool.query(
    'DELETE FROM expenses WHERE id = $1 AND user_id = $2 RETURNING id',
    [idCheck.data, req.userId]
  );

  if (result.rowCount === 0) {
    return res.status(404).json({ message: 'Expense not found' });
  }
  res.status(204).send();
}
