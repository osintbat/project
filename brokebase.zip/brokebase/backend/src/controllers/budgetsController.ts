import { Response } from 'express';
import { z } from 'zod';
import { pool } from '../db/pool.js';
import type { AuthedRequest } from '../middleware/auth.js';

const budgetSchema = z.object({
  category: z.string().trim().min(1).max(60),
  limit: z.number().finite().positive().max(1_000_000)
});

export async function listBudgets(req: AuthedRequest, res: Response) {
  const result = await pool.query(
    `SELECT b.id, b.category, b."limit"::float AS limit,
            COALESCE(SUM(e.amount), 0)::float AS spent
     FROM budgets b
     LEFT JOIN expenses e
       ON e.user_id = b.user_id
      AND e.category = b.category
      AND date_trunc('month', e.date) = date_trunc('month', CURRENT_DATE)
     WHERE b.user_id = $1
     GROUP BY b.id
     ORDER BY b.category`,
    [req.userId]
  );
  res.json({ budgets: result.rows });
}

export async function upsertBudget(req: AuthedRequest, res: Response) {
  const parsed = budgetSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid budget data' });
  }
  const { category, limit } = parsed.data;

  const result = await pool.query(
    `INSERT INTO budgets (user_id, category, "limit")
     VALUES ($1, $2, $3)
     ON CONFLICT (user_id, category) DO UPDATE SET "limit" = EXCLUDED."limit"
     RETURNING id, category, "limit"::float AS limit`,
    [req.userId, category, limit]
  );
  res.status(201).json({ budget: result.rows[0] });
}
