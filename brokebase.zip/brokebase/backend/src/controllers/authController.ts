import { Response } from 'express';
import { z } from 'zod';
import { pool } from '../db/pool.js';
import { hashPassword, verifyPassword } from '../utils/passwords.js';
import { signAccessToken } from '../utils/jwt.js';
import { generateCsrfToken } from '../utils/csrf.js';
import { env } from '../config/env.js';
import type { AuthedRequest } from '../middleware/auth.js';

const emailSchema = z.string().trim().toLowerCase().email().max(254);
const passwordSchema = z
  .string()
  .min(10)
  .max(128)
  .regex(/[a-z]/)
  .regex(/[A-Z]/)
  .regex(/[0-9]/);

const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  name: z.string().trim().min(1).max(80)
});

const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(128)
});

const COOKIE_BASE = {
  httpOnly: true,
  secure: true,
  sameSite: 'strict' as const,
  domain: env.COOKIE_DOMAIN,
  path: '/'
};

function setAuthCookies(res: Response, accessToken: string) {
  res.cookie('access_token', accessToken, { ...COOKIE_BASE, maxAge: 15 * 60 * 1000 });
  // csrf cookie must be readable by JS (not httpOnly) to mirror into header
  res.cookie('csrf_token', generateCsrfToken(), { ...COOKIE_BASE, httpOnly: false, maxAge: 15 * 60 * 1000 });
}

export async function register(req: AuthedRequest, res: Response) {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid registration details' });
  }
  const { email, password, name } = parsed.data;

  const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
  if (existing.rowCount && existing.rowCount > 0) {
    // Deliberately generic — do not reveal whether the email exists (enumeration defense)
    return res.status(409).json({ message: 'Could not create account with these details' });
  }

  const passwordHash = await hashPassword(password);
  const result = await pool.query(
    'INSERT INTO users (email, password_hash, name) VALUES ($1, $2, $3) RETURNING id, email, name',
    [email, passwordHash, name]
  );
  const user = result.rows[0];

  const accessToken = signAccessToken({ sub: user.id, email: user.email });
  setAuthCookies(res, accessToken);

  res.status(201).json({ user: { id: user.id, email: user.email, name: user.name } });
}

export async function login(req: AuthedRequest, res: Response) {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid credentials' });
  }
  const { email, password } = parsed.data;
  const ip = req.ip ?? 'unknown';

  const result = await pool.query(
    'SELECT id, email, name, password_hash FROM users WHERE email = $1',
    [email]
  );
  const user = result.rows[0];

  // Constant generic response whether the user exists or the password is wrong —
  // avoids user-enumeration via response differences / timing.
  const genericFail = () => res.status(401).json({ message: 'Invalid email or password' });

  if (!user) {
    await pool.query('INSERT INTO login_attempts (email, ip, succeeded) VALUES ($1, $2, false)', [email, ip]);
    return genericFail();
  }

  const valid = await verifyPassword(user.password_hash, password);
  await pool.query('INSERT INTO login_attempts (email, ip, succeeded) VALUES ($1, $2, $3)', [email, ip, valid]);

  if (!valid) return genericFail();

  const accessToken = signAccessToken({ sub: user.id, email: user.email });
  setAuthCookies(res, accessToken);

  res.json({ user: { id: user.id, email: user.email, name: user.name } });
}

export async function logout(_req: AuthedRequest, res: Response) {
  res.clearCookie('access_token', COOKIE_BASE);
  res.clearCookie('csrf_token', { ...COOKIE_BASE, httpOnly: false });
  res.status(204).send();
}

export async function me(req: AuthedRequest, res: Response) {
  const result = await pool.query('SELECT id, email, name FROM users WHERE id = $1', [req.userId]);
  const user = result.rows[0];
  if (!user) return res.status(401).json({ message: 'Not authenticated' });
  res.json({ user });
}
