import { Router } from 'express';
import { listExpenses, createExpense, deleteExpense } from '../controllers/expensesController.js';
import { requireAuth } from '../middleware/auth.js';
import { csrfProtection } from '../middleware/csrf.js';

const router = Router();

router.use(requireAuth);
router.get('/', listExpenses);
router.post('/', csrfProtection, createExpense);
router.delete('/:id', csrfProtection, deleteExpense);

export default router;
