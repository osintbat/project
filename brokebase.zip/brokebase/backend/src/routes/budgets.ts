import { Router } from 'express';
import { listBudgets, upsertBudget } from '../controllers/budgetsController.js';
import { requireAuth } from '../middleware/auth.js';
import { csrfProtection } from '../middleware/csrf.js';

const router = Router();

router.use(requireAuth);
router.get('/', listBudgets);
router.post('/', csrfProtection, upsertBudget);

export default router;
