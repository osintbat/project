import rateLimit from 'express-rate-limit';

// Generic API limiter — generous enough for normal use, tight enough to blunt scraping/DoS.
export const apiLimiter = rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false
});

// Tighter limiter for auth endpoints — mitigates brute force / credential stuffing.
export const authLimiter = rateLimit({
  windowMs: 15 * 60_000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many attempts, please try again later' }
});
