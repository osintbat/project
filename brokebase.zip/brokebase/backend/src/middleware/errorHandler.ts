import { Request, Response, NextFunction } from 'express';

// Central error handler: never leak stack traces, SQL errors, or internal
// paths to the client. Full detail goes to the server log only.
export function errorHandler(err: any, req: Request, res: Response, _next: NextFunction) {
  req.log?.error({ err }, 'Unhandled request error');

  if (res.headersSent) return;

  const status = typeof err?.status === 'number' ? err.status : 500;
  const message = status < 500 ? (err?.message ?? 'Request failed') : 'Something went wrong on our end';

  res.status(status).json({ message });
}

export function notFoundHandler(_req: Request, res: Response) {
  res.status(404).json({ message: 'Not found' });
}
