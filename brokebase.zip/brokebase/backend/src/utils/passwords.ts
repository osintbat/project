import argon2 from 'argon2';

// Argon2id: current best-practice password hashing (memory-hard, GPU-resistant).
// Never MD5/SHA1/plain — and never a fixed/shared salt, argon2 handles per-hash salting.
const HASH_OPTIONS: argon2.Options = {
  type: argon2.argon2id,
  memoryCost: 19_456, // ~19 MB
  timeCost: 2,
  parallelism: 1
};

export function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, HASH_OPTIONS);
}

export function verifyPassword(hash: string, plain: string): Promise<boolean> {
  return argon2.verify(hash, plain).catch(() => false);
}
