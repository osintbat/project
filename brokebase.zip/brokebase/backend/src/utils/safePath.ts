import path from 'path';

// Defense against path/directory traversal for any code that resolves a
// user-supplied filename against a base directory. Always route through this.
export function safeResolve(baseDir: string, userSuppliedPath: string): string {
  const resolvedBase = path.resolve(baseDir);
  const target = path.resolve(resolvedBase, userSuppliedPath);

  if (target !== resolvedBase && !target.startsWith(resolvedBase + path.sep)) {
    throw new Error('Path traversal attempt blocked');
  }
  return target;
}
