import { Link, useNavigate } from 'react-router-dom';
import { AppBar, Toolbar, Button, Box } from '@mui/material';
import { useAuth } from '@/store/auth';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      sx={{ bgcolor: 'rgba(8,9,11,0.85)', backdropFilter: 'blur(8px)', borderBottom: '1px solid #1f2227' }}
    >
      <Toolbar sx={{ maxWidth: 1200, mx: 'auto', width: '100%', px: { xs: 2, md: 4 } }}>
        <Link to="/" className="font-display font-bold text-lg tracking-tight text-ink-100 no-underline">
          broke<span className="text-signal">base</span>
        </Link>
        <Box sx={{ flexGrow: 1 }} />
        {user ? (
          <>
            <Button component={Link} to="/dashboard" color="inherit" sx={{ mr: 1 }}>
              Dashboard
            </Button>
            <Button onClick={handleLogout} variant="outlined" color="inherit">
              Log out
            </Button>
          </>
        ) : (
          <>
            <Button component={Link} to="/login" color="inherit" sx={{ mr: 1 }}>
              Log in
            </Button>
            <Button component={Link} to="/register" variant="contained" color="primary">
              Get started
            </Button>
          </>
        )}
      </Toolbar>
    </AppBar>
  );
}
