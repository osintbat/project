import { Box } from '@mui/material';

export default function Navbar() {
  return (
    <Box
      component="nav"
      sx={{
        position: 'sticky',
        top: 0,
        zIndex: 50,
        bgcolor: 'rgba(0,0,0,0.7)',
        backdropFilter: 'blur(8px)',
        borderBottom: '1px solid rgba(255,255,255,0.12)',
        py: 2.5
      }}
    >
      <Box sx={{ maxWidth: 1200, mx: 'auto', px: { xs: 2, md: 4 } }}>
        <span className="font-display" style={{ fontSize: '1.1rem', letterSpacing: '0.02em', color: '#fff' }}>
          brokebase
        </span>
      </Box>
    </Box>
  );
}
