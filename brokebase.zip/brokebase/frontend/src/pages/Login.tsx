import { useState, FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Box, Container, Typography, TextField, Button, Alert, Paper } from '@mui/material';
import { useAuth } from '@/store/auth';
import { loginSchema } from '@/lib/validation';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const parsed = loginSchema.safeParse({ email, password });
    if (!parsed.success) {
      setFormError(parsed.error.issues[0]?.message ?? 'Check the fields below');
      return;
    }

    setSubmitting(true);
    try {
      await login(parsed.data.email, parsed.data.password);
      navigate('/dashboard');
    } catch {
      setFormError('Wrong email or password.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Container maxWidth="xs" sx={{ py: { xs: 8, md: 14 } }}>
      <Paper sx={{ p: 4, bgcolor: '#0d0f12' }} component="form" onSubmit={handleSubmit} noValidate>
        <Typography variant="h2" sx={{ fontSize: '1.75rem', mb: 3 }}>
          Log in
        </Typography>
        {formError && <Alert severity="error" sx={{ mb: 2 }}>{formError}</Alert>}
        <TextField
          fullWidth
          label="Email"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          sx={{ mb: 2 }}
          required
        />
        <TextField
          fullWidth
          label="Password"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          sx={{ mb: 3 }}
          required
        />
        <Button fullWidth type="submit" variant="contained" size="large" disabled={submitting}>
          {submitting ? 'Logging in…' : 'Log in'}
        </Button>
        <Box sx={{ mt: 3, textAlign: 'center' }}>
          <Typography sx={{ color: '#9aa1ab', fontSize: '0.9rem' }}>
            No account? <Link to="/register" className="text-signal no-underline">Sign up</Link>
          </Typography>
        </Box>
      </Paper>
    </Container>
  );
}
