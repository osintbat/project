import { Link } from 'react-router-dom';
import { Container, Typography, Button, Box } from '@mui/material';

export default function NotFound() {
  return (
    <Container maxWidth="sm" sx={{ py: 16, textAlign: 'center' }}>
      <Typography className="font-mono" sx={{ color: '#5eead4', mb: 2 }}>404</Typography>
      <Typography variant="h2" sx={{ fontSize: '1.75rem', mb: 2 }}>Nothing here.</Typography>
      <Typography sx={{ color: '#9aa1ab', mb: 4 }}>
        That page doesn't exist, or you don't have access to it.
      </Typography>
      <Box>
        <Button component={Link} to="/" variant="contained">Back home</Button>
      </Box>
    </Container>
  );
}
