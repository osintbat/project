import { Box, Container, Typography, Button, Chip } from '@mui/material';
import {
  FiLayers,
  FiZap,
  FiGitBranch,
  FiClock,
  FiUsers,
  FiBarChart2,
  FiCheckSquare,
  FiBell,
  FiLock,
  FiTerminal,
  FiGitPullRequest,
  FiCalendar,
  FiCheckCircle,
  FiStar,
  FiSlack,
  FiGithub,
  FiFigma
} from 'react-icons/fi';
import PixelBlast from '@/components/PixelBlast';

const features = [
  { icon: FiCheckSquare, title: 'Task boards', body: 'Kanban and list views that stay in sync. Drag a card, everyone sees it move instantly.' },
  { icon: FiGitBranch, title: 'Dependency tracking', body: 'Mark what blocks what. Brokebase warns you before a blocked task slips the deadline.' },
  { icon: FiClock, title: 'Time tracking', body: 'Built-in timers per task. No separate app, no manual entry at the end of the week.' },
  { icon: FiUsers, title: 'Team workload', body: 'See who is overloaded before it becomes a problem, not after the sprint is already late.' },
  { icon: FiBarChart2, title: 'Reporting', body: 'Burndown, velocity, and cycle time — generated automatically from work you already logged.' },
  { icon: FiBell, title: 'Smart notifications', body: 'Only pinged for what needs you. No channel noise, no missed mentions.' },
  { icon: FiLock, title: 'Role-based access', body: 'Guests, members, admins. Control exactly who can see and edit what.' },
  { icon: FiTerminal, title: 'API & webhooks', body: 'Automate anything. Trigger workflows in your own stack when a task changes state.' }
];

const integrations = [
  { icon: FiSlack, name: 'Slack' },
  { icon: FiGithub, name: 'GitHub' },
  { icon: FiFigma, name: 'Figma' },
  { icon: FiGitPullRequest, name: 'GitLab' },
  { icon: FiCalendar, name: 'Calendar' },
  { icon: FiTerminal, name: 'CLI' }
];

const steps = [
  { n: '01', title: 'Create a workspace', body: 'Set up your team in under a minute. Invite people by email, no seat limits on the trial.' },
  { n: '02', title: 'Import or start fresh', body: 'Pull tasks from a CSV, Jira, or Trello export — or start a clean board from a template.' },
  { n: '03', title: 'Ship on schedule', body: 'Track progress in real time and catch slippage before it costs you the deadline.' }
];

const testimonials = [
  { quote: 'We replaced three tools with this. Onboarding took an afternoon, not a quarter.', name: 'Engineering manager, 12-person team' },
  { quote: 'The dependency view alone paid for the subscription. We stopped shipping broken releases.', name: 'Product lead, agency' },
  { quote: 'Reporting used to take me half a day every Friday. Now it is already there.', name: 'Ops lead, remote startup' }
];

const faqs = [
  { q: 'Is there a free plan?', a: 'Yes. Free covers up to 3 members and unlimited tasks, no time limit.' },
  { q: 'Can I import from Jira or Trello?', a: 'Yes, via CSV or our direct importer — most boards migrate in under 10 minutes.' },
  { q: 'Do you offer annual billing?', a: 'Yes, annual billing saves roughly two months compared to paying monthly.' },
  { q: 'Can I cancel anytime?', a: 'Yes, no lock-in contracts. Cancel from account settings, effective at the end of the billing period.' }
];

const tiers = [
  { title: 'Free', price: '0', features: ['Up to 3 members', 'Unlimited tasks', 'Basic reporting', 'Community support'], cta: 'Start free', highlight: false },
  { title: 'Team', price: '12', features: ['Up to 25 members', 'Dependency tracking', 'Time tracking', 'API access', 'Priority support'], cta: 'Start trial', highlight: true },
  { title: 'Business', price: '29', features: ['Unlimited members', 'Advanced reporting', 'SSO & role-based access', 'Dedicated onboarding'], cta: 'Contact sales', highlight: false }
];

export default function Landing() {
  return (
    <Box sx={{ bgcolor: '#000000' }}>
      {/* Hero */}
      <Box sx={{ position: 'relative', height: { xs: 560, md: 680 }, overflow: 'hidden', borderBottom: '1px solid rgba(255,255,255,0.12)' }}>
        <Box sx={{ position: 'absolute', inset: 0 }}>
          <PixelBlast
            variant="square"
            pixelSize={4}
            color="#ffffff"
            patternScale={2}
            patternDensity={1}
            pixelSizeJitter={0}
            enableRipples
            rippleSpeed={0.4}
            rippleThickness={0.12}
            rippleIntensityScale={1.5}
            liquid={false}
            speed={0.5}
            edgeFade={0.25}
            transparent
          />
        </Box>
        <Container
          maxWidth="lg"
          sx={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
        >
          <Typography className="font-mono" sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 3 }}>
            PROJECT MANAGEMENT, MADE PLAIN
          </Typography>
          <Typography
            className="font-display"
            sx={{ fontSize: { xs: '3rem', md: '5.5rem' }, lineHeight: 0.95, maxWidth: 920, mb: 3, color: '#fff' }}
          >
            SHIP PROJECTS WITHOUT THE CHAOS.
          </Typography>
          <Typography sx={{ color: '#a3a3a3', fontSize: '1.15rem', maxWidth: 560, mb: 4 }}>
            Boards, dependencies, and reporting in one place — built for small teams that would
            rather ship than manage the tool.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button
              variant="contained"
              size="large"
              sx={{ px: 4, bgcolor: '#fff', color: '#000', '&:hover': { bgcolor: '#e5e5e5' } }}
            >
              Start free
            </Button>
            <Button variant="outlined" color="inherit" size="large" sx={{ px: 4, borderColor: 'rgba(255,255,255,0.4)' }}>
              See pricing
            </Button>
          </Box>
        </Container>
      </Box>

      {/* Section 1 — Features, joined card grid */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
        <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 1 }} className="font-mono">
          WHAT YOU GET
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.3rem' }, fontWeight: 800, mb: 5, maxWidth: 640 }}>
          Everything a shipping team needs, nothing it has to configure first.
        </Typography>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr 1fr' },
            border: '1px solid rgba(255,255,255,0.14)'
          }}
        >
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <Box
                key={f.title}
                sx={{
                  p: 3.5,
                  bgcolor: i % 2 === 0 ? '#0a0a0a' : '#000',
                  borderRight: { md: i % 4 !== 3 ? '1px solid rgba(255,255,255,0.14)' : 'none' },
                  borderBottom: '1px solid rgba(255,255,255,0.14)',
                  transition: 'background-color 0.15s ease',
                  '&:hover': { bgcolor: '#141414' }
                }}
              >
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    border: '1px solid rgba(255,255,255,0.25)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#fff',
                    mb: 2
                  }}
                >
                  <Icon size={19} />
                </Box>
                <Typography sx={{ fontSize: '1rem', fontWeight: 700, mb: 1 }}>{f.title}</Typography>
                <Typography sx={{ color: '#a3a3a3', fontSize: '0.9rem', lineHeight: 1.55 }}>{f.body}</Typography>
              </Box>
            );
          })}
        </Box>
      </Container>

      {/* Section 2 — Integrations strip */}
      <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.12)', borderBottom: '1px solid rgba(255,255,255,0.12)', bgcolor: '#0a0a0a' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 6, md: 7 } }}>
          <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 4 }} className="font-mono">
            WORKS WITH WHAT YOU ALREADY USE
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr 1fr', md: 'repeat(6, 1fr)' }, gap: 2 }}>
            {integrations.map((it) => {
              const Icon = it.icon;
              return (
                <Box
                  key={it.name}
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: 1,
                    py: 3,
                    border: '1px solid rgba(255,255,255,0.14)',
                    color: '#a3a3a3',
                    '&:hover': { color: '#fff', borderColor: 'rgba(255,255,255,0.4)' }
                  }}
                >
                  <Icon size={22} />
                  <Typography sx={{ fontSize: '0.78rem' }}>{it.name}</Typography>
                </Box>
              );
            })}
          </Box>
        </Container>
      </Box>

      {/* Section 3 — How it works, real sequence */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
        <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 1 }} className="font-mono">
          HOW IT WORKS
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.3rem' }, fontWeight: 800, mb: 6, maxWidth: 640 }}>
          Three steps, no consultant required.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 4 }}>
          {steps.map((s) => (
            <Box key={s.n}>
              <Typography className="font-display tabular" sx={{ fontSize: '3rem', color: 'rgba(255,255,255,0.25)', mb: 1, lineHeight: 1 }}>
                {s.n}
              </Typography>
              <Typography sx={{ fontWeight: 700, mb: 1 }}>{s.title}</Typography>
              <Typography sx={{ color: '#a3a3a3', fontSize: '0.9rem', lineHeight: 1.6 }}>{s.body}</Typography>
            </Box>
          ))}
        </Box>
      </Container>

      {/* Section 4 — Why teams switch */}
      <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.12)', bgcolor: '#0a0a0a' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
          <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 1 }} className="font-mono">
            WHY TEAMS SWITCH
          </Typography>
          <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.3rem' }, fontWeight: 800, mb: 5, maxWidth: 640 }}>
            Fewer tools, less status-update overhead.
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 0, border: '1px solid rgba(255,255,255,0.14)' }}>
            {[
              { icon: FiLayers, title: 'One board, not five tabs', body: 'Tasks, docs, and timelines in a single workspace instead of stitched-together tools.' },
              { icon: FiZap, title: 'Fast by default', body: 'No loading spinners on every click. Boards with thousands of tasks stay instant.' },
              { icon: FiCheckCircle, title: 'Nothing falls through', body: 'Dependencies and due dates surface automatically — no manual chasing in standup.' },
              { icon: FiUsers, title: 'Built for small teams', body: 'Not bloated enterprise software repurposed for 5 people. Priced and built for you.' }
            ].map((w, i) => {
              const Icon = w.icon;
              return (
                <Box
                  key={w.title}
                  sx={{
                    display: 'flex',
                    gap: 2.5,
                    p: 3.5,
                    borderRight: { sm: i % 2 === 0 ? '1px solid rgba(255,255,255,0.14)' : 'none' },
                    borderBottom: i < 2 ? '1px solid rgba(255,255,255,0.14)' : 'none'
                  }}
                >
                  <Box sx={{ flexShrink: 0, width: 44, height: 44, border: '1px solid rgba(255,255,255,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon size={20} />
                  </Box>
                  <Box>
                    <Typography sx={{ fontWeight: 700, mb: 0.5 }}>{w.title}</Typography>
                    <Typography sx={{ color: '#a3a3a3', fontSize: '0.9rem', lineHeight: 1.55 }}>{w.body}</Typography>
                  </Box>
                </Box>
              );
            })}
          </Box>
        </Container>
      </Box>

      {/* Section 5 — Testimonials */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
        <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 1 }} className="font-mono">
          WHO'S USING IT
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.3rem' }, fontWeight: 800, mb: 5, maxWidth: 640 }}>
          Teams that stopped managing the tool.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, border: '1px solid rgba(255,255,255,0.14)' }}>
          {testimonials.map((t, i) => (
            <Box
              key={t.name}
              sx={{
                p: 3.5,
                borderRight: { md: i !== 2 ? '1px solid rgba(255,255,255,0.14)' : 'none' }
              }}
            >
              <Box sx={{ display: 'flex', gap: 0.5, mb: 1.5 }}>
                {[...Array(5)].map((_, k) => <FiStar key={k} size={13} fill="#fff" color="#fff" />)}
              </Box>
              <Typography sx={{ fontSize: '0.92rem', lineHeight: 1.6, mb: 2 }}>&ldquo;{t.quote}&rdquo;</Typography>
              <Typography sx={{ fontSize: '0.8rem', color: '#737373' }}>{t.name}</Typography>
            </Box>
          ))}
        </Box>
      </Container>

      {/* Section 6 — Pricing */}
      <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.12)', bgcolor: '#0a0a0a' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 8, md: 12 } }}>
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 1 }} className="font-mono">
              PRICING
            </Typography>
            <Typography sx={{ fontSize: { xs: '1.9rem', md: '2.4rem' }, fontWeight: 800 }}>
              Simple pricing, cancel anytime.
            </Typography>
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 0, border: '1px solid rgba(255,255,255,0.14)' }}>
            {tiers.map((tier, i) => (
              <Box
                key={tier.title}
                sx={{
                  p: 4,
                  bgcolor: tier.highlight ? '#141414' : '#000',
                  borderRight: { md: i !== 2 ? '1px solid rgba(255,255,255,0.14)' : 'none' },
                  position: 'relative',
                  display: 'flex',
                  flexDirection: 'column'
                }}
              >
                {tier.highlight && (
                  <Chip label="Most popular" size="small" sx={{ position: 'absolute', top: -12, left: 24, bgcolor: '#fff', color: '#000', fontWeight: 700, borderRadius: 0 }} />
                )}
                <Typography sx={{ fontWeight: 700, mb: 1 }}>{tier.title}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'baseline', mb: 3 }}>
                  <Typography className="font-display" sx={{ fontSize: '2.6rem' }}>${tier.price}</Typography>
                  <Typography sx={{ color: '#737373', ml: 1 }}>/ month</Typography>
                </Box>
                <Box sx={{ flexGrow: 1, mb: 3 }}>
                  {tier.features.map((f) => (
                    <Box key={f} sx={{ display: 'flex', gap: 1.25, alignItems: 'center', py: 0.75 }}>
                      <FiCheckCircle size={16} />
                      <Typography sx={{ fontSize: '0.9rem', color: '#d4d4d4' }}>{f}</Typography>
                    </Box>
                  ))}
                </Box>
                <Button
                  fullWidth
                  variant={tier.highlight ? 'contained' : 'outlined'}
                  color="inherit"
                  sx={
                    tier.highlight
                      ? { bgcolor: '#fff', color: '#000', '&:hover': { bgcolor: '#e5e5e5' } }
                      : { borderColor: 'rgba(255,255,255,0.4)' }
                  }
                >
                  {tier.cta}
                </Button>
              </Box>
            ))}
          </Box>
        </Container>
      </Box>

      {/* Section 7 — FAQ */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
        <Typography sx={{ color: '#a3a3a3', fontSize: '0.8rem', letterSpacing: '0.14em', mb: 1 }} className="font-mono">
          FAQ
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.3rem' }, fontWeight: 800, mb: 5, maxWidth: 640 }}>
          Questions people actually ask.
        </Typography>
        <Box sx={{ border: '1px solid rgba(255,255,255,0.14)' }}>
          {faqs.map((f, i) => (
            <Box key={f.q} sx={{ p: 3.5, borderBottom: i !== faqs.length - 1 ? '1px solid rgba(255,255,255,0.14)' : 'none' }}>
              <Typography sx={{ fontWeight: 700, mb: 1 }}>{f.q}</Typography>
              <Typography sx={{ color: '#a3a3a3', fontSize: '0.9rem', lineHeight: 1.6 }}>{f.a}</Typography>
            </Box>
          ))}
        </Box>
      </Container>

      {/* Final CTA */}
      <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.12)', py: { xs: 8, md: 10 }, textAlign: 'center' }}>
        <Container maxWidth="sm">
          <Typography sx={{ fontSize: { xs: '1.7rem', md: '2.1rem' }, fontWeight: 800, mb: 2 }}>
            Stop managing the tool. Start shipping.
          </Typography>
          <Typography sx={{ color: '#a3a3a3', mb: 4 }}>Free plan available. No credit card required.</Typography>
          <Button variant="contained" size="large" sx={{ px: 5, bgcolor: '#fff', color: '#000', '&:hover': { bgcolor: '#e5e5e5' } }}>
            Create your workspace
          </Button>
        </Container>
      </Box>

      <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.12)', py: 3 }}>
        <Container maxWidth="lg">
          <Typography sx={{ color: '#737373', fontSize: '0.85rem' }}>
            © {new Date().getFullYear()} Brokebase. Project management for teams that would rather ship.
          </Typography>
        </Container>
      </Box>
    </Box>
  );
}
