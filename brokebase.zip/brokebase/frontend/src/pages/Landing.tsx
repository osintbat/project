import { Link } from 'react-router-dom';
import { Box, Container, Typography, Button, Grid, Paper } from '@mui/material';
import FloatingLines from '@/components/FloatingLines';

const features = [
  {
    label: 'Track',
    title: 'Every expense, tagged in seconds',
    body: 'Log spending as it happens. No spreadsheets, no manual categorizing at month-end.'
  },
  {
    label: 'Cap',
    title: 'Budgets that push back',
    body: 'Set a limit per category. Brokebase tells you before you blow it, not after.'
  },
  {
    label: 'See',
    title: 'Where the money actually goes',
    body: 'A running read on your month — not a report you have to go looking for.'
  }
];

export default function Landing() {
  return (
    <Box>
      {/* Hero — the signature moment: the wave field is the thesis, money as motion, not chart */}
      <Box sx={{ position: 'relative', height: { xs: 480, md: 640 }, overflow: 'hidden' }}>
        <Box sx={{ position: 'absolute', inset: 0 }}>
          <FloatingLines
            enabledWaves={['top', 'middle', 'bottom']}
            lineCount={8}
            lineDistance={8}
            bendRadius={8}
            bendStrength={-2}
            interactive
            parallax
            animationSpeed={1}
            gradientStart="#5eead4"
            gradientMid="#2dd4bf"
            gradientEnd="#0d9488"
            mixBlendMode="screen"
          />
        </Box>
        <Container
          maxWidth="lg"
          sx={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
        >
          <Typography
            variant="h1"
            sx={{ fontSize: { xs: '2.5rem', md: '4.25rem' }, lineHeight: 1.05, maxWidth: 760, mb: 3 }}
          >
            Budgeting for people who are actually broke.
          </Typography>
          <Typography variant="body1" sx={{ color: '#9aa1ab', fontSize: '1.15rem', maxWidth: 520, mb: 4 }}>
            Not another finance dashboard for people with money to manage. Brokebase is for the gap between
            paychecks — track it, cap it, stop guessing.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button component={Link} to="/register" variant="contained" size="large" sx={{ px: 4 }}>
              Start free
            </Button>
            <Button component={Link} to="/login" variant="outlined" color="inherit" size="large" sx={{ px: 4 }}>
              I have an account
            </Button>
          </Box>
        </Container>
      </Box>

      {/* Features — no numbered markers: these three aren't a sequence, they run in parallel */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 12 } }}>
        <Grid container spacing={3}>
          {features.map((f) => (
            <Grid item xs={12} md={4} key={f.title}>
              <Paper sx={{ p: 4, height: '100%', bgcolor: '#0d0f12' }}>
                <Typography
                  className="font-mono"
                  sx={{ color: '#5eead4', fontSize: '0.8rem', letterSpacing: '0.08em', mb: 2 }}
                >
                  {f.label.toUpperCase()}
                </Typography>
                <Typography variant="h3" sx={{ fontSize: '1.35rem', mb: 1.5 }}>
                  {f.title}
                </Typography>
                <Typography sx={{ color: '#9aa1ab' }}>{f.body}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>

      <Box sx={{ borderTop: '1px solid #1f2227', py: 3 }}>
        <Container maxWidth="lg">
          <Typography sx={{ color: '#6b7280', fontSize: '0.85rem' }}>
            © {new Date().getFullYear()} Brokebase. Built for people counting days to payday.
          </Typography>
        </Container>
      </Box>
    </Box>
  );
}
