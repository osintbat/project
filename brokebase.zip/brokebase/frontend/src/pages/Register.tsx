import { useState, FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Box, Container, Typography, TextField, Button, Alert, Paper } from '@mui/material';
import { useAuth } from '@/store/auth';
import { registerSchema } from '@/lib/validation';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const parsed = registerSchema.safeParse({ name, email, password });
    if (!parsed.success) {
      setFormError(parsed.error.issues[0]?.message ?? 'Check the fields below');
      return;
    }

    setSubmitting(true);
    try {
      await register(parsed.data.email, parsed.data.password, parsed.data.name);
      navigate('/dashboard');
    } catch (err: any) {
      setFormError(err?.response?.data?.message ?? 'Could not create account.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Container maxWidth="xs" sx={{ py: { xs: 8, md: 14 } }}>
      <Paper sx={{ p: 4, bgcolor: '#0d0f12' }} component="form" onSubmit={handleSubmit} noValidate>
        <Typography variant="h2" sx={{ fontSize: '1.75rem', mb: 3 }}>
          Create your account
        </Typography>
        {formError && <Alert severity="error" sx={{ mb: 2 }}>{formError}</Alert>}
        <TextField
          fullWidth
          label="Name"
          autoComplete="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          sx={{ mb: 2 }}
          required
        />
        <TextField
          fullWidth
          label="Email"
          type="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          sx={{ mb: 2 }}
          required
        />
        <TextField
          fullWidth
          label="Password"
          type="password"
          autoComplete="new-password"
          helperText="10+ characters, upper, lower and a number"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          sx={{ mb: 3 }}
          required
        />
        <Button fullWidth type="submit" variant="contained" size="large" disabled={submitting}>
          {submitting ? 'Creating…' : 'Create account'}
        </Button>
        <Box sx={{ mt: 3, textAlign: 'center' }}>
          <Typography sx={{ color: '#9aa1ab', fontSize: '0.9rem' }}>
            Already have an account? <Link to="/login" className="text-signal no-underline">Log in</Link>
          </Typography>
        </Box>
      </Paper>
    </Container>
  );
}
