import { createTheme } from '@mui/material/styles';

// Token system per la skill di design: dark, signal teal come unico accento.
export const theme = createTheme({
  palette: {
    mode: 'dark',
    background: { default: '#08090b', paper: '#0d0f12' },
    primary: { main: '#5eead4' },
    error: { main: '#f87171' },
    text: { primary: '#f4f5f7', secondary: '#9aa1ab' }
  },
  typography: {
    fontFamily: '"Inter", sans-serif',
    h1: { fontFamily: '"Space Grotesk", sans-serif', fontWeight: 700 },
    h2: { fontFamily: '"Space Grotesk", sans-serif', fontWeight: 700 },
    h3: { fontFamily: '"Space Grotesk", sans-serif', fontWeight: 700 },
    button: { textTransform: 'none', fontWeight: 600 }
  },
  shape: { borderRadius: 6 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 6 }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none', border: '1px solid #1f2227' }
      }
    }
  }
});
