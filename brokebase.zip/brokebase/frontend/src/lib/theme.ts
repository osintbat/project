import { createTheme } from '@mui/material/styles';

export const theme = createTheme({
  palette: {
    mode: 'dark',
    background: { default: '#000000', paper: '#0a0a0a' },
    primary: { main: '#ffffff' },
    text: { primary: '#ffffff', secondary: '#a3a3a3' }
  },
  typography: {
    fontFamily: '"Inter", sans-serif',
    h1: { fontFamily: '"Anton", sans-serif', fontWeight: 400, textTransform: 'uppercase' },
    h2: { fontFamily: '"Anton", sans-serif', fontWeight: 400, textTransform: 'uppercase' },
    h3: { fontWeight: 800 },
    button: { textTransform: 'none', fontWeight: 700 }
  },
  shape: { borderRadius: 0 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 0 }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none', border: '1px solid rgba(255,255,255,0.14)', borderRadius: 0 }
      }
    }
  }
});
