import { z } from 'zod';

export const emailSchema = z.string().trim().toLowerCase().email().max(254);

export const passwordSchema = z
  .string()
  .min(10, 'At least 10 characters')
  .max(128)
  .regex(/[a-z]/, 'Needs a lowercase letter')
  .regex(/[A-Z]/, 'Needs an uppercase letter')
  .regex(/[0-9]/, 'Needs a number');

export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  name: z.string().trim().min(1).max(80)
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(128)
});

export const expenseSchema = z.object({
  label: z.string().trim().min(1).max(120),
  amount: z.number().finite().positive().max(1_000_000),
  category: z.string().trim().min(1).max(60),
  date: z.string().date()
});

export const budgetSchema = z.object({
  category: z.string().trim().min(1).max(60),
  limit: z.number().finite().positive().max(1_000_000)
});
