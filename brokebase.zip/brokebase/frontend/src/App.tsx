import { ThemeProvider, CssBaseline } from '@mui/material';
import { theme } from '@/lib/theme';
import Navbar from '@/components/Navbar';
import Landing from '@/pages/Landing';

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Navbar />
      <Landing />
    </ThemeProvider>
  );
}
