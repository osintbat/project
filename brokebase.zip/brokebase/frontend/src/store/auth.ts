import { create } from 'zustand';
import { api } from '@/lib/api';

export type User = { id: string; email: string; name: string };

type AuthState = {
  user: User | null;
  loading: boolean;
  error: string | null;
  fetchMe: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
};

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: true,
  error: null,

  fetchMe: async () => {
    try {
      const { data } = await api.get<{ user: User }>('/auth/me');
      set({ user: data.user, loading: false, error: null });
    } catch {
      set({ user: null, loading: false });
    }
  },

  login: async (email, password) => {
    set({ error: null });
    try {
      const { data } = await api.post<{ user: User }>('/auth/login', { email, password });
      set({ user: data.user });
    } catch (err: any) {
      set({ error: err?.response?.data?.message ?? 'Login failed' });
      throw err;
    }
  },

  register: async (email, password, name) => {
    set({ error: null });
    try {
      const { data } = await api.post<{ user: User }>('/auth/register', { email, password, name });
      set({ user: data.user });
    } catch (err: any) {
      set({ error: err?.response?.data?.message ?? 'Registration failed' });
      throw err;
    }
  },

  logout: async () => {
    await api.post('/auth/logout');
    set({ user: null });
  }
}));
