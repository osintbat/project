/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#08090b',
          900: '#0d0f12',
          800: '#15171b',
          700: '#1f2227',
          600: '#2a2e35'
        },
        ink: {
          100: '#f4f5f7',
          400: '#9aa1ab',
          500: '#6b7280'
        },
        signal: {
          DEFAULT: '#5eead4', // acid teal accent — the one bold move
          dim: '#2dd4bf'
        },
        danger: '#f87171'
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      }
    }
  },
  plugins: []
};
