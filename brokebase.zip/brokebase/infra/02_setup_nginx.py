#!/usr/bin/env python3
"""
02_setup_nginx.py
Writes the nginx site config for brokebase.com -> www.brokebase.com,
terminating TLS with the Cloudflare origin certificate in /opt/certs,
and reverse-proxying /api to the Node backend on 127.0.0.1:4000.

Assumes Cloudflare SSL/TLS mode is set to "Full (strict)" — the origin
cert in /opt/certs must be a valid Cloudflare Origin CA certificate
(or a cert Cloudflare will trust), not a self-signed one, or "Full (strict)"
will fail.

Run as root: python3 02_setup_nginx.py
"""
import os
import subprocess
import sys

SITE_NAME = "brokebase.com"
CONF_PATH = f"/etc/nginx/sites-available/{SITE_NAME}"
ENABLED_PATH = f"/etc/nginx/sites-enabled/{SITE_NAME}"
CERT_PATH = "/opt/certs/cert.pem"
KEY_PATH = "/opt/certs/key.pem"
FRONTEND_ROOT = "/opt/brokebase/frontend/dist"
BACKEND_UPSTREAM = "127.0.0.1:4000"

NGINX_CONF = f"""# Managed by 02_setup_nginx.py — edit the script, not this file, if regenerating.

# Bare domain -> www, HTTPS only
server {{
    listen 80;
    listen [::]:80;
    server_name {SITE_NAME} www.{SITE_NAME};
    return 301 https://www.{SITE_NAME}$request_uri;
}}

server {{
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name {SITE_NAME};

    ssl_certificate     {CERT_PATH};
    ssl_certificate_key {KEY_PATH};
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!3DES:!RC4;
    ssl_prefer_server_ciphers on;

    return 301 https://www.{SITE_NAME}$request_uri;
}}

server {{
    listen 443 ssl;
    listen [::]:443 ssl;
    http2 on;
    server_name www.{SITE_NAME};

    ssl_certificate     {CERT_PATH};
    ssl_certificate_key {KEY_PATH};
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!3DES:!RC4;
    ssl_prefer_server_ciphers on;

    # Real client IP from Cloudflare (Full strict terminates TLS here, CF still proxies)
    set_real_ip_from 0.0.0.0/0;
    real_ip_header CF-Connecting-IP;

    # Baseline security headers at the edge too (defense in depth with helmet in the app)
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;

    client_max_body_size 1m;

    # Static frontend build
    root {FRONTEND_ROOT};
    index index.html;

    location / {{
        try_files $uri /index.html;
    }}

    # Never serve dotfiles / env / config artifacts, wherever they might land
    location ~ /\\. {{
        deny all;
    }}
    location ~* \\.(env|log|sql|bak|git)$ {{
        deny all;
    }}

    # Reverse proxy to the Node/Express API — backend listens on loopback only
    location /api/ {{
        proxy_pass http://{BACKEND_UPSTREAM}/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header CF-Connecting-IP $http_cf_connecting_ip;
        proxy_read_timeout 30s;
        proxy_connect_timeout 5s;
    }}

    location = /health {{
        proxy_pass http://{BACKEND_UPSTREAM}/health;
    }}
}}
"""


def main():
    if os.geteuid() != 0:
        print("Run this as root (sudo python3 02_setup_nginx.py)")
        sys.exit(1)

    for p in (CERT_PATH, KEY_PATH):
        if not os.path.isfile(p):
            print(f"Missing expected file: {p} — aborting before writing nginx config.")
            sys.exit(1)

    os.makedirs("/etc/nginx/sites-available", exist_ok=True)
    os.makedirs("/etc/nginx/sites-enabled", exist_ok=True)

    with open(CONF_PATH, "w") as f:
        f.write(NGINX_CONF)
    print(f"  wrote {CONF_PATH}")

    if not os.path.islink(ENABLED_PATH):
        os.symlink(CONF_PATH, ENABLED_PATH)
        print(f"  linked {ENABLED_PATH}")

    default_site = "/etc/nginx/sites-enabled/default"
    if os.path.exists(default_site):
        os.remove(default_site)
        print("  removed default nginx site")

    print("\nTesting nginx config...")
    result = subprocess.run(["nginx", "-t"], capture_output=True, text=True)
    print(result.stdout)
    print(result.stderr)

    if result.returncode == 0:
        subprocess.run(["systemctl", "reload", "nginx"])
        print("nginx config valid and reloaded.")
    else:
        print("nginx config test FAILED — not reloading. Fix the error above and re-run nginx -t.")
        sys.exit(1)


if __name__ == "__main__":
    main()
