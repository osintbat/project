#!/usr/bin/env python3
"""
00_install_dependencies.py
Installs everything Brokebase needs on a fresh Ubuntu 24.04 VPS
(starting point: only python3 + nano installed, per your setup).

Installs: nginx, Node.js 20 LTS + npm, PostgreSQL, ufw, fail2ban,
unattended-upgrades, and creates the app database + role.

Run as root: python3 00_install_dependencies.py
Run order on the VPS:
  1) python3 00_install_dependencies.py
  2) python3 01_setup_dirs.py
  3) (deploy backend + frontend build into /opt/brokebase)
  4) python3 02_setup_nginx.py
  5) systemctl enable --now brokebase-backend   (see systemd unit this script installs)
"""
import os
import subprocess
import sys
import secrets

DB_NAME = "brokebase"
DB_USER = "brokebase_app"


def run(cmd, check=True, env=None):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True, env=env)
    if check and result.returncode != 0:
        print(f"Command failed: {cmd}")
        sys.exit(1)


def apt_install(*packages):
    run("apt-get update -y")
    run(f"DEBIAN_FRONTEND=noninteractive apt-get install -y {' '.join(packages)}")


def main():
    if os.geteuid() != 0:
        print("Run this as root (sudo python3 00_install_dependencies.py)")
        sys.exit(1)

    print("== 1/6: Base packages ==")
    apt_install(
        "curl", "ca-certificates", "gnupg", "build-essential",
        "ufw", "fail2ban", "unattended-upgrades", "git"
    )

    print("== 2/6: Node.js 20 LTS ==")
    if subprocess.run("command -v node", shell=True, capture_output=True).returncode != 0:
        run("curl -fsSL https://deb.nodesource.com/setup_20.x | bash -")
        apt_install("nodejs")
    else:
        print("  node already installed, skipping")

    print("== 3/6: nginx ==")
    apt_install("nginx")
    run("systemctl enable nginx")

    print("== 4/6: PostgreSQL ==")
    apt_install("postgresql", "postgresql-contrib")
    run("systemctl enable postgresql")
    run("systemctl start postgresql")

    db_password = secrets.token_urlsafe(24)
    # Create role + database idempotently, restricted privileges (not superuser).
    psql_cmds = f"""
DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '{DB_USER}') THEN
      CREATE ROLE {DB_USER} LOGIN PASSWORD '{db_password}';
   END IF;
END
$$;
SELECT 'CREATE DATABASE {DB_NAME} OWNER {DB_USER}'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '{DB_NAME}')\\gexec
GRANT ALL PRIVILEGES ON DATABASE {DB_NAME} TO {DB_USER};
"""
    with open("/tmp/brokebase_init.sql", "w") as f:
        f.write(psql_cmds)
    run(f"sudo -u postgres psql -v ON_ERROR_STOP=1 -f /tmp/brokebase_init.sql")
    os.remove("/tmp/brokebase_init.sql")

    print(f"\n  Postgres role '{DB_USER}' ready.")
    print(f"  DATABASE_URL=postgres://{DB_USER}:{db_password}@127.0.0.1:5432/{DB_NAME}")
    print("  >>> Save this connection string into /opt/brokebase/backend/env/.env as DATABASE_URL <<<\n")

    print("== 5/6: Firewall (ufw) ==")
    run("ufw allow OpenSSH", check=False)
    run("ufw allow 'Nginx Full'", check=False)
    run("ufw --force enable", check=False)

    print("== 6/6: systemd unit for the backend ==")
    unit = """[Unit]
Description=Brokebase API
After=network.target postgresql.service

[Service]
Type=simple
User=brokebase
Group=brokebase
WorkingDirectory=/opt/brokebase/backend
EnvironmentFile=/opt/brokebase/backend/env/.env
ExecStart=/usr/bin/node dist/server.js
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=/opt/brokebase/backend/logs
ProtectHome=true

[Install]
WantedBy=multi-user.target
"""
    with open("/etc/systemd/system/brokebase-backend.service", "w") as f:
        f.write(unit)
    run("systemctl daemon-reload")
    print("  systemd unit installed at /etc/systemd/system/brokebase-backend.service")
    print("  (enable it after deploying code + env file: systemctl enable --now brokebase-backend)")

    print("\nAll base dependencies installed.")
    print("Next: python3 01_setup_dirs.py")


if __name__ == "__main__":
    main()
