#!/usr/bin/env python3
"""
01_setup_dirs.py
Creates the directory layout for Brokebase on the VPS.
Run as root (or with sudo): python3 01_setup_dirs.py
"""
import os
import pwd
import grp
import sys

BASE = "/opt/brokebase"

DIRS = [
    BASE,
    f"{BASE}/frontend",          # built static files (dist/) go here
    f"{BASE}/backend",           # compiled backend (dist/) + node_modules
    f"{BASE}/backend/logs",
    f"{BASE}/backend/env",       # holds the real .env, never in git
    "/opt/certs",                # already has cert.pem / key.pem (Cloudflare origin cert)
    "/var/log/brokebase",
]

# Directories that should NOT be world-readable (env files, certs, logs)
RESTRICTED = [f"{BASE}/backend/env", f"{BASE}/backend/logs", "/opt/certs", "/var/log/brokebase"]


def ensure_dir(path: str, mode: int = 0o755):
    os.makedirs(path, exist_ok=True)
    os.chmod(path, mode)
    print(f"  ok  {path}  (mode {oct(mode)})")


def main():
    if os.geteuid() != 0:
        print("Run this as root (sudo python3 01_setup_dirs.py)")
        sys.exit(1)

    print("Creating Brokebase directory layout...")
    for d in DIRS:
        mode = 0o750 if d in RESTRICTED else 0o755
        ensure_dir(d, mode)

    # Create a dedicated, unprivileged system user to run the Node process.
    # Never run the app as root.
    try:
        pwd.getpwnam("brokebase")
        print("  ok  system user 'brokebase' already exists")
    except KeyError:
        os.system("useradd --system --no-create-home --shell /usr/sbin/nologin brokebase")
        print("  ok  created system user 'brokebase'")

    # Hand ownership of the app tree to that user, keep certs root-only readable by the group.
    uid = pwd.getpwnam("brokebase").pw_uid
    gid = grp.getgrnam("brokebase").gr_gid
    for root, dirs, files in os.walk(BASE):
        os.chown(root, uid, gid)
        for f in files:
            os.chown(os.path.join(root, f), uid, gid)

    print("\nDone. Directory tree:")
    os.system(f"find {BASE} -maxdepth 2")


if __name__ == "__main__":
    main()
