#!/usr/bin/env python3
"""
deploy_all.py
Static-site deploy: fetches brokebase.zip from GitHub, installs nginx + node
(build-time only), builds the frontend, deploys the static output, and writes
+ reloads the nginx config with the Cloudflare origin cert in /opt/certs.
No backend service, no database — this is a landing-only static site.

EDIT THIS BEFORE RUNNING:
  ZIP_URL — raw GitHub URL to your brokebase.zip

Run as root, from anywhere:
  python3 deploy_all.py
"""
import os
import subprocess
import sys

# ---- EDIT ME ----
ZIP_URL = "https://github.com/osintbat/project/raw/refs/heads/main/brokebase.zip"
# ------------------

WORK_DIR = "/opt/brokebase_src"
DEPLOY_ROOT = "/opt/brokebase"
DOMAIN = "brokebase.com"


def run(cmd, cwd=None, check=True):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd)
    if check and result.returncode != 0:
        print(f"Command failed: {cmd}")
        sys.exit(1)
    return result.returncode


def step(title):
    print(f"\n== {title} ==")


def main():
    if os.geteuid() != 0:
        print("Run this as root (sudo python3 deploy_all.py)")
        sys.exit(1)

    step("1/6 Base packages")
    run("apt-get update -y")
    run(
        "DEBIAN_FRONTEND=noninteractive apt-get install -y "
        "curl ca-certificates gnupg build-essential ufw fail2ban "
        "unattended-upgrades git unzip"
    )

    step("2/6 Node.js 20 LTS (build-time only, no runtime service)")
    if run("command -v node", check=False) != 0:
        run("curl -fsSL https://deb.nodesource.com/setup_20.x | bash -")
        run("DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs")
    else:
        print("  node already installed, skipping")

    step("3/6 nginx")
    run("DEBIAN_FRONTEND=noninteractive apt-get install -y nginx")
    run("systemctl enable nginx")

    step("4/6 Firewall")
    run("ufw allow OpenSSH", check=False)
    run("ufw allow 'Nginx Full'", check=False)
    run("ufw --force enable", check=False)

    step("5/6 Fetching project and building")
    run(f"rm -rf {WORK_DIR}")
    run(f"mkdir -p {WORK_DIR}")
    run(f"curl -fsSL -o /tmp/brokebase.zip '{ZIP_URL}'")
    run(f"unzip -oq /tmp/brokebase.zip -d {WORK_DIR}")
    src_root = os.path.join(WORK_DIR, "brokebase")
    if not os.path.isdir(src_root):
        src_root = WORK_DIR
    frontend_src = os.path.join(src_root, "frontend")

    run("npm install", cwd=frontend_src)
    run("npm run build", cwd=frontend_src)

    run("id -u brokebase >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin brokebase")
    run(f"mkdir -p {DEPLOY_ROOT}")
    run(f"rm -rf {DEPLOY_ROOT}/dist")
    run(f"cp -r {os.path.join(frontend_src, 'dist')} {DEPLOY_ROOT}/dist")
    run(f"chown -R brokebase:brokebase {DEPLOY_ROOT}")

    step("6/6 nginx + TLS")
    cert_path = "/opt/certs/cert.pem"
    key_path = "/opt/certs/key.pem"
    for p in (cert_path, key_path):
        if not os.path.isfile(p):
            print(f"Missing {p} — cannot write nginx TLS config. Add the cert and rerun.")
            sys.exit(1)

    nginx_conf = f"""# Managed by deploy_all.py — static site, no backend
server {{
    listen 80;
    listen [::]:80;
    server_name {DOMAIN} www.{DOMAIN};
    return 301 https://www.{DOMAIN}$request_uri;
}}

server {{
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name {DOMAIN};
    ssl_certificate     {cert_path};
    ssl_certificate_key {key_path};
    ssl_protocols TLSv1.2 TLSv1.3;
    return 301 https://www.{DOMAIN}$request_uri;
}}

server {{
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name www.{DOMAIN};

    ssl_certificate     {cert_path};
    ssl_certificate_key {key_path};
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!3DES:!RC4;
    ssl_prefer_server_ciphers on;

    set_real_ip_from 0.0.0.0/0;
    real_ip_header CF-Connecting-IP;

    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;

    root {DEPLOY_ROOT}/dist;
    index index.html;

    location / {{
        try_files $uri /index.html;
    }}

    location ~ /\\. {{ deny all; }}
    location ~* \\.(env|log|sql|bak|git)$ {{ deny all; }}
}}
"""
    os.makedirs("/etc/nginx/sites-available", exist_ok=True)
    os.makedirs("/etc/nginx/sites-enabled", exist_ok=True)
    with open(f"/etc/nginx/sites-available/{DOMAIN}", "w") as f:
        f.write(nginx_conf)
    if not os.path.islink(f"/etc/nginx/sites-enabled/{DOMAIN}"):
        os.symlink(f"/etc/nginx/sites-available/{DOMAIN}", f"/etc/nginx/sites-enabled/{DOMAIN}")
    default_site = "/etc/nginx/sites-enabled/default"
    if os.path.exists(default_site):
        os.remove(default_site)

    run("nginx -t")
    run("systemctl reload nginx")

    print(f"\nDone. Visit https://www.{DOMAIN}")


if __name__ == "__main__":
    main()
