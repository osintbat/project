# Brokebase

Static landing page for a project-management mini-SaaS. React + Vite + TypeScript +
Tailwind + MUI, black/white square theme, PixelBlast WebGL background.
No backend, no database — single-page static site.

## Structure

```
brokebase/
├── frontend/          # React + Vite + TS, builds to a static dist/
└── infra/
    └── deploy_all.py  # fetches this zip from GitHub and deploys everything
```

## Deploy (Ubuntu 24.04)

1. Upload this zip to your GitHub repo.
2. Edit `ZIP_URL` at the top of `infra/deploy_all.py` if the path changed.
3. On the VPS, as root:

```bash
python3 deploy_all.py
```

Installs nginx + Node (build-time only), builds the frontend, deploys the static
output to `/opt/brokebase/dist`, and configures nginx with the Cloudflare origin
cert already in `/opt/certs/{cert.pem,key.pem}`.

## Editing the landing page

Main file: `frontend/src/pages/Landing.tsx` — hero + 7 sections + pricing + FAQ.
Background: `frontend/src/components/PixelBlast.tsx`.
Theme: `frontend/src/lib/theme.ts` (MUI) and `frontend/tailwind.config.js`.

After editing, rebuild and redeploy just the frontend:

```bash
cd /opt/brokebase_src/brokebase/frontend && npm run build && \
rm -rf /opt/brokebase/dist && cp -r dist /opt/brokebase/dist && \
chown -R brokebase:brokebase /opt/brokebase
```
