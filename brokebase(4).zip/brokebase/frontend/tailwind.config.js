/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#000000',
          900: '#0a0a0a',
          800: '#141414',
          700: '#1f1f1f',
          600: '#2e2e2e',
          400: '#a3a3a3',
          100: '#f5f5f5'
        }
      },
      fontFamily: {
        display: ['"Anton"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      },
      borderRadius: {
        DEFAULT: '0px'
      }
    }
  },
  plugins: []
};
