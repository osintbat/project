import { ThemeProvider, CssBaseline } from '@mui/material';
import { theme } from '@/lib/theme';
import Landing from '@/pages/Landing';

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Landing />
    </ThemeProvider>
  );
}
