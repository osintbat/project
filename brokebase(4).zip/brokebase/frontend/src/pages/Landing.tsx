import { useState, FormEvent, MouseEvent } from 'react';
import { Box, Container, Typography, Button, TextField, InputAdornment, Chip } from '@mui/material';
import {
  FiMail,
  FiShield,
  FiZap,
  FiLock,
  FiCheckCircle,
  FiAlertTriangle,
  FiUser,
  FiUsers,
  FiBriefcase,
  FiSearch,
  FiBell,
  FiTool,
  FiChevronDown
} from 'react-icons/fi';
import { Menu, MenuItem } from '@mui/material';

const accentPurple = '#7c5fe6';

const modes = [
  { key: 'check', label: 'Check' },
  { key: 'monitor', label: 'Monitor' },
  { key: 'fix', label: 'Fix' }
] as const;

const modeContent = {
  check: {
    eyebrow: 'A one-time lookup.',
    title: 'Check now.',
    body: 'Run a free check against known, publicly disclosed breach compilations. See if your email shows up — nothing more is scanned, nothing else is stored.',
    cta: 'Run a check'
  },
  monitor: {
    eyebrow: 'Ongoing protection.',
    title: 'Monitor continuously.',
    body: 'Once verified, we watch for your email in newly disclosed breaches and alert you the same day — not months after the fact.',
    cta: 'Enable monitoring'
  },
  fix: {
    eyebrow: 'Turn a hit into action.',
    title: 'Fix what is exposed.',
    body: 'Every match comes with the specific fix: change the password on that one service, or enable 2FA where it is supported.',
    cta: 'See remediation steps'
  }
};

const audiences = [
  { icon: FiUser, title: 'Individuals', body: 'Check the email you actually use. Free forever for a single address.' },
  { icon: FiUsers, title: 'Families', body: 'Cover everyone in your household from one dashboard, one bill.' },
  { icon: FiBriefcase, title: 'Small teams', body: 'Know when a work email surfaces in a breach before it becomes an incident.' }
];

export default function Landing() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [mode, setMode] = useState<'check' | 'monitor' | 'fix'>('check');
  const [menuAnchor, setMenuAnchor] = useState<null | { el: HTMLElement; key: string }>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) return;
    setSubmitted(true);
  };

  const openMenu = (key: string) => (e: MouseEvent<HTMLElement>) => setMenuAnchor({ el: e.currentTarget, key });
  const closeMenu = () => setMenuAnchor(null);

  const nav = [
    { key: 'product', label: 'Product', items: ['Check', 'Monitor', 'Fix'] },
    { key: 'resources', label: 'Resources', items: ['How it works', 'FAQ', 'Security'] },
    { key: 'company', label: 'Company', items: ['About', 'Contact'] }
  ];

  const active = modeContent[mode];

  return (
    <Box sx={{ bgcolor: '#0a0710', minHeight: '100%' }}>
      {/* Navbar — same structure as reference: logo, dropdown nav groups, Sign up / primary CTA */}
      <Box
        component="nav"
        sx={{ position: 'sticky', top: 0, zIndex: 50, bgcolor: 'rgba(10,7,16,0.85)', backdropFilter: 'blur(10px)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}
      >
        <Container maxWidth="lg" sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 2 }}>
          <Typography sx={{ fontWeight: 800, letterSpacing: '-0.01em', fontSize: '1.1rem' }}>
            brokebase
          </Typography>
          <Box sx={{ display: { xs: 'none', md: 'flex' }, alignItems: 'center', gap: 3 }}>
            {nav.map((group) => (
              <Box key={group.key}>
                <Button
                  onClick={openMenu(group.key)}
                  endIcon={<FiChevronDown size={14} />}
                  sx={{ color: '#d4d4d8', textTransform: 'none', fontSize: '0.92rem' }}
                >
                  {group.label}
                </Button>
                <Menu
                  anchorEl={menuAnchor?.key === group.key ? menuAnchor.el : null}
                  open={menuAnchor?.key === group.key}
                  onClose={closeMenu}
                  PaperProps={{ sx: { bgcolor: '#151020', border: '1px solid rgba(255,255,255,0.1)' } }}
                >
                  {group.items.map((item) => (
                    <MenuItem key={item} onClick={closeMenu} sx={{ fontSize: '0.9rem' }}>{item}</MenuItem>
                  ))}
                </Menu>
              </Box>
            ))}
            <Button sx={{ color: '#d4d4d8', textTransform: 'none' }}>Pricing</Button>
          </Box>
          <Box sx={{ display: 'flex', gap: 1.5 }}>
            <Button variant="outlined" sx={{ borderColor: 'rgba(255,255,255,0.2)', color: '#fff', textTransform: 'none' }}>Sign In</Button>
            <Button variant="contained" sx={{ bgcolor: accentPurple, textTransform: 'none', '&:hover': { bgcolor: '#6a4dd1' } }}>Check for Free</Button>
          </Box>
        </Container>
      </Box>

      {/* Hero — headline/subhead/CTA left, floating result panel right, same structure as reference */}
      <Container maxWidth="lg" sx={{ pt: { xs: 8, md: 12 }, pb: 10 }}>
        <Box sx={{ display: { md: 'flex' }, alignItems: 'center', gap: 6 }}>
          <Box sx={{ flex: '1 1 480px' }}>
            <Typography sx={{ fontSize: { xs: '2.6rem', md: '3.6rem' }, fontWeight: 800, lineHeight: 1.08, mb: 3 }}>
              Check if your email
              <br />
              has been <Box component="span" sx={{ color: accentPurple }}>breached</Box>
              <Box component="span" sx={{ opacity: 0.5 }}>|</Box>
            </Typography>
            <Typography sx={{ color: '#a3a1ab', fontSize: '1.05rem', maxWidth: 480, mb: 4 }}>
              Unmatched accuracy on a single question: has this email shown up in a known data breach?
              Free, no password ever shown, verified ownership required for full detail.
            </Typography>
            <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', maxWidth: 480 }}>
              <TextField
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                fullWidth
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <FiSearch color="#a3a1ab" />
                    </InputAdornment>
                  ),
                  sx: { bgcolor: 'rgba(255,255,255,0.04)', borderRadius: 1.5 }
                }}
                sx={{ flex: '1 1 220px' }}
              />
              <Button type="submit" variant="contained" size="large" sx={{ bgcolor: accentPurple, px: 4, textTransform: 'none', whiteSpace: 'nowrap', '&:hover': { bgcolor: '#6a4dd1' } }}>
                Check Now
              </Button>
            </Box>
            <Typography sx={{ color: '#6b6875', fontSize: '0.8rem', mt: 2 }}>
              No password ever shown. Verified ownership required for detailed results.
            </Typography>
          </Box>

          {/* Floating result panel — mirrors the reference's "showing results" card, breach status only */}
          <Box sx={{ flex: '1 1 420px', mt: { xs: 6, md: 0 } }}>
            <Box sx={{ borderRadius: 2, border: '1px solid rgba(255,255,255,0.1)', bgcolor: '#120e1c', overflow: 'hidden' }}>
              <Box sx={{ p: 2.5, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <Typography sx={{ fontSize: '0.8rem', color: '#a3a1ab', mb: 1 }}>Showing results for</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'rgba(255,255,255,0.05)', borderRadius: 1, px: 1.5, py: 1 }}>
                  <FiMail size={14} color="#a3a1ab" />
                  <Typography sx={{ fontSize: '0.85rem' }}>{submitted ? email : 'you@example.com'}</Typography>
                </Box>
              </Box>
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
                <Box sx={{ p: 2.5, borderRight: '1px solid rgba(255,255,255,0.08)' }}>
                  <Typography sx={{ fontSize: '0.75rem', color: '#6b6875' }}>Breaches Checked</Typography>
                  <Typography sx={{ fontSize: '1.6rem', fontWeight: 700 }}>800+</Typography>
                </Box>
                <Box sx={{ p: 2.5 }}>
                  <Typography sx={{ fontSize: '0.75rem', color: '#6b6875' }}>Passwords Shown</Typography>
                  <Typography sx={{ fontSize: '1.6rem', fontWeight: 700 }}>0</Typography>
                </Box>
              </Box>
              <Box sx={{ p: 2.5 }}>
                <Typography sx={{ fontSize: '0.75rem', color: '#6b6875', mb: 1.5 }}>Sample match types</Typography>
                {[
                  { name: 'Adobe', status: 'Breached · Oct 2013', bad: true },
                  { name: 'Canva', status: 'Breached · May 2019', bad: true },
                  { name: 'LinkedIn', status: 'Not found', bad: false }
                ].map((row) => (
                  <Box key={row.name} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', py: 1, borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                    <Typography sx={{ fontSize: '0.88rem' }}>{row.name}</Typography>
                    <Chip
                      icon={row.bad ? <FiAlertTriangle size={12} /> : <FiCheckCircle size={12} />}
                      label={row.status}
                      size="small"
                      sx={{ bgcolor: row.bad ? 'rgba(124,95,230,0.18)' : 'transparent', border: row.bad ? 'none' : '1px solid rgba(255,255,255,0.15)', color: '#fff', fontSize: '0.72rem' }}
                    />
                  </Box>
                ))}
                <Typography sx={{ color: '#6b6875', fontSize: '0.72rem', mt: 1.5 }}>
                  Illustrative example. No names, photos, or addresses are ever shown.
                </Typography>
              </Box>
            </Box>
          </Box>
        </Box>
      </Container>

      {/* "Unmatched Accuracy" — 2-col: copy+CTA left, stacked feature cards right */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
        <Box sx={{ display: { md: 'flex' }, gap: 6 }}>
          <Box sx={{ flex: '1 1 420px', mb: { xs: 5, md: 0 } }}>
            <Typography sx={{ fontSize: { xs: '2rem', md: '2.4rem' }, fontWeight: 800, mb: 2, lineHeight: 1.15 }}>
              Unmatched accuracy.
              <br />
              Zero exposure.
            </Typography>
            <Typography sx={{ color: '#a3a1ab', mb: 4, maxWidth: 420 }}>
              A single, verified check against known breach data — built to inform you, never to expose
              anyone else.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Button variant="contained" sx={{ bgcolor: accentPurple, textTransform: 'none', '&:hover': { bgcolor: '#6a4dd1' } }}>Get Started</Button>
              <Button sx={{ color: accentPurple, textTransform: 'none' }} endIcon={<FiChevronDown size={14} style={{ transform: 'rotate(-90deg)' }} />}>Learn More</Button>
            </Box>
          </Box>
          <Box sx={{ flex: '1 1 420px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2.5 }}>
            {[
              { icon: FiZap, title: 'Real-Time Data', body: 'Checked against breach records that are kept current, not a stale annual dump.' },
              { icon: FiLock, title: 'Privacy First', body: 'We never store the content of a match. Only that a match exists.' },
              { icon: FiCheckCircle, title: 'Zero False Positives', body: 'Every hit is validated against the source record before it reaches you.' },
              { icon: FiShield, title: 'Verified Only', body: 'Full detail unlocks only after you confirm ownership of the inbox.' }
            ].map((f) => {
              const Icon = f.icon;
              return (
                <Box key={f.title} sx={{ p: 3, border: '1px solid rgba(255,255,255,0.1)', borderRadius: 2, bgcolor: '#120e1c' }}>
                  <Icon size={22} color={accentPurple} style={{ marginBottom: 12 }} />
                  <Typography sx={{ fontWeight: 700, mb: 0.75, fontSize: '0.95rem' }}>{f.title}</Typography>
                  <Typography sx={{ color: '#a3a1ab', fontSize: '0.82rem', lineHeight: 1.5 }}>{f.body}</Typography>
                </Box>
              );
            })}
          </Box>
        </Box>
      </Container>

      {/* Mode tabs — Check / Monitor / Fix, replacing the reference's Who/Where/When,
          but every mode still operates only on the user's own verified email */}
      <Container maxWidth="lg" sx={{ py: { xs: 6, md: 8 } }}>
        <Box sx={{ display: 'inline-flex', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 1.5, p: 0.5, mb: 6 }}>
          {modes.map((m) => (
            <Button
              key={m.key}
              onClick={() => setMode(m.key)}
              sx={{
                textTransform: 'none',
                px: 2.5,
                py: 0.75,
                borderRadius: 1,
                color: mode === m.key ? '#0a0710' : '#d4d4d8',
                bgcolor: mode === m.key ? '#fff' : 'transparent',
                '&:hover': { bgcolor: mode === m.key ? '#fff' : 'rgba(255,255,255,0.06)' }
              }}
            >
              {m.label}
            </Button>
          ))}
        </Box>
        <Box sx={{ display: { md: 'flex' }, alignItems: 'center', gap: 6 }}>
          <Box sx={{ flex: '1 1 420px', mb: { xs: 5, md: 0 } }}>
            <Typography sx={{ color: accentPurple, fontWeight: 600, mb: 1 }}>{active.eyebrow}</Typography>
            <Typography sx={{ fontSize: { xs: '2rem', md: '2.4rem' }, fontWeight: 800, mb: 2 }}>{active.title}</Typography>
            <Typography sx={{ color: '#a3a1ab', maxWidth: 460, mb: 3 }}>{active.body}</Typography>
            <Button variant="contained" sx={{ bgcolor: accentPurple, textTransform: 'none', '&:hover': { bgcolor: '#6a4dd1' } }}>
              {active.cta}
            </Button>
          </Box>
          <Box sx={{ flex: '1 1 420px' }}>
            <Box sx={{ border: '1px solid rgba(255,255,255,0.1)', borderRadius: 2, bgcolor: '#120e1c', p: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 220 }}>
              {mode === 'check' && <FiSearch size={64} color={accentPurple} opacity={0.6} />}
              {mode === 'monitor' && <FiBell size={64} color={accentPurple} opacity={0.6} />}
              {mode === 'fix' && <FiTool size={64} color={accentPurple} opacity={0.6} />}
            </Box>
          </Box>
        </Box>
      </Container>

      {/* Result cards — same grid structure as reference, breach status only */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
        <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.2rem' }, fontWeight: 800, textAlign: 'center', mb: 6 }}>
          100% Accurate Breach Results.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 3 }}>
          {[
            { name: 'Adobe', date: 'Oct 2013', fields: 'Email, hashed password', status: 'Breached' },
            { name: 'Canva', date: 'May 2019', fields: 'Email, username', status: 'Breached' }
          ].map((r) => (
            <Box key={r.name} sx={{ p: 3, border: '1px solid rgba(255,255,255,0.1)', borderRadius: 2, bgcolor: '#120e1c' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography sx={{ fontWeight: 700 }}>{r.name}</Typography>
                <Chip label={r.status} size="small" sx={{ bgcolor: 'rgba(124,95,230,0.18)', color: '#fff', fontSize: '0.7rem' }} />
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', py: 1, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                <Typography sx={{ color: '#6b6875', fontSize: '0.85rem' }}>Date</Typography>
                <Typography sx={{ fontSize: '0.85rem' }}>{r.date}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', py: 1, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                <Typography sx={{ color: '#6b6875', fontSize: '0.85rem' }}>Data exposed</Typography>
                <Typography sx={{ fontSize: '0.85rem' }}>{r.fields}</Typography>
              </Box>
            </Box>
          ))}
        </Box>
      </Container>

      {/* "Built for" — replaces the reference's Government/Law Enforcement/Media sector framing
          with legitimate personal-security audiences */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
        <Typography sx={{ fontSize: { xs: '1.8rem', md: '2.2rem' }, fontWeight: 800, textAlign: 'center', mb: 1 }}>
          Protection for everyone who has an inbox.
        </Typography>
        <Typography sx={{ color: '#a3a1ab', textAlign: 'center', mb: 6 }}>
          Simple enough for one person, flexible enough for a household or a small team.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 3 }}>
          {audiences.map((a) => {
            const Icon = a.icon;
            return (
              <Box key={a.title} sx={{ p: 4, border: '1px solid rgba(255,255,255,0.1)', borderRadius: 2, bgcolor: '#120e1c', textAlign: 'center' }}>
                <Icon size={28} color={accentPurple} style={{ marginBottom: 16 }} />
                <Typography sx={{ fontWeight: 700, fontSize: '1.1rem', mb: 1 }}>{a.title}</Typography>
                <Typography sx={{ color: '#a3a1ab', fontSize: '0.88rem', mb: 2.5 }}>{a.body}</Typography>
                <Button sx={{ color: accentPurple, textTransform: 'none' }}>Get Free Access</Button>
              </Box>
            );
          })}
        </Box>
      </Container>

      {/* Newsletter + footer, same structure as reference */}
      <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.08)', bgcolor: '#0d0912' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 6, md: 8 } }}>
          <Box sx={{ display: { md: 'flex' }, justifyContent: 'space-between', alignItems: 'center', gap: 4, mb: 6 }}>
            <Box>
              <Typography sx={{ fontSize: '1.3rem', fontWeight: 800, mb: 0.5 }}>Get our security newsletter.</Typography>
              <Typography sx={{ color: '#a3a1ab', fontSize: '0.9rem' }}>Practical breach and password-hygiene tips, twice a month.</Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1.5, mt: { xs: 3, md: 0 }, width: { xs: '100%', md: 'auto' } }}>
              <TextField placeholder="Email" size="small" sx={{ minWidth: 220, bgcolor: 'rgba(255,255,255,0.04)', borderRadius: 1 }} />
              <Button variant="contained" sx={{ bgcolor: accentPurple, textTransform: 'none', '&:hover': { bgcolor: '#6a4dd1' } }}>Subscribe</Button>
            </Box>
          </Box>

          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(4, 1fr)' }, gap: 4, borderTop: '1px solid rgba(255,255,255,0.08)', pt: 5 }}>
            {[
              { title: 'Product', items: ['Check', 'Monitor', 'Fix', 'Pricing'] },
              { title: 'Resources', items: ['How it works', 'FAQ', 'Security'] },
              { title: 'Company', items: ['About', 'Contact'] },
              { title: 'Legal', items: ['Terms of Use', 'Privacy Policy'] }
            ].map((col) => (
              <Box key={col.title}>
                <Typography sx={{ fontWeight: 700, mb: 1.5, fontSize: '0.9rem' }}>{col.title}</Typography>
                {col.items.map((item) => (
                  <Typography key={item} sx={{ color: '#a3a1ab', fontSize: '0.85rem', mb: 1, '&:hover': { color: '#fff' }, cursor: 'pointer' }}>
                    {item}
                  </Typography>
                ))}
              </Box>
            ))}
          </Box>

          <Box sx={{ borderTop: '1px solid rgba(255,255,255,0.08)', mt: 5, pt: 3, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}>
            <Typography sx={{ color: '#6b6875', fontSize: '0.8rem' }}>© {new Date().getFullYear()} Brokebase. All rights reserved.</Typography>
            <Typography sx={{ color: '#6b6875', fontSize: '0.8rem' }}>Check your own exposure — never anyone else&apos;s.</Typography>
          </Box>
        </Container>
      </Box>
    </Box>
  );
}
