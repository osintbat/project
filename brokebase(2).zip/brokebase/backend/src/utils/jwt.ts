import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export type AccessTokenPayload = { sub: string; email: string };

// Explicit algorithm allow-list — never accept "none" or let the algorithm
// be chosen by the token itself (the classic "alg: none" bypass).
const ALGORITHM: jwt.Algorithm = 'HS256';

export function signAccessToken(payload: AccessTokenPayload): string {
  const options: jwt.SignOptions = {
    algorithm: ALGORITHM,
    expiresIn: env.JWT_EXPIRES_IN as jwt.SignOptions['expiresIn']
  };
  return jwt.sign(payload, env.JWT_SECRET, options);
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  const decoded = jwt.verify(token, env.JWT_SECRET, { algorithms: [ALGORITHM] });
  return decoded as AccessTokenPayload;
}
