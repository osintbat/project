import pg from 'pg';
import { env } from '../config/env.js';

// Single shared pool. All queries elsewhere MUST use parameterized placeholders ($1, $2…)
// — never string-concatenate user input into SQL. This is the actual SQLi defense.
export const pool = new pg.Pool({
  connectionString: env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  // DB runs on the same host over loopback (127.0.0.1) — no TLS needed here.
  // If you later point this at a managed/remote Postgres, re-enable SSL with a proper CA.
  ssl: false
});

pool.on('error', (err) => {
  // Never let an idle client error crash the process silently swallow secrets.
  console.error('Unexpected PG pool error', err.message);
});
