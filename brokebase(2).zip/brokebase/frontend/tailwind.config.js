/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#08090b',
          900: '#0d0f12',
          800: '#15171b',
          700: '#1f2227',
          600: '#2a2e35'
        },
        ink: {
          100: '#f4f5f7',
          400: '#9aa1ab',
          500: '#6b7280'
        },
        signal: {
          DEFAULT: '#B497CF',
          dim: '#9b7ab8'
        },
        brand: {
          DEFAULT: '#8b5cf6',
          light: '#B497CF',
          dark: '#6d28d9'
        },
        danger: '#f87171'
      },
      fontFamily: {
        display: ['"Anton"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      }
    }
  },
  plugins: []
};
