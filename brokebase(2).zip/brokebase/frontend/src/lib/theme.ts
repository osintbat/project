import { createTheme } from '@mui/material/styles';

// Token system per la skill di design: dark, signal teal come unico accento.
export const theme = createTheme({
  palette: {
    mode: 'dark',
    background: { default: '#0a0710', paper: '#120d1c' },
    primary: { main: '#B497CF' },
    error: { main: '#f87171' },
    text: { primary: '#f4f2f7', secondary: '#a89bb8' }
  },
  typography: {
    fontFamily: '"Inter", sans-serif',
    h1: { fontFamily: '"Anton", sans-serif', fontWeight: 400, textTransform: 'uppercase' },
    h2: { fontFamily: '"Anton", sans-serif', fontWeight: 400, textTransform: 'uppercase' },
    h3: { fontWeight: 800 },
    button: { textTransform: 'none', fontWeight: 700 }
  },
  shape: { borderRadius: 10 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 10 }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none', border: '1px solid rgba(180,151,207,0.15)' }
      }
    }
  }
});
