import { Link } from 'react-router-dom';
import { Box, Container, Typography, Button, Chip } from '@mui/material';
import {
  FiLayers,
  FiZap,
  FiCode,
  FiPackage,
  FiCopy,
  FiSliders,
  FiGrid,
  FiCheckCircle,
  FiStar
} from 'react-icons/fi';
import Plasma from '@/components/Plasma';

const categories = [
  { icon: FiGrid, name: 'Layout', count: 24 },
  { icon: FiSliders, name: 'Forms', count: 31 },
  { icon: FiLayers, name: 'Navigation', count: 18 },
  { icon: FiZap, name: 'Feedback', count: 22 },
  { icon: FiPackage, name: 'Data display', count: 27 },
  { icon: FiCode, name: 'Overlays', count: 16 }
];

const featured = [
  { name: 'Command Palette', tag: 'New', desc: 'Keyboard-driven search with fuzzy matching and grouped results.' },
  { name: 'Data Table', tag: 'Popular', desc: 'Sortable, filterable table with virtualized rows for large datasets.' },
  { name: 'Toast Stack', tag: '', desc: 'Stacked notifications with swipe-to-dismiss and auto-collapse.' },
  { name: 'Multi-step Form', tag: '', desc: 'Wizard layout with per-step validation and progress indicator.' },
  { name: 'Kanban Board', tag: 'Popular', desc: 'Drag-and-drop columns and cards, keyboard accessible.' },
  { name: 'Date Range Picker', tag: '', desc: 'Dual-calendar range selection with presets.' }
];

const why = [
  { icon: FiCheckCircle, title: 'Copy, not install', body: 'Every component is source you own — paste it in and modify freely, no black-box package.' },
  { icon: FiCode, title: 'TypeScript first', body: 'Full prop types and JSDoc on every component. Your editor tells you what it needs.' },
  { icon: FiSliders, title: 'Tailwind native', body: 'Styled with utility classes you already know, no separate theming language to learn.' },
  { icon: FiZap, title: 'Accessible by default', body: 'Keyboard navigation, focus states, and ARIA roles built in, not bolted on.' }
];

const steps = [
  { n: '01', title: 'Browse the catalog', body: 'Filter by category, preview live, check the props before you commit.' },
  { n: '02', title: 'Copy the source', body: 'One click copies the full component — no install, no dependency to track.' },
  { n: '03', title: 'Ship it', body: 'Paste into your project and adjust classes to match your design system.' }
];

const testimonials = [
  { quote: 'Cut our internal tools build time in half. The table and form components alone paid for the subscription.', name: 'Frontend lead, seed-stage startup' },
  { quote: 'Finally a component set that doesn\u2019t fight Tailwind. Everything just slots in.', name: 'Freelance product engineer' },
  { quote: 'The accessibility defaults saved us an audit cycle before launch.', name: 'Eng manager, B2B SaaS' }
];

const tiers = [
  { title: 'Free', price: '0', features: ['12 components', 'Community support', 'MIT license', 'Copy & paste access'], cta: 'Start free', highlight: false },
  { title: 'Pro', price: '19', features: ['All 138 components', 'New components monthly', 'Figma source files', 'Priority support', 'Private Discord'], cta: 'Go Pro', highlight: true },
  { title: 'Team', price: '49', features: ['Everything in Pro', 'Up to 10 seats', 'Shared component library', 'Onboarding call'], cta: 'Contact us', highlight: false }
];

export default function Landing() {
  return (
    <Box sx={{ bgcolor: 'transparent', position: 'relative' }}>
      <Box sx={{ position: 'fixed', inset: 0, zIndex: 0, opacity: 0.5 }}>
        <Plasma
          color="#B497CF"
          speed={1}
          direction="forward"
          scale={1}
          opacity={0.85}
          mouseInteractive={false}
          renderScale={0.55}
          maxDpr={1.5}
          targetFps={60}
          iterations={60}
        />
      </Box>
      <Box sx={{ position: 'relative', zIndex: 1 }}>
      {/* Hero */}
      <Box sx={{ position: 'relative', height: { xs: 560, md: 680 }, overflow: 'hidden' }}>
        <Box sx={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(10,7,16,0.1) 0%, #0a0710 100%)' }} />
        <Container
          maxWidth="lg"
          sx={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}
        >
          <Typography
            className="font-display"
            sx={{ fontSize: { xs: '3rem', md: '5.5rem' }, lineHeight: 0.95, maxWidth: 900, mb: 3, letterSpacing: '0.01em' }}
          >
            REACT COMPONENTS, READY TO SHIP.
          </Typography>
          <Typography sx={{ color: '#a89bb8', fontSize: '1.15rem', maxWidth: 540, mb: 4 }}>
            Browse, preview, and copy production-ready components. TypeScript and Tailwind out of the box —
            no package to install, no black box to debug.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
            <Button
              component={Link}
              to="/register"
              variant="contained"
              size="large"
              sx={{ px: 4, bgcolor: '#8b5cf6', '&:hover': { bgcolor: '#6d28d9' } }}
            >
              Browse components
            </Button>
            <Button component={Link} to="/login" variant="outlined" color="inherit" size="large" sx={{ px: 4 }}>
              I have an account
            </Button>
          </Box>
        </Container>
      </Box>

      {/* Section 1 — Categories */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
        <Typography sx={{ color: '#B497CF', fontSize: '0.8rem', letterSpacing: '0.12em', mb: 1 }} className="font-mono">
          CATEGORIES
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.7rem', md: '2.1rem' }, fontWeight: 800, mb: 5, maxWidth: 620 }}>
          Six categories, every piece of UI you'll actually build.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(6, 1fr)' }, gap: 2 }}>
          {categories.map((c) => {
            const Icon = c.icon;
            return (
              <Box
                key={c.name}
                sx={{
                  p: 3,
                  border: '1px solid rgba(180,151,207,0.15)',
                  borderRadius: 2,
                  bgcolor: 'rgba(18,13,28,0.55)',
                  textAlign: 'center',
                  transition: 'all 0.2s ease',
                  '&:hover': { borderColor: 'rgba(180,151,207,0.5)', bgcolor: 'rgba(23,15,38,0.7)' }
                }}
              >
                <Icon size={22} color="#B497CF" style={{ marginBottom: 10 }} />
                <Typography sx={{ fontSize: '0.9rem', fontWeight: 700 }}>{c.name}</Typography>
                <Typography sx={{ fontSize: '0.75rem', color: '#6b6078' }}>{c.count} components</Typography>
              </Box>
            );
          })}
        </Box>
      </Container>

      {/* Section 2 — Featured components, cards joined into one panel */}
      <Box sx={{ borderTop: '1px solid rgba(180,151,207,0.1)', bgcolor: 'rgba(13,9,22,0.55)' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
          <Typography sx={{ color: '#B497CF', fontSize: '0.8rem', letterSpacing: '0.12em', mb: 1 }} className="font-mono">
            FEATURED
          </Typography>
          <Typography sx={{ fontSize: { xs: '1.7rem', md: '2.1rem' }, fontWeight: 800, mb: 5, maxWidth: 620 }}>
            The ones people copy first.
          </Typography>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' },
              border: '1px solid rgba(180,151,207,0.15)',
              borderRadius: 2,
              overflow: 'hidden'
            }}
          >
            {featured.map((f, i) => (
              <Box
                key={f.name}
                sx={{
                  p: 3.5,
                  bgcolor: i % 2 === 0 ? 'rgba(18,13,28,0.55)' : 'rgba(15,10,25,0.5)',
                  borderRight: { md: i % 3 !== 2 ? '1px solid rgba(180,151,207,0.15)' : 'none' },
                  borderBottom: '1px solid rgba(180,151,207,0.15)',
                  '&:hover': { bgcolor: 'rgba(23,15,38,0.7)' }
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                  <Typography sx={{ fontWeight: 700 }}>{f.name}</Typography>
                  {f.tag && (
                    <Chip label={f.tag} size="small" sx={{ bgcolor: 'rgba(180,151,207,0.15)', color: '#B497CF', fontSize: '0.7rem' }} />
                  )}
                </Box>
                <Typography sx={{ color: '#a89bb8', fontSize: '0.88rem', lineHeight: 1.55, mb: 2 }}>{f.desc}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, color: '#6b6078', fontSize: '0.78rem' }} className="font-mono">
                  <FiCopy size={13} /> copy source
                </Box>
              </Box>
            ))}
          </Box>
        </Container>
      </Box>

      {/* Section 3 — Why this over a UI kit */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
        <Typography sx={{ color: '#B497CF', fontSize: '0.8rem', letterSpacing: '0.12em', mb: 1 }} className="font-mono">
          WHY BROKEBASE
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.7rem', md: '2.1rem' }, fontWeight: 800, mb: 5, maxWidth: 620 }}>
          Not a dependency. Your code, from the first paste.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 3 }}>
          {why.map((w) => {
            const Icon = w.icon;
            return (
              <Box key={w.title} sx={{ display: 'flex', gap: 2.5, p: 3, border: '1px solid rgba(180,151,207,0.15)', borderRadius: 2, bgcolor: 'rgba(18,13,28,0.55)' }}>
                <Box sx={{ flexShrink: 0, width: 44, height: 44, borderRadius: '10px', bgcolor: 'rgba(139,92,246,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#B497CF' }}>
                  <Icon size={20} />
                </Box>
                <Box>
                  <Typography sx={{ fontWeight: 700, mb: 0.5 }}>{w.title}</Typography>
                  <Typography sx={{ color: '#a89bb8', fontSize: '0.9rem', lineHeight: 1.55 }}>{w.body}</Typography>
                </Box>
              </Box>
            );
          })}
        </Box>
      </Container>

      {/* Section 4 — How it works, real sequence so numbering earns its place */}
      <Box sx={{ borderTop: '1px solid rgba(180,151,207,0.1)', bgcolor: 'rgba(13,9,22,0.55)' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
          <Typography sx={{ color: '#B497CF', fontSize: '0.8rem', letterSpacing: '0.12em', mb: 1 }} className="font-mono">
            HOW IT WORKS
          </Typography>
          <Typography sx={{ fontSize: { xs: '1.7rem', md: '2.1rem' }, fontWeight: 800, mb: 6, maxWidth: 620 }}>
            Three steps, no scaffolding CLI.
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 4 }}>
            {steps.map((s) => (
              <Box key={s.n}>
                <Typography className="font-display tabular" sx={{ fontSize: '3rem', color: 'rgba(180,151,207,0.35)', mb: 1, lineHeight: 1 }}>
                  {s.n}
                </Typography>
                <Typography sx={{ fontWeight: 700, mb: 1 }}>{s.title}</Typography>
                <Typography sx={{ color: '#a89bb8', fontSize: '0.9rem', lineHeight: 1.6 }}>{s.body}</Typography>
              </Box>
            ))}
          </Box>
        </Container>
      </Box>

      {/* Section 5 — Testimonials */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 10 } }}>
        <Typography sx={{ color: '#B497CF', fontSize: '0.8rem', letterSpacing: '0.12em', mb: 1 }} className="font-mono">
          WHO'S USING IT
        </Typography>
        <Typography sx={{ fontSize: { xs: '1.7rem', md: '2.1rem' }, fontWeight: 800, mb: 5, maxWidth: 620 }}>
          Teams shipping faster with it.
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 3 }}>
          {testimonials.map((t) => (
            <Box key={t.name} sx={{ p: 3, border: '1px solid rgba(180,151,207,0.15)', borderRadius: 2, bgcolor: 'rgba(18,13,28,0.55)' }}>
              <Box sx={{ display: 'flex', gap: 0.5, mb: 1.5, color: '#B497CF' }}>
                {[...Array(5)].map((_, i) => <FiStar key={i} size={13} fill="#B497CF" />)}
              </Box>
              <Typography sx={{ fontSize: '0.92rem', lineHeight: 1.6, mb: 2 }}>&ldquo;{t.quote}&rdquo;</Typography>
              <Typography sx={{ fontSize: '0.8rem', color: '#6b6078' }}>{t.name}</Typography>
            </Box>
          ))}
        </Box>
      </Container>

      {/* Section 6 — Pricing */}
      <Box sx={{ borderTop: '1px solid rgba(180,151,207,0.1)', bgcolor: 'rgba(13,9,22,0.55)' }}>
        <Container maxWidth="lg" sx={{ py: { xs: 8, md: 11 } }}>
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Typography sx={{ color: '#B497CF', fontSize: '0.8rem', letterSpacing: '0.12em', mb: 1 }} className="font-mono">
              PRICING
            </Typography>
            <Typography sx={{ fontSize: { xs: '1.9rem', md: '2.4rem' }, fontWeight: 800 }}>
              Simple pricing, cancel anytime.
            </Typography>
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' }, gap: 3, alignItems: 'stretch' }}>
            {tiers.map((tier) => (
              <Box
                key={tier.title}
                sx={{
                  p: 4,
                  borderRadius: 3,
                  border: tier.highlight ? '1px solid #8b5cf6' : '1px solid rgba(180,151,207,0.15)',
                  bgcolor: tier.highlight ? 'rgba(23,15,38,0.7)' : 'rgba(18,13,28,0.55)',
                  position: 'relative',
                  display: 'flex',
                  flexDirection: 'column'
                }}
              >
                {tier.highlight && (
                  <Chip label="Most popular" size="small" sx={{ position: 'absolute', top: -12, left: 24, bgcolor: '#8b5cf6', color: '#fff', fontWeight: 700 }} />
                )}
                <Typography sx={{ fontWeight: 700, mb: 1 }}>{tier.title}</Typography>
                <Box sx={{ display: 'flex', alignItems: 'baseline', mb: 3 }}>
                  <Typography className="font-display" sx={{ fontSize: '2.6rem' }}>${tier.price}</Typography>
                  <Typography sx={{ color: '#6b6078', ml: 1 }}>/ month</Typography>
                </Box>
                <Box sx={{ flexGrow: 1, mb: 3 }}>
                  {tier.features.map((f) => (
                    <Box key={f} sx={{ display: 'flex', gap: 1.25, alignItems: 'center', py: 0.75 }}>
                      <FiCheckCircle size={16} color={tier.highlight ? '#B497CF' : '#8b5cf6'} />
                      <Typography sx={{ fontSize: '0.9rem', color: '#d8cfe3' }}>{f}</Typography>
                    </Box>
                  ))}
                </Box>
                <Button
                  component={Link}
                  to="/register"
                  fullWidth
                  variant={tier.highlight ? 'contained' : 'outlined'}
                  color="inherit"
                  sx={tier.highlight ? { bgcolor: '#8b5cf6', '&:hover': { bgcolor: '#6d28d9' } } : {}}
                >
                  {tier.cta}
                </Button>
              </Box>
            ))}
          </Box>
        </Container>
      </Box>

      <Box sx={{ borderTop: '1px solid rgba(180,151,207,0.1)', py: 3 }}>
        <Container maxWidth="lg">
          <Typography sx={{ color: '#6b6078', fontSize: '0.85rem' }}>
            © {new Date().getFullYear()} Brokebase. Components you own, not a dependency you owe.
          </Typography>
        </Container>
      </Box>
      </Box>
    </Box>
  );
}
