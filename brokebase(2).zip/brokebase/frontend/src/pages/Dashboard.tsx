import { useEffect, useState, FormEvent } from 'react';
import {
  Container, Box, Typography, Paper, TextField, Button, Grid,
  List, ListItem, ListItemText, IconButton, Alert, MenuItem
} from '@mui/material';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { api } from '@/lib/api';
import { expenseSchema } from '@/lib/validation';
import { useAuth } from '@/store/auth';

type Expense = { id: string; label: string; amount: number; category: string; date: string };
type Budget = { id: string; category: string; limit: number; spent: number };

const CATEGORIES = ['Food', 'Rent', 'Transport', 'Subscriptions', 'Fun', 'Other'];

export default function Dashboard() {
  const { user } = useAuth();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [label, setLabel] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));

  const load = async () => {
    try {
      const [expRes, budRes] = await Promise.all([
        api.get<{ expenses: Expense[] }>('/expenses'),
        api.get<{ budgets: Budget[] }>('/budgets')
      ]);
      setExpenses(expRes.data.expenses);
      setBudgets(budRes.data.budgets);
    } catch {
      setError('Could not load your data. Try refreshing.');
    }
  };

  useEffect(() => { load(); }, []);

  const handleAddExpense = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    const parsed = expenseSchema.safeParse({ label, amount: Number(amount), category, date });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? 'Check the expense fields');
      return;
    }
    try {
      await api.post('/expenses', parsed.data);
      setLabel(''); setAmount('');
      load();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? 'Could not add expense');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.delete(`/expenses/${id}`);
      load();
    } catch {
      setError('Could not delete that expense');
    }
  };

  const totalSpent = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h2" sx={{ fontSize: '1.9rem', mb: 0.5 }}>
        Hey{user?.name ? `, ${user.name}` : ''}.
      </Typography>
      <Typography sx={{ color: '#9aa1ab', mb: 4 }}>
        You've logged <span className="tabular text-signal">${totalSpent.toFixed(2)}</span> this month.
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

      <Grid container spacing={3}>
        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 3, bgcolor: '#0d0f12' }} component="form" onSubmit={handleAddExpense} noValidate>
            <Typography variant="h3" sx={{ fontSize: '1.1rem', mb: 2 }}>Add expense</Typography>
            <TextField fullWidth label="What was it" value={label} onChange={(e) => setLabel(e.target.value)} sx={{ mb: 2 }} required />
            <TextField fullWidth label="Amount" type="number" inputProps={{ step: '0.01', min: 0 }} value={amount} onChange={(e) => setAmount(e.target.value)} sx={{ mb: 2 }} required />
            <TextField fullWidth select label="Category" value={category} onChange={(e) => setCategory(e.target.value)} sx={{ mb: 2 }}>
              {CATEGORIES.map((c) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
            </TextField>
            <TextField fullWidth label="Date" type="date" value={date} onChange={(e) => setDate(e.target.value)} sx={{ mb: 3 }} InputLabelProps={{ shrink: true }} required />
            <Button fullWidth type="submit" variant="contained">Add</Button>
          </Paper>

          <Paper sx={{ p: 3, mt: 3, bgcolor: '#0d0f12' }}>
            <Typography variant="h3" sx={{ fontSize: '1.1rem', mb: 2 }}>Budgets</Typography>
            {budgets.length === 0 && (
              <Typography sx={{ color: '#6b7280', fontSize: '0.9rem' }}>
                No budgets set yet. Add one from your category spend once you've logged expenses.
              </Typography>
            )}
            {budgets.map((b) => {
              const pct = Math.min(100, (b.spent / b.limit) * 100);
              const over = b.spent > b.limit;
              return (
                <Box key={b.id} sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography sx={{ fontSize: '0.9rem' }}>{b.category}</Typography>
                    <Typography className="tabular" sx={{ fontSize: '0.9rem', color: over ? '#f87171' : '#9aa1ab' }}>
                      ${b.spent.toFixed(2)} / ${b.limit.toFixed(2)}
                    </Typography>
                  </Box>
                  <Box sx={{ height: 6, bgcolor: '#1f2227', borderRadius: 1, overflow: 'hidden' }}>
                    <Box sx={{ width: `${pct}%`, height: '100%', bgcolor: over ? '#f87171' : '#5eead4' }} />
                  </Box>
                </Box>
              );
            })}
          </Paper>
        </Grid>

        <Grid item xs={12} md={7}>
          <Paper sx={{ p: 3, bgcolor: '#0d0f12' }}>
            <Typography variant="h3" sx={{ fontSize: '1.1rem', mb: 1 }}>Recent expenses</Typography>
            <List>
              {expenses.length === 0 && (
                <Typography sx={{ color: '#6b7280', fontSize: '0.9rem', py: 2 }}>
                  Nothing logged yet. Add your first expense on the left.
                </Typography>
              )}
              {expenses.map((exp) => (
                <ListItem
                  key={exp.id}
                  divider
                  secondaryAction={
                    <IconButton edge="end" onClick={() => handleDelete(exp.id)} aria-label={`Delete ${exp.label}`}>
                      <DeleteOutlineIcon fontSize="small" sx={{ color: '#6b7280' }} />
                    </IconButton>
                  }
                >
                  <ListItemText
                    primary={exp.label}
                    secondary={`${exp.category} · ${exp.date}`}
                    primaryTypographyProps={{ fontSize: '0.95rem' }}
                    secondaryTypographyProps={{ fontSize: '0.8rem', color: '#6b7280' }}
                  />
                  <Typography className="tabular" sx={{ mr: 2 }}>${exp.amount.toFixed(2)}</Typography>
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
}
