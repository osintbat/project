#!/usr/bin/env python3
"""
04_upgrade_landing.py
Redesigns the Brokebase landing page: connected feature-card grid, react-icons,
richer brand-blue color, "how it works" sequence, CTA band. Installs react-icons,
rebuilds the frontend, and redeploys to /opt/brokebase/frontend/dist (nginx root).

Run as root, from the repo checkout (e.g. /opt/brokebase/brokebase):
  python3 infra/04_upgrade_landing.py
"""
import os
import subprocess
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_SRC = os.path.join(REPO_ROOT, "frontend")
DEPLOY_ROOT = "/opt/brokebase/frontend"

LANDING_TSX = 'import { Link } from \'react-router-dom\';\nimport { Box, Container, Typography, Button } from \'@mui/material\';\nimport {\n  FiTrendingDown,\n  FiBell,\n  FiPieChart,\n  FiLock,\n  FiClock,\n  FiTarget,\n  FiZap,\n  FiSmartphone\n} from \'react-icons/fi\';\nimport FloatingLines from \'@/components/FloatingLines\';\n\nconst features = [\n  { icon: FiTrendingDown, title: \'Every expense, tagged in seconds\', body: \'Log spending as it happens. No spreadsheets, no manual sorting at month-end.\' },\n  { icon: FiTarget, title: \'Budgets that push back\', body: \'Set a limit per category. Brokebase warns you before you blow it, not after.\' },\n  { icon: FiPieChart, title: \'Where the money actually goes\', body: \'A running read on your month — not a report you have to go looking for.\' },\n  { icon: FiBell, title: \'Nudges, not nagging\', body: "You\'ll know you\'re close to a limit before it becomes a problem." },\n  { icon: FiLock, title: \'Your data, locked down\', body: \'Encrypted sessions, hashed passwords, nothing sold, nothing shared.\' },\n  { icon: FiClock, title: \'Two minutes a day, tops\', body: \'Built to be fast enough that you actually keep doing it.\' },\n  { icon: FiZap, title: \'Instant category totals\', body: \'See what a category costs you this month the second you open the app.\' },\n  { icon: FiSmartphone, title: \'Works wherever you are\', body: \'Log an expense from your phone the moment you pay for something.\' }\n];\n\nconst steps = [\n  { n: \'01\', title: \'Set your budgets\', body: \'Pick your categories — rent, food, transport — and cap what each one can cost you this month.\' },\n  { n: \'02\', title: \'Log as you spend\', body: \'Ten seconds per expense. Amount, category, done.\' },\n  { n: \'03\', title: \'See it before it hurts\', body: \'Brokebase shows you the gap between what you have left and what the month still owes.\' }\n];\n\nexport default function Landing() {\n  return (\n    <Box sx={{ bgcolor: \'#08090b\' }}>\n      {/* Hero */}\n      <Box sx={{ position: \'relative\', height: { xs: 520, md: 680 }, overflow: \'hidden\' }}>\n        <Box\n          sx={{\n            position: \'absolute\',\n            inset: 0,\n            background: \'radial-gradient(ellipse at 30% 20%, rgba(0,129,217,0.35), transparent 60%), radial-gradient(ellipse at 80% 70%, rgba(94,234,212,0.18), transparent 55%)\'\n          }}\n        />\n        <Box sx={{ position: \'absolute\', inset: 0 }}>\n          <FloatingLines\n            enabledWaves={[\'top\', \'middle\', \'bottom\']}\n            lineCount={9}\n            lineDistance={8}\n            bendRadius={8}\n            bendStrength={-2}\n            interactive\n            parallax\n            animationSpeed={1}\n            gradientStart="#0081d9"\n            gradientMid="#3fa9f5"\n            gradientEnd="#5eead4"\n            mixBlendMode="screen"\n          />\n        </Box>\n        <Container\n          maxWidth="lg"\n          sx={{ position: \'relative\', height: \'100%\', display: \'flex\', flexDirection: \'column\', justifyContent: \'center\' }}\n        >\n          <Typography\n            className="font-mono"\n            sx={{ color: \'#3fa9f5\', fontSize: \'0.8rem\', letterSpacing: \'0.12em\', mb: 2 }}\n          >\n            BUDGETING, NOT VIBES\n          </Typography>\n          <Typography\n            variant="h1"\n            sx={{\n              fontSize: { xs: \'2.75rem\', md: \'4.5rem\' },\n              lineHeight: 1.03,\n              maxWidth: 820,\n              mb: 3,\n              background: \'linear-gradient(135deg, #f4f5f7 40%, #3fa9f5 100%)\',\n              WebkitBackgroundClip: \'text\',\n              WebkitTextFillColor: \'transparent\'\n            }}\n          >\n            Budgeting for people who are actually broke.\n          </Typography>\n          <Typography sx={{ color: \'#9aa1ab\', fontSize: \'1.15rem\', maxWidth: 540, mb: 4 }}>\n            Not another finance dashboard for people with money to manage. Brokebase is for the gap between\n            paychecks — track it, cap it, stop guessing.\n          </Typography>\n          <Box sx={{ display: \'flex\', gap: 2, flexWrap: \'wrap\' }}>\n            <Button\n              component={Link}\n              to="/register"\n              variant="contained"\n              size="large"\n              sx={{ px: 4, bgcolor: \'#0081d9\', \'&:hover\': { bgcolor: \'#005a9e\' } }}\n            >\n              Start free\n            </Button>\n            <Button component={Link} to="/login" variant="outlined" color="inherit" size="large" sx={{ px: 4 }}>\n              I have an account\n            </Button>\n          </Box>\n        </Container>\n      </Box>\n\n      {/* Feature grid — cards share borders instead of floating separately, reads as one panel */}\n      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 12 } }}>\n        <Typography sx={{ color: \'#3fa9f5\', fontSize: \'0.8rem\', letterSpacing: \'0.12em\', mb: 1 }} className="font-mono">\n          WHAT YOU GET\n        </Typography>\n        <Typography variant="h2" sx={{ fontSize: { xs: \'1.8rem\', md: \'2.3rem\' }, mb: 5, maxWidth: 640 }}>\n          Everything a broke month actually needs, nothing it doesn\'t.\n        </Typography>\n\n        <Box\n          sx={{\n            display: \'grid\',\n            gridTemplateColumns: { xs: \'1fr\', sm: \'1fr 1fr\', md: \'1fr 1fr 1fr 1fr\' },\n            border: \'1px solid #1f2227\',\n            borderRadius: 2,\n            overflow: \'hidden\'\n          }}\n        >\n          {features.map((f, i) => {\n            const Icon = f.icon;\n            return (\n              <Box\n                key={f.title}\n                sx={{\n                  p: 3.5,\n                  bgcolor: i % 2 === 0 ? \'#0d0f12\' : \'#0b0c0e\',\n                  borderRight: { md: (i % 4 !== 3) ? \'1px solid #1f2227\' : \'none\' },\n                  borderBottom: \'1px solid #1f2227\',\n                  transition: \'background-color 0.2s ease\',\n                  \'&:hover\': { bgcolor: \'#15171b\' }\n                }}\n              >\n                <Box\n                  sx={{\n                    width: 40,\n                    height: 40,\n                    borderRadius: \'8px\',\n                    display: \'flex\',\n                    alignItems: \'center\',\n                    justifyContent: \'center\',\n                    bgcolor: \'rgba(0,129,217,0.12)\',\n                    color: \'#3fa9f5\',\n                    mb: 2\n                  }}\n                >\n                  <Icon size={19} />\n                </Box>\n                <Typography sx={{ fontSize: \'1rem\', fontWeight: 600, mb: 1 }}>{f.title}</Typography>\n                <Typography sx={{ color: \'#9aa1ab\', fontSize: \'0.9rem\', lineHeight: 1.55 }}>{f.body}</Typography>\n              </Box>\n            );\n          })}\n        </Box>\n      </Container>\n\n      {/* How it works — a real ordered sequence, so numbering earns its place here */}\n      <Box sx={{ borderTop: \'1px solid #1f2227\', bgcolor: \'#0b0c0e\' }}>\n        <Container maxWidth="lg" sx={{ py: { xs: 8, md: 12 } }}>\n          <Typography sx={{ color: \'#3fa9f5\', fontSize: \'0.8rem\', letterSpacing: \'0.12em\', mb: 1 }} className="font-mono">\n            HOW IT WORKS\n          </Typography>\n          <Typography variant="h2" sx={{ fontSize: { xs: \'1.8rem\', md: \'2.3rem\' }, mb: 6, maxWidth: 640 }}>\n            Three steps. No onboarding tour.\n          </Typography>\n          <Box sx={{ display: \'grid\', gridTemplateColumns: { xs: \'1fr\', md: \'repeat(3, 1fr)\' }, gap: 4 }}>\n            {steps.map((s) => (\n              <Box key={s.n} sx={{ position: \'relative\', pl: 0 }}>\n                <Typography\n                  className="font-mono tabular"\n                  sx={{ fontSize: \'2.5rem\', fontWeight: 700, color: \'rgba(63,169,245,0.3)\', mb: 1, lineHeight: 1 }}\n                >\n                  {s.n}\n                </Typography>\n                <Typography sx={{ fontSize: \'1.15rem\', fontWeight: 600, mb: 1 }}>{s.title}</Typography>\n                <Typography sx={{ color: \'#9aa1ab\', fontSize: \'0.92rem\', lineHeight: 1.6 }}>{s.body}</Typography>\n              </Box>\n            ))}\n          </Box>\n        </Container>\n      </Box>\n\n      {/* CTA band */}\n      <Box\n        sx={{\n          background: \'linear-gradient(120deg, #005a9e 0%, #0081d9 50%, #2dd4bf 100%)\',\n          py: { xs: 7, md: 9 }\n        }}\n      >\n        <Container maxWidth="lg" sx={{ textAlign: \'center\' }}>\n          <Typography variant="h2" sx={{ fontSize: { xs: \'1.6rem\', md: \'2.1rem\' }, mb: 2, color: \'#08090b\' }}>\n            Stop guessing where your money went.\n          </Typography>\n          <Typography sx={{ color: \'rgba(8,9,11,0.75)\', mb: 4, maxWidth: 480, mx: \'auto\' }}>\n            Free to use. No card required to start.\n          </Typography>\n          <Button\n            component={Link}\n            to="/register"\n            variant="contained"\n            size="large"\n            sx={{ px: 5, bgcolor: \'#08090b\', color: \'#f4f5f7\', \'&:hover\': { bgcolor: \'#15171b\' } }}\n          >\n            Create your account\n          </Button>\n        </Container>\n      </Box>\n\n      <Box sx={{ borderTop: \'1px solid #1f2227\', py: 3 }}>\n        <Container maxWidth="lg">\n          <Typography sx={{ color: \'#6b7280\', fontSize: \'0.85rem\' }}>\n            © {new Date().getFullYear()} Brokebase. Built for people counting days to payday.\n          </Typography>\n        </Container>\n      </Box>\n    </Box>\n  );\n}\n'
TAILWIND_CONFIG = '/** @type {import(\'tailwindcss\').Config} */\nexport default {\n  content: [\'./index.html\', \'./src/**/*.{ts,tsx}\'],\n  theme: {\n    extend: {\n      colors: {\n        base: {\n          950: \'#08090b\',\n          900: \'#0d0f12\',\n          800: \'#15171b\',\n          700: \'#1f2227\',\n          600: \'#2a2e35\'\n        },\n        ink: {\n          100: \'#f4f5f7\',\n          400: \'#9aa1ab\',\n          500: \'#6b7280\'\n        },\n        signal: {\n          DEFAULT: \'#5eead4\', // acid teal accent — the one bold move\n          dim: \'#2dd4bf\'\n        },\n        brand: {\n          DEFAULT: \'#0081d9\',\n          light: \'#3fa9f5\',\n          dark: \'#005a9e\'\n        },\n        danger: \'#f87171\'\n      },\n      fontFamily: {\n        display: [\'"Space Grotesk"\', \'sans-serif\'],\n        body: [\'"Inter"\', \'sans-serif\'],\n        mono: [\'"IBM Plex Mono"\', \'monospace\']\n      }\n    }\n  },\n  plugins: []\n};\n'


def run(cmd, cwd=None):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd)
    if result.returncode != 0:
        print(f"Command failed: {cmd}")
        sys.exit(1)


def main():
    if os.geteuid() != 0:
        print("Run this as root (sudo python3 04_upgrade_landing.py)")
        sys.exit(1)

    if not os.path.isdir(FRONTEND_SRC):
        print(f"Expected frontend source at {FRONTEND_SRC} — run this from the repo checkout.")
        sys.exit(1)

    print("== Writing updated Landing.tsx ==")
    landing_path = os.path.join(FRONTEND_SRC, "src", "pages", "Landing.tsx")
    with open(landing_path, "w") as f:
        f.write(LANDING_TSX)
    print(f"  wrote {landing_path}")

    print("== Writing updated tailwind.config.js ==")
    tailwind_path = os.path.join(FRONTEND_SRC, "tailwind.config.js")
    with open(tailwind_path, "w") as f:
        f.write(TAILWIND_CONFIG)
    print(f"  wrote {tailwind_path}")

    print("== Installing react-icons ==")
    run("npm install react-icons@^5.7.0", cwd=FRONTEND_SRC)

    print("== Building frontend ==")
    run("npm run build", cwd=FRONTEND_SRC)

    print("== Deploying to nginx root ==")
    dist_src = os.path.join(FRONTEND_SRC, "dist")
    dist_dst = os.path.join(DEPLOY_ROOT, "dist")
    run(f"rm -rf {dist_dst}")
    run(f"mkdir -p {DEPLOY_ROOT}")
    run(f"cp -r {dist_src} {dist_dst}")
    run(f"chown -R brokebase:brokebase {DEPLOY_ROOT}")

    print("== Reloading nginx ==")
    run("nginx -t")
    run("systemctl reload nginx")

    print("\nDone. Refresh https://www.brokebase.com to see the new landing page.")


if __name__ == "__main__":
    main()
