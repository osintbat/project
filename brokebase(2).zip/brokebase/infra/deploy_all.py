#!/usr/bin/env python3
"""
deploy_all.py
One script, does everything: fetches brokebase.zip from GitHub, installs all
system dependencies (node, nginx, postgres, ufw, fail2ban), unzips, builds
frontend + backend, deploys to /opt/brokebase, runs DB migrations, starts the
backend as a systemd service, and writes + reloads the nginx config with the
Cloudflare origin cert already in /opt/certs.

EDIT THIS BEFORE RUNNING:
  ZIP_URL — raw GitHub URL to your brokebase.zip

Run as root, from anywhere:
  python3 deploy_all.py
"""
import os
import subprocess
import sys
import secrets

# ---- EDIT ME ----
ZIP_URL = "https://github.com/osintbat/project/raw/refs/heads/main/brokebase.zip"
# ------------------

WORK_DIR = "/opt/brokebase_src"
DEPLOY_ROOT = "/opt/brokebase"
DB_NAME = "brokebase"
DB_USER = "brokebase_app"
DOMAIN = "brokebase.com"


def run(cmd, cwd=None, check=True):
    print(f"$ {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd)
    if check and result.returncode != 0:
        print(f"Command failed: {cmd}")
        sys.exit(1)
    return result.returncode


def step(title):
    print(f"\n== {title} ==")


def main():
    if os.geteuid() != 0:
        print("Run this as root (sudo python3 deploy_all.py)")
        sys.exit(1)

    # ---------- 1. Base system packages ----------
    step("1/9 Base packages")
    run("apt-get update -y")
    run(
        "DEBIAN_FRONTEND=noninteractive apt-get install -y "
        "curl ca-certificates gnupg build-essential ufw fail2ban "
        "unattended-upgrades git unzip"
    )

    step("2/9 Node.js 20 LTS")
    if run("command -v node", check=False) != 0:
        run("curl -fsSL https://deb.nodesource.com/setup_20.x | bash -")
        run("DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs")
    else:
        print("  node already installed, skipping")

    step("3/9 nginx")
    run("DEBIAN_FRONTEND=noninteractive apt-get install -y nginx")
    run("systemctl enable nginx")

    step("4/9 PostgreSQL")
    run("DEBIAN_FRONTEND=noninteractive apt-get install -y postgresql postgresql-contrib")
    run("systemctl enable postgresql")
    run("systemctl start postgresql")

    db_password = secrets.token_urlsafe(24)
    sql = f"""
DO $$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '{DB_USER}') THEN
      CREATE ROLE {DB_USER} LOGIN PASSWORD '{db_password}';
   ELSE
      ALTER ROLE {DB_USER} WITH PASSWORD '{db_password}';
   END IF;
END
$$;
SELECT 'CREATE DATABASE {DB_NAME} OWNER {DB_USER}'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '{DB_NAME}')\\gexec
GRANT ALL PRIVILEGES ON DATABASE {DB_NAME} TO {DB_USER};
"""
    with open("/tmp/brokebase_init.sql", "w") as f:
        f.write(sql)
    run("sudo -u postgres psql -v ON_ERROR_STOP=1 -f /tmp/brokebase_init.sql")
    os.remove("/tmp/brokebase_init.sql")
    database_url = f"postgres://{DB_USER}:{db_password}@127.0.0.1:5432/{DB_NAME}"
    print(f"  DATABASE_URL={database_url}")

    step("5/9 Firewall")
    run("ufw allow OpenSSH", check=False)
    run("ufw allow 'Nginx Full'", check=False)
    run("ufw --force enable", check=False)

    # ---------- 2. Fetch + unzip the project ----------
    step("6/9 Fetching project from GitHub")
    run(f"rm -rf {WORK_DIR}")
    run(f"mkdir -p {WORK_DIR}")
    run(f"curl -fsSL -o /tmp/brokebase.zip '{ZIP_URL}'")
    run(f"unzip -oq /tmp/brokebase.zip -d {WORK_DIR}")
    # zip contains a top-level "brokebase/" folder
    src_root = os.path.join(WORK_DIR, "brokebase")
    if not os.path.isdir(src_root):
        # fallback: maybe the zip has no wrapper folder
        src_root = WORK_DIR
    frontend_src = os.path.join(src_root, "frontend")
    backend_src = os.path.join(src_root, "backend")

    # ---------- 3. Build frontend ----------
    step("7/9 Building frontend")
    run("npm install", cwd=frontend_src)
    env_content = "VITE_API_URL=https://www.brokebase.com/api\n"
    with open(os.path.join(frontend_src, ".env.production"), "w") as f:
        f.write(env_content)
    run("npm run build", cwd=frontend_src)

    # ---------- 4. Build backend ----------
    run("npm install", cwd=backend_src)
    run("npm run build", cwd=backend_src)

    # ---------- 5. System user + directories ----------
    step("8/9 Deploying")
    run("id -u brokebase >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin brokebase")

    run(f"mkdir -p {DEPLOY_ROOT}/frontend {DEPLOY_ROOT}/backend/env {DEPLOY_ROOT}/backend/logs")

    # frontend: nginx root expects /opt/brokebase/frontend/dist
    run(f"rm -rf {DEPLOY_ROOT}/frontend/dist")
    run(f"cp -r {os.path.join(frontend_src, 'dist')} {DEPLOY_ROOT}/frontend/dist")

    # backend: compiled JS + runtime deps
    run(f"rm -rf {DEPLOY_ROOT}/backend/dist {DEPLOY_ROOT}/backend/node_modules")
    run(f"cp -r {os.path.join(backend_src, 'dist')} {DEPLOY_ROOT}/backend/dist")
    run(f"cp -r {os.path.join(backend_src, 'node_modules')} {DEPLOY_ROOT}/backend/node_modules")
    run(f"cp {os.path.join(backend_src, 'package.json')} {DEPLOY_ROOT}/backend/package.json")

    jwt_secret = secrets.token_urlsafe(48)
    env_file = f"""NODE_ENV=production
PORT=4000
DATABASE_URL={database_url}
JWT_SECRET={jwt_secret}
JWT_EXPIRES_IN=15m
REFRESH_TOKEN_EXPIRES_IN=7d
CORS_ALLOWED_ORIGINS=https://www.{DOMAIN}
COOKIE_DOMAIN=.{DOMAIN}
"""
    with open(f"{DEPLOY_ROOT}/backend/env/.env", "w") as f:
        f.write(env_file)
    # symlink so `node dist/db/migrate.js` also picks it up when run manually
    run(f"ln -sf env/.env {DEPLOY_ROOT}/backend/.env")

    run(f"chown -R brokebase:brokebase {DEPLOY_ROOT}")

    # ---------- 6. Migrate + systemd ----------
    run(f"cd {DEPLOY_ROOT}/backend && node dist/db/migrate.js")

    unit = f"""[Unit]
Description=Brokebase API
After=network.target postgresql.service

[Service]
Type=simple
User=brokebase
Group=brokebase
WorkingDirectory={DEPLOY_ROOT}/backend
EnvironmentFile={DEPLOY_ROOT}/backend/env/.env
ExecStart=/usr/bin/node dist/server.js
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths={DEPLOY_ROOT}/backend/logs
ProtectHome=true

[Install]
WantedBy=multi-user.target
"""
    with open("/etc/systemd/system/brokebase-backend.service", "w") as f:
        f.write(unit)
    run("systemctl daemon-reload")
    run("systemctl enable --now brokebase-backend")
    run("sleep 2")
    run("systemctl status brokebase-backend --no-pager", check=False)

    # ---------- 7. nginx ----------
    step("9/9 nginx + TLS")
    cert_path = "/opt/certs/cert.pem"
    key_path = "/opt/certs/key.pem"
    for p in (cert_path, key_path):
        if not os.path.isfile(p):
            print(f"Missing {p} — cannot write nginx TLS config. Deploy stops here; add the cert and rerun nginx setup.")
            sys.exit(1)

    nginx_conf = f"""# Managed by deploy_all.py
server {{
    listen 80;
    listen [::]:80;
    server_name {DOMAIN} www.{DOMAIN};
    return 301 https://www.{DOMAIN}$request_uri;
}}

server {{
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name {DOMAIN};
    ssl_certificate     {cert_path};
    ssl_certificate_key {key_path};
    ssl_protocols TLSv1.2 TLSv1.3;
    return 301 https://www.{DOMAIN}$request_uri;
}}

server {{
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name www.{DOMAIN};

    ssl_certificate     {cert_path};
    ssl_certificate_key {key_path};
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5:!3DES:!RC4;
    ssl_prefer_server_ciphers on;

    set_real_ip_from 0.0.0.0/0;
    real_ip_header CF-Connecting-IP;

    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()" always;

    client_max_body_size 1m;

    root {DEPLOY_ROOT}/frontend/dist;
    index index.html;

    location / {{
        try_files $uri /index.html;
    }}

    location ~ /\\. {{ deny all; }}
    location ~* \\.(env|log|sql|bak|git)$ {{ deny all; }}

    location /api/ {{
        proxy_pass http://127.0.0.1:4000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header CF-Connecting-IP $http_cf_connecting_ip;
        proxy_read_timeout 30s;
        proxy_connect_timeout 5s;
    }}

    location = /health {{
        proxy_pass http://127.0.0.1:4000/health;
    }}
}}
"""
    os.makedirs("/etc/nginx/sites-available", exist_ok=True)
    os.makedirs("/etc/nginx/sites-enabled", exist_ok=True)
    with open(f"/etc/nginx/sites-available/{DOMAIN}", "w") as f:
        f.write(nginx_conf)
    if not os.path.islink(f"/etc/nginx/sites-enabled/{DOMAIN}"):
        os.symlink(f"/etc/nginx/sites-available/{DOMAIN}", f"/etc/nginx/sites-enabled/{DOMAIN}")
    default_site = "/etc/nginx/sites-enabled/default"
    if os.path.exists(default_site):
        os.remove(default_site)

    run("nginx -t")
    run("systemctl reload nginx")

    print(f"\nDone. Visit https://www.{DOMAIN}")
    print(f"DATABASE_URL saved in {DEPLOY_ROOT}/backend/env/.env")


if __name__ == "__main__":
    main()
