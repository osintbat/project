import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    // impedisce di servire file al di fuori della root del progetto
    fs: { strict: true },
  },
  build: {
    // niente sourcemap in produzione: evita di esporre codice sorgente/commenti interni
    sourcemap: false,
  },
});
