/**
 * safePath.js
 *
 * Utility per prevenire Path Traversal / Directory Traversal / LFI / arbitrary
 * file read-write quando un backend Node.js deve risolvere un path fornito
 * (anche indirettamente) da un utente.
 *
 * Regola d'oro: MAI passare a fs.readFile/writeFile/sendFile un path costruito
 * concatenando input utente senza prima farlo passare da qui.
 *
 * Uso tipico (Express):
 *
 *   const { resolveSafePath } = require("./security/safePath");
 *   const UPLOADS_ROOT = path.join(__dirname, "..", "storage", "uploads");
 *
 *   app.get("/files/:name", (req, res) => {
 *     const safe = resolveSafePath(UPLOADS_ROOT, req.params.name);
 *     if (!safe) return res.status(404).end(); // niente dettagli, sempre 404
 *     res.sendFile(safe);
 *   });
 */

const path = require("node:path");
const fs = require("node:fs");

/**
 * Risolve `userInput` dentro `rootDir` garantendo che il risultato non possa
 * mai uscire da `rootDir`, anche con ../, path assoluti, null byte o symlink.
 *
 * @param {string} rootDir - directory radice consentita (deve essere assoluta)
 * @param {string} userInput - segmento di path fornito dall'utente
 * @returns {string|null} path assoluto sicuro, oppure null se l'input e' invalido/malevolo
 */
function resolveSafePath(rootDir, userInput) {
  if (typeof userInput !== "string" || userInput.length === 0) return null;

  // null byte injection
  if (userInput.includes("\0")) return null;

  const root = path.resolve(rootDir);

  // normalizza e risolve l'input RELATIVAMENTE alla root, mai come path assoluto
  const candidate = path.resolve(root, path.normalize(userInput));

  // deve restare strettamente dentro root (root stessa esclusa, salvo serva)
  const relative = path.relative(root, candidate);
  const isInsideRoot =
    relative !== "" && !relative.startsWith("..") && !path.isAbsolute(relative);

  if (!isInsideRoot) return null;

  // se il file esiste, risolvi anche eventuali symlink e riverifica che
  // il target reale sia ancora dentro root (blocca symlink traversal)
  try {
    const real = fs.realpathSync(candidate);
    const realRelative = path.relative(root, real);
    const realInsideRoot =
      realRelative !== "" &&
      !realRelative.startsWith("..") &&
      !path.isAbsolute(realRelative);
    if (!realInsideRoot) return null;
    return real;
  } catch {
    // file non ancora esistente (es. scrittura nuova): il check sul candidate
    // normalizzato e' comunque sufficiente per bloccare la traversal
    return candidate;
  }
}

/**
 * Whitelist di nomi file: consente solo [a-zA-Z0-9._-], lunghezza massima 255.
 * Da usare quando l'utente fornisce SOLO un nome file (mai un path con /).
 */
function isSafeFilename(name) {
  if (typeof name !== "string") return false;
  if (name.length === 0 || name.length > 255) return false;
  if (name === "." || name === "..") return false;
  return /^[a-zA-Z0-9._-]+$/.test(name);
}

module.exports = { resolveSafePath, isSafeFilename };
