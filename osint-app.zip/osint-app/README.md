# OSINT App — starter

## Setup

```bash
npm install
cp .env.example .env
# incolla la tua Clerk publishable key (pk_live_/pk_test_) in .env
npm run dev
```

## ⚠️ Sicurezza chiavi

- `.env` è nel `.gitignore`: non committarlo mai.
- La `CLERK_SECRET_KEY` **non serve in questo progetto** (è un'app Vite/SPA
  pura, senza backend): quella chiave va usata SOLO lato server, quando
  aggiungerai un'API. Non va mai messa nel codice frontend né in `.env` di
  un progetto Vite (finirebbe nel bundle pubblico).
- Se una chiave secret è mai stata incollata in una chat, un log o un
  commit pubblico, consideraLa compromessa e rigenerala dalla dashboard
  Clerk, anche se era "solo per test".

## Cosa c'è

- Login (`/login`) e Register (`/register`) con Clerk, ritematizzati sulla
  palette "Modal" (dark, accento lime).
- Routing con 404 generico per qualsiasi path non riconosciuto (nessuna
  fuga di informazioni su struttura interna).
- CSP restrittiva in `index.html` (da duplicare come header HTTP reale in
  produzione).
- `server/security/safePath.js`: utility anti path-traversal pronta per
  quando aggiungerai un backend.

## Cosa manca volutamente

- Dashboard: non richiesta in questo giro.
- Backend/API: quando lo aggiungerai, valuta gli input con `zod`, usa query
  parametrizzate/ORM per qualsiasi DB, e monta `safePath.js` per ogni
  endpoint che tocca il filesystem.
