import type { Appearance } from "@clerk/types";

export const modalClerkAppearance: Appearance = {
  variables: {
    colorPrimary: "#7fee64",
    colorBackground: "#181818",
    colorText: "#ddffdc",
    colorTextSecondary: "#8cab87",
    colorInputBackground: "#212525",
    colorInputText: "#ddffdc",
    colorDanger: "#ff6b6b",
    borderRadius: "12px",
    fontFamily: "'Inter Variable', ui-sans-serif, system-ui, sans-serif",
  },
  elements: {
    card: "bg-ground-iron border border-circuit-border/40 shadow-none",
    headerTitle: "text-phosphor-white",
    headerSubtitle: "text-sage-60",
    formButtonPrimary:
      "bg-lime-pulse text-black hover:bg-lime-pulse/90 rounded-full font-medium normal-case",
    formFieldInput:
      "bg-carbon-veil border-circuit-border/50 text-phosphor-white focus:border-lime-pulse",
    formFieldLabel: "text-sage-60",
    footerActionLink: "text-lime-pulse hover:text-lime-pulse/80",
    dividerLine: "bg-circuit-border/30",
    dividerText: "text-sage-40",
    socialButtonsBlockButton:
      "border-circuit-border/40 text-phosphor-white hover:bg-carbon-veil",
    identityPreviewText: "text-phosphor-white",
    formResendCodeLink: "text-lime-pulse",
  },
};
