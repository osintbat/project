import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { ClerkProvider } from "@clerk/clerk-react";
import App from "./App";
import "./index.css";

// La chiave pubblicabile e' sicura da esporre lato client (per design di Clerk),
// ma va comunque presa da env e mai hardcoded nel sorgente: cosi' resta
// facile da ruotare/differenziare tra ambienti (dev/staging/prod) senza toccare il codice.
const CLERK_PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

if (!CLERK_PUBLISHABLE_KEY) {
  throw new Error(
    "Manca VITE_CLERK_PUBLISHABLE_KEY. Copia .env.example in .env e imposta la publishable key di Clerk.",
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ClerkProvider publishableKey={CLERK_PUBLISHABLE_KEY} afterSignOutUrl="/">
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ClerkProvider>
  </StrictMode>,
);
