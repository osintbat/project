import type { ReactNode } from "react";

export function AuthShell({
  eyebrow,
  title,
  subtitle,
  children,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <div className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-void-black px-6 py-12">
      {/* unico accento cromatico della pagina: un glow lime ambientale */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/2 h-[640px] w-[640px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-30 blur-[140px]"
        style={{
          background:
            "radial-gradient(circle, rgba(127,238,100,0.55), transparent 70%)",
        }}
      />

      {/* hairline grid di sfondo, molto tenue */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(#485346 1px, transparent 1px), linear-gradient(90deg, #485346 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />

      <div className="relative z-10 grid w-full max-w-5xl grid-cols-1 overflow-hidden rounded-2xl border border-circuit-border/40 bg-black/20 backdrop-blur-sm md:grid-cols-2">
        {/* pannello sinistro: identita' del brand, stile code-window */}
        <div className="hidden flex-col justify-between bg-carbon-veil p-10 md:flex">
          <div>
            <div className="mb-10 flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-lime-pulse" />
              <span className="text-xs uppercase tracking-[0.15em] text-moss-70">
                system online
              </span>
            </div>

            <p className="mb-3 text-xs uppercase tracking-[0.2em] text-moss-70">
              {eyebrow}
            </p>
            <h1 className="mb-4 max-w-xs text-3xl font-medium leading-[1.1] text-phosphor-white">
              {title}
            </h1>
            <p className="max-w-xs text-sm leading-relaxed text-sage-60">
              {subtitle}
            </p>
          </div>

          <div className="mt-10 rounded-lg border border-circuit-border/40 bg-charcoal-rust/40 p-4 font-mono text-xs leading-relaxed text-sage-60">
            <div className="mb-2 flex gap-1.5">
              <span className="h-2 w-2 rounded-full bg-circuit-border" />
              <span className="h-2 w-2 rounded-full bg-circuit-border" />
              <span className="h-2 w-2 rounded-full bg-circuit-border" />
            </div>
            <p>
              <span className="text-lime-pulse">$</span> auth --session secure
            </p>
            <p className="text-deep-fern">// encrypted end-to-end via Clerk</p>
          </div>
        </div>

        {/* pannello destro: form Clerk */}
        <div className="flex items-center justify-center bg-ground-iron p-6 sm:p-10">
          <div className="w-full max-w-sm">{children}</div>
        </div>
      </div>
    </div>
  );
}
