const STATS = [
  { value: "500+", label: "sources monitored per domain" },
  { value: "24/7", label: "continuous scanning" },
  { value: "<5min", label: "average alert latency" },
];

export function StatsBand() {
  return (
    <section className="border-y border-phosphor-blue-black bg-carbon-veil px-6 py-16">
      <div className="mx-auto grid max-w-[1280px] grid-cols-1 gap-8 text-center sm:grid-cols-3">
        {STATS.map((stat) => (
          <div key={stat.label}>
            <p className="mb-2 text-4xl font-medium text-lime-pulse">
              {stat.value}
            </p>
            <p className="text-sm text-sage-60">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
