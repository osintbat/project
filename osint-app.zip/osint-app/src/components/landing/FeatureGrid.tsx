const FEATURES = [
  {
    title: "Domain & asset discovery",
    description:
      "Automatically map every subdomain, certificate, and exposed service tied to your organization — kept current as your infrastructure changes.",
  },
  {
    title: "Exposure monitoring",
    description:
      "Get alerted the moment credentials or configuration tied to your own domains surface in a known incident, so you can rotate them fast.",
  },
  {
    title: "Reporting & workflow",
    description:
      "Turn findings into tickets your team can actually act on, with severity scoring and a full audit trail for compliance.",
  },
];

export function FeatureGrid() {
  return (
    <section id="product" className="bg-void-black px-6 py-24">
      <div className="mx-auto max-w-[1280px]">
        <p className="mb-3 text-center text-xs uppercase tracking-[0.2em] text-moss-70">
          Platform
        </p>
        <h2 className="mx-auto mb-16 max-w-xl text-center text-3xl font-medium leading-tight text-phosphor-white sm:text-4xl">
          Everything your security team needs to watch your own perimeter.
        </h2>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {FEATURES.map((feature) => (
            <div
              key={feature.title}
              className="rounded-lg bg-phosphor-blue-black p-8"
            >
              <div className="mb-6 h-16 w-16 rounded bg-lime-pulse/10" aria-hidden />
              <h3 className="mb-2 text-xl font-normal text-phosphor-white">
                {feature.title}
              </h3>
              <p className="text-sm leading-relaxed text-sage-60">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
