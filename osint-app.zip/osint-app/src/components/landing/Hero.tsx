import { Link } from "react-router-dom";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-void-black px-6 py-32 text-center">
      {/* unico accento cromatico della sezione: glow ambientale */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-1/3 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-30 blur-[130px]"
        style={{
          background: "radial-gradient(circle, rgba(127,238,100,0.6), transparent 70%)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-3xl">
        <p className="mb-4 text-xs uppercase tracking-[0.2em] text-moss-70">
          Attack surface intelligence
        </p>

        <h1 className="mb-6 text-4xl font-medium leading-[1.1] text-phosphor-white sm:text-6xl">
          <span className="text-lime-pulse">See your exposure</span> before
          someone else finds it first.
        </h1>

        <p className="mx-auto mb-10 max-w-xl text-lg leading-relaxed text-moss-80">
          TraceGrid continuously maps your organization's public footprint —
          domains, credentials, and infrastructure — and flags what shouldn't
          be exposed, so your team can fix it before it becomes an incident.
        </p>

        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link
            to="/register"
            className="rounded-full bg-lime-pulse px-6 py-3 text-sm font-medium text-black transition-opacity hover:opacity-90"
          >
            Start free assessment
          </Link>
          <a
            href="#how-it-works"
            className="rounded-xl border border-phosphor-white/80 px-8 py-3 text-sm font-medium text-phosphor-white transition-colors hover:bg-phosphor-white/5"
          >
            How it works
          </a>
        </div>

        <p className="mt-6 text-xs text-sage-40">
          No credit card required · Access scoped to your own verified domains
        </p>
      </div>
    </section>
  );
}
