import { Link } from "react-router-dom";

export function CTASection() {
  return (
    <section id="how-it-works" className="bg-void-black px-6 py-24 text-center">
      <div className="mx-auto max-w-xl">
        <h2 className="mb-4 text-3xl font-medium text-phosphor-white sm:text-4xl">
          Get a baseline of your exposure in minutes.
        </h2>
        <p className="mb-8 text-sage-60">
          Verify ownership of your domain, and TraceGrid starts mapping your
          footprint right away. No sales call required to get started.
        </p>
        <Link
          to="/register"
          className="inline-block rounded-full bg-lime-pulse px-6 py-3 text-sm font-medium text-black transition-opacity hover:opacity-90"
        >
          Create free account
        </Link>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-phosphor-blue-black bg-carbon-veil px-6 py-12">
      <div className="mx-auto flex max-w-[1280px] flex-col items-center justify-between gap-6 sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-lime-pulse" />
          <span className="text-sm text-phosphor-white">TraceGrid</span>
        </div>
        <p className="text-xs text-deep-fern">
          © {new Date().getFullYear()} TraceGrid. Built for defensive
          security teams monitoring their own assets.
        </p>
      </div>
    </footer>
  );
}
