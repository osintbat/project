import { Link } from "react-router-dom";

const NAV_LINKS = [
  { label: "Product", href: "#product" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Pricing", href: "#pricing" },
  { label: "Docs", href: "#docs" },
];

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-phosphor-blue-black bg-carbon-veil/80 backdrop-blur-[10px]">
      <div className="mx-auto flex h-16 max-w-[1280px] items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-lime-pulse" />
          <span className="text-lg font-medium text-phosphor-white">
            TraceGrid
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm text-phosphor-white/90 transition-colors hover:text-lime-pulse"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            to="/login"
            className="text-sm text-fern-link transition-colors hover:text-phosphor-white"
          >
            Log in
          </Link>
          <Link
            to="/register"
            className="rounded-full bg-lime-pulse px-5 py-2 text-sm font-medium text-black transition-opacity hover:opacity-90"
          >
            Sign up
          </Link>
        </div>
      </div>
    </header>
  );
}
