import { SignIn } from "@clerk/clerk-react";
import { AuthShell } from "../components/AuthShell";
import { modalClerkAppearance } from "../lib/clerkAppearance";

export default function LoginPage() {
  return (
    <AuthShell
      eyebrow="Access Console"
      title="Sign in to your workspace."
      subtitle="Open-source intelligence, structured. Sign in to pick up where you left off."
    >
      <SignIn
        routing="path"
        path="/login"
        signUpUrl="/register"
        appearance={modalClerkAppearance}
      />
    </AuthShell>
  );
}
